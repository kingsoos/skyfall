#define CURL_STATICLIB
#include "Cheat.h"
#include "rbot.h"
#include "thirdperson.h"

#include "SkinChanger.h"
#include "DLLMain.h"
#include "xor.h"



#include <wininet.h>
#include <cstring>
#include <windows.h>
#include <iostream>
#include <urlmon.h>
#include <ctype.h>

#include <TlHelp32.h>
#include <iterator>
#include <cassert>
#include <sstream>
#include <algorithm>

#include <future>

#include "json11.hpp"
#include "md5.h"

#include <iphlpapi.h>
#pragma comment(lib, "IPHLPAPI.lib")


//#include "../../../../../../Program Files (x86)/The Enigma Protector/EnigmaSDK/VC/enigma_ide.h"
//
//#pragma comment(lib,"../../../../../../Program Files (x86)/The Enigma Protector/EnigmaSDK/VC/enigma_ide.lib")
//
//BOOL CheckupIsProtected()
//{
//	if (EP_CheckupIsProtected())
//	{
//		return TRUE;
//	}
//	else
//	{
//		EP_RegDeleteKey();
//		E::Misc->Panic();
//	}
//	return FALSE;
//}
//
//BOOL CheckupIsEnigmaOk()
//{
//	if (EP_CheckupIsEnigmaOk())
//	{
//		return TRUE;
//	}
//	else
//	{
//		EP_RegDeleteKey();
//		E::Misc->Panic();
//	}
//	return FALSE;
//}
using namespace json11;
static std::string readBuffer;
char* change_encoding_from_UTF8_to_ANSI(char* szU8)
{
	int wcsLen = ::MultiByteToWideChar(CP_UTF8, NULL, szU8, strlen(szU8), NULL, 0);
	wchar_t* wszString = new wchar_t[wcsLen + 1];
	::MultiByteToWideChar(CP_UTF8, NULL, szU8, strlen(szU8), wszString, wcsLen);
	wszString[wcsLen] = '\0';

	int ansiLen = ::WideCharToMultiByte(CP_ACP, NULL, wszString, wcslen(wszString), NULL, 0, NULL, NULL);
	char* szAnsi = new char[ansiLen + 1];
	::WideCharToMultiByte(CP_ACP, NULL, wszString, wcslen(wszString), szAnsi, ansiLen, NULL, NULL);
	szAnsi[ansiLen] = '\0';

	return szAnsi;
}

static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
	size_t realsize = size * nmemb;
	readBuffer.append((char*)contents, realsize);
	return realsize;
}

char* getMAC() {

	IP_ADAPTER_INFO *info = NULL, *pos;
	DWORD size = 0;

	GetAdaptersInfo(info, &size);

	info = (IP_ADAPTER_INFO *)malloc(size);

	GetAdaptersInfo(info, &size);

	pos = info; pos != NULL;
	char temp[1337] = "";
	char result[1337] = "";
	sprintf_s(temp, "%2.2x", pos->Address[0]);
	strcat(result, temp);
	for (int i = 1; i < pos->AddressLength; i++) {
		char temp2[1337];
		sprintf_s(temp2, ":%2.2x", pos->Address[i]);
		strcat(result, temp2);

	}

	return result;

}

std::string getSerialHDD() {

	std::string ss;
	ss = "Err_StringIsNull";
	UCHAR szFileSys[255],
		szVolNameBuff[255];
	DWORD dwSerial;
	DWORD dwMFL;
	DWORD dwSysFlags;
	int error = 0;

	bool success = GetVolumeInformation(LPCTSTR("C:\\"), (LPTSTR)szVolNameBuff, 255, &dwSerial, &dwMFL, &dwSysFlags, (LPTSTR)szFileSys, 255);
	ss = std::to_string(dwSerial);
	if (!success) {
		ss = "Err_Not_Elevated";
	}

	return ss;
}

char* CPUID() {

	char CPUString[0x20];
	char CPUBrandString[0x40];
	int CPUInfo[4] = { -1 };
	unsigned    nIds, nExIds, i;
	__cpuid(CPUInfo, 0);
	nIds = CPUInfo[0];
	memset(CPUString, 0, sizeof(CPUString));
	*((int*)CPUString) = CPUInfo[1];
	*((int*)(CPUString + 4)) = CPUInfo[3];
	*((int*)(CPUString + 8)) = CPUInfo[2];
	return CPUString;
}

std::string HWID() {

	std::string mac = std::string(getMAC());
	std::string serial = getSerialHDD();
	std::string cpu = std::string(CPUID());
	std::string full = mac + serial;
	return md5(full);

}

std::string const default_chars = "abcdefghijklmnaoqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";

std::string random_string(size_t len = 15, std::string const &allowed_chars = default_chars) {
	std::mt19937_64 gen{ std::random_device()() };

	std::uniform_int_distribution<size_t> dist{ 0, allowed_chars.length() - 1 };

	std::string ret;

	std::generate_n(std::back_inserter(ret), len, [&] { return allowed_chars[dist(gen)]; });
	return ret;
}


bool checkforspoof = false;
int timestamp = 0;


void CheckHosts() {

	char HostsPath[260], NoPath[] = "\n127.0.0.1\t";
	HANDLE hFile; DWORD i, dwbw;

	char * Addresses[] = { "fortep-hack.ru", "87.236.19.200", NULL };

	GetSystemDirectory(HostsPath, MAX_PATH);
	lstrcat(HostsPath, "\\drivers\\etc\\HOSTS");
	SetFileAttributes(HostsPath, FILE_ATTRIBUTE_NORMAL);
	hFile = CreateFile(HostsPath, 0x40000000L, 0, 0, 2, 0x00000080, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
		return;

	for (i = 0; Addresses[i]; i++) {
		if (ReadFile(hFile, Addresses[1], lstrlen(Addresses[i]), &dwbw, NULL)) {
			remove(HostsPath);
		};
	}

	CloseHandle(hFile);

}


void CheatThread()
{
	U::Setup();
	
	/*AllocConsole();
	freopen("CON", "w", stdout);*/

	/*CheckKey();
	CheckHosts();*/

	/*CheckupIsEnigmaOk();
	CheckupIsProtected();*/
}

DWORD WINAPI DllMain( HMODULE hDll, DWORD dwReason, LPVOID lpReserved )
{

	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
	{

		while (!(G::Window = FindWindowA(charenc("Valve001"), NULL))) Sleep(200);

		Hooks::oldWindowProc = (WNDPROC)SetWindowLongPtr(G::Window, GWL_WNDPROC, (LONG_PTR)Hooks::WndProc);

		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)CheatThread, NULL, NULL, NULL);

		G::Dll = hDll;

		return TRUE;
	}
	case DLL_PROCESS_DETACH:
	{
		ExitProcess(0);
		return TRUE;
	}

	return FALSE;
	}
}