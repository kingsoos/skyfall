#include "../Cheat.h"
//#define WEAPON_DATA_SIZE ( sizeof( pWeaponData ) / sizeof( *pWeaponData ) )
#include "../Settings/Vars.h"
#include "../Hooks.h"
