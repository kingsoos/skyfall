﻿#include <vector>
#include "../Cheat.h"
#include "Menu.h"
#include "../SkinChanger.h"


#include <locale>
#include <d3d9.h>
#include <../../../../../Program Files (x86)/Microsoft DirectX SDK (June 2010)/Include/d3dx9.h>


#include "..\imgui\imgui_internal.h"


#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")


static const char rawData_compressed_data_base85[21475 + 1] = //font
"7])#######QLE^e'/###W),##/l:$#Q6>##5[n42XeNY*p6)=-(_rS%G(pu8EXa3aHC&##@x###/MF0FfhKSF+/###&s+##<1PkE[]FgEA&###nA+##FY=UCY5L)E*K###4F4v-D'TqL"
"f:s;?oL(##xF*R<E3n0F4`90++Kdw'U-&##lC]UCXO.dro+(##>78V1P+uhFBd?mF/R###u-2_A/[Y=BMpwOoMN*##*2I20i3^=BLu#7o'&`w'LZ+##DsEiFPdsq)L=%##]j'##VQu9)"
"p[-;Ql`xQEd/s.CW<(&P7@GF%s:c@t?C0i#rP'##AIggL8xQ%J<rj*%^)Cv-kTbu>V2)g(j0bw'K%T&#,X&,2(a*`s3oZS%)55uu41RS%*OV8&/e.T&e]C_&bL35&.C82'a,Ke$`ejl&"
"/'4m'4<b2(iiC_&k*KM'2nkf(e8Ke$5Q^e$jE,/(=&?g)g>Ke$n^cf(=>DH*2>9xtp`^e$s#DG)BSrD+kJKe$w;%)*Blw&,5At[tuo^e$&W[`*G+O#-oVKe$*p<A+AusY-LX,w-8DX@t"
"c4tx+FF,W.scKe$3MTY,FLP8/Q0`T/;G=%tlh5;-Kt_50woKe$<+mr-K$.m0P9[21)VD_&GFMS.I[ef1%&Le$QP_e$Fb.5/Y#9g2',Le$J$fl/Y;>H3CS]Cs6`_e$O?FM0_PlD4+8Le$"
"SW'/1_iq&5FVA(s;o_e$Xs^f1d(I#6/DLe$]5?G2^rmY6iU&w6IY&cr?Pv(3cC&W73PLe$fiV`3cIJ88n-YT8L]aFrH.8A4hqX597]Le$oFox4hw'm9m6U2:?CE_&$cOY5aI_f:;iLe$"
"nO`e$#(1;6vv2g;=oLe$-@hr6et;D<?uLe$s_`e$,[HS7%NfD=A%Me$0t)58%gk&>WleIqWn`e$59al8*&C#?E1Me$9QAM9$pgY?pM_mpp`]i9o/-8@H:Me$@#>J:*J;s@J@Me$+4ae$"
"K>u+;sY`lALFMe$IVUc;/xnPBNLMe$0Cae$Nr6D<>tKNCbxiLp04n%=2C9/D7XgJDX9F_&WON]==9)-Ee%N1p9h/>>7qlcE<0D)F]EF_&a-gu><B%aFXkMe$iEGV?+@.>GA^w]GaQF_&"
"ja(8@ApW>H]wMe$@nNe$YharHl.nOoN2%5AE>pVI`*Ne$uJ[lAED>8JP(MTJo1R4oWf<MBJlL5Kd6Ne$()t.CJrqlKUU*3Lr47onaCTfCOC*jLhBNe$PNbe$2`5GDXq&gMjHNe$<xl(E"
"=P/DNlNNe$U^be$;=M`E^HYDOnTNe$EU.AFA%cxOpZNe$Zmbe$DqexFcv6#QraNe$H3FYG]jZYQfHNZm)BbuGGbv7RujNe$OZBVHcD/sRwpNe$d2ce$Zv#8IK6SlS#wNe$X8ZoIhrbPT"
"%'Oe$iAce$dS;PJOa0JU'-Oe$blr1Kk=-/VpRZJV/jG_&g1SiKv3s,W1P?ulHI4JLpk`cWu*8)X3vG_&pek+M%bOaX4S$YlQ'LcMuB=AY$Xk]Y7,H_&#C-DN$kK>Z3QOe$#mPe$2DTrZ"
"8Y_=l^j)AO(9dV[6ZOe$.-axO(?28]`hUake;&>Pc$Ml]9dOe$5T]uP.p[P^;jOe$/Ade$@p=VQgN*J_=pOe$>2u7R1;'/`6PTJ`EVH_&IMUoRk#^(aA&Pe$Gf6PS6iYca;(2)bIcH_&"
"L+n1TA_IabEiG%k.CNiT;@7Ac@Ue]cMoH_&U_/JU@hE>dI>Pe$?lQe$I2NrdIo,`j:0,GVD6^VeLGPe$aHc(WD<,8fZ:#-jAW(DW$iFlfOPPe$hp_%XJmUPgQVPe$K@ee$s5@]X(=$Jh"
"S]Pe$qMw=YM8w.iRMNJi[CI_&&jWuY,hV(jWiPe$$,9VZRfScjW%,)k`OI_&)Gp7[^[CakV(lFia_Po[W=1Al]R_]ld[I_&2%2P]a'e>mY+P+i=wee$7@i1^f<<;nb1Qe$;XIi^b<srn"
"d7Qe$a$Se$eJ%Po^15fhv)Ff_fa45pg@Qe$FB'G`fgXlpTY*3h'QBc`?+tIqjIQe$Mj#Daj5q.roJHJrr0J_&X/Z%bCUP(snUQe$VG;]bocMcstx%)tv<J_&[cr=c$Y=ath=9ig=%Suc"
"t:+Au#PX]u$IJ_&e@4Vd%it&#&2>>#t7pr-i++,Mn1FA+*`$s$@tYhL%.gfLHYjfLghiS%h'###5.Is$Ew/6&UjlN'f]Rh(vO9+*0CvC+@6]],P)Cv-ar)9/qefQ0+XLk1;K3.3K>pF4"
"[1V`5l$=#7&n#<86a`T9FSFn:VF-1<g9jI=w,Pc>1v6&@Ais>AD:D-#^uMRXSUE<a#hpta7m%ScH`bld[nD,glWSdg/p?$joRG<LmI^V`?X+dQWb,C^]%(##_ULqV2aT_SYNREU;T9JC"
"Dbw$Tw2fWV5%LdHE(&/GFl7`j:_O3F]/LcDC-'OE]rM3YwB1MZ/fu5#Oica^<$D/PHFurRwUb&#)f)'Mt%;'#,+ST%(dMiKo_Cuu/<)2Br]?MK*=FYc62oJ)FBx],VMQ8/#-s]53&Hv-"
",JVq2e]u?0<K>A=0tw?0q8G@0?L)d*JZX>-*fVA5L-;#v](>uu4X+41(DY##Ic<TuB_)3lEL#L1EbX18?-%##FE<r>c%<X(Dmk-$A1g+M1YjfL;G]'.GWajL&@c(NSdb&#?e)AFahL`E"
"b'I]Ff9exFNVs.C_6auGGY4GDV$&;HiYMfL>LZY#jjg34D`85Ah7$>%8<.J3(]Oe)*X=PCUr=R#26(KC/x.F.QhFQ#uP2Q00Yu##@9K:%x7P/M*90/1NM%n9]G7TCDKTh#;BQq;`F;mL"
"9<p%#Kej=.g>l-$I6fX-[BLe$<=6g)bj5pLC'Y%$-9d&T6q7eCqWc>uo[0I#$4_WCxA'tLwFp;-QENfLmHF%vO-Pu#wtnm-lA%I6@-vM(G&9f3b*V.3l5MG)27E:.%G3]-9n?g)3Djc)"
"cc``3s%u+DdB-_uWZSW8<AE>].j,igZi[tLdbeG]VGs'Ml8fR;fIG3;JqP<LK<8vLuf</6BBXGMQx-tLk]W$#r>$(#Pc/*#WGSF4@Gx8/x)Qv$Lap,*G'k?#L_P8/k+;E4Rq@.*rkm0-"
">ddC#QTQ-3Sm?`0jv56^kC@tHnr.l'j(A[u]A-l0TiiUddD'80*2n50KPgZHnl.l'J#+.)Te5W)h4lwL3N5l$6PwqLv]G&#,F9D3MR^fLMsZ1M7,:a#X0fX-uiWI)>+`p.vg'u$q<I9i"
"(44]-`u.K:Qlep0MgN-*iR&C#Apb_-=p1^#->8I>1w?GDnX6Yu7Ebd*,X_G3AZfB5,F(80A6,9/:.^9CEn;_.8dxM9pF?>#g(5P]kj0_JO/###vtq8.GdST'x$g+M:3Z7et3irQ6]###"
"+$fF4cMi=.3WP<hd8x:/4rmoJdE<RD.#1--3Vu(E%6tK=S/[qLWuI^Po$DN(TMrB#)^B.*dZ'u$_JlD4RJ4-7w:dl/:jxI_kHOM'.S$?%Zk_a4k`qR/VT4J*rGak(bqAQ0BVn&4;;)h1"
"A;fiLo1IV%Z>29/G9vGM>>io.RLJA44b6dbPY0i)NIHg)6A*'i[Za0/b8_ahpV;kkM@JfU7#>;$^#HktW//X9=S0S/rMs@t3dxu#2g%[-vck@t$h]%b#V+4+Pc@R3q@Ma4/c'lU+$9;-"
"89X7/A5YY#8Yh5Ma=fC#F(Jl#XI,oe$E_CWkd/W-n0hk+Q8###2ctM(M7R20^57V64v'8%s&o'/@@@SR/w_&#Gh%@0l@#qrS0nO(%X)22NH7TCjLs9)+-2>5&Ni%u46+Q'Afq<1JA'i)"
"#jic)MGg+4[h6g)0iC%6,rRv$BxF)4TfQW84FPG#*`.*Dx*+&@9CU%tptMs-wG*rL5p-:9v-i]M+F4jLFwK,3?_#V/r@=F%g`O/Mr]l]#]3B:%@I3j0x&9Z-B:*Y-dUi[k488N0Q[xnn"
"Wl,X7`.oQ0xc3Q1<5]$/PWnJCgums.W_7'5/Eio00x[@-xA=+NZC8F-%p8V-m%$m50j7d)8Kp[#&$jluS^YdhScj]+rXeMuTeMnLF,N2/Fe[%#AI3*,-e6g)YJe>%0GXI)c9j/V$.Ym#"
"T-o^o$==5MD?qo-Cd@hlj&l'6074WJZ$<$#/u9t.UF;8..M0+*@0WQ.o#fF4BEb8.?]J,3'+*<6:2Cv-:sPN#kd9]=)f#/Cdbx_W>--p%Z;H21/m0A@>v5l]@x>D')kgb,.Is?#OxwRC"
"dh$J=3DYH=8SQ=0xr]xt9MQP&[w>6s-l2T.BV5g)]m9h$o=dY#b]#9@bDsD#Mj+[M0fL=8.Z/w$n0taQ&7FGMk',cMJw]%#>hg)&);YB],`q?^*U^:/w,sv$'.@x6YGh.8RHda5=meV#"
"j?OZ6[q];/jS=/MZ7VZ-SY_8/_W5t7>@R:1#HZO0xS5t7g78Z1'-e#5S6,9/g(vM9d-EJ:i1<9/*j^s7,F(80TvaG'Q*Np7k1$0)5QCD37l@B0SZ'u$iF3]-]Ewms#BOZ6gH7lL`&Z,*"
"dIT$-tRZ$-^:321=IrH>.tB,)mGq=><MrH>/R=SCpw,E>sD*igC#Hq.mcCfUi][dk/HF:.&&,?In*#UCX+XdkZrP+`MT<W%f?-IMLtr8.mI'UCR@p:d545fU%U:5#H$l&,2Tf._1N<Z5"
"*X'B#$vD%$i;/gO'4^B[2/;W#:[S3I._#68jcxSS]w8YcAVfA#TOrM(%uT^#]<bA#[h1p.?Nidu=Oel=UgCD3W=:8.YIhfufiTJ(`3b,bd^8%#n5K(/w#9Z--v[p0Nn]:/KIBZ-,CS@#"
":5w5/>wni0s'qVCOo7PD/Gd[t.P@21_h,I#iNg)X/:eK3H38[/.3TWNekO5$./F3.<P,lLg7oR9%wH#63-g0>Fe&Q/X0fX-]p*P(nl,W--)`$'_mr>5wl)`#qnbHVnr.l'2@Z$-u/C21"
"`N?ip@NP$K=ijL>oO+O0=><Ek(WwF#:#+.)CUY**$iXjLkVbM.Hh,V9w2[H=tuhI_tms;-aq#X$fNsV$:cMM'h&^;.SW'B#I>WD#7ZRD*LO_fuIfcV$Flak'%h@],o0HruusUU6<'pR/"
"R,,d$Evo=u[Q>a+A19'fVR(f),39Z-q:-x6#L8j-]P1I$ILD8.&>YV-n<Vk+l<1`-9N5AuigV78*qGg)>=M0MTa](<E&`;/jJ19/e4jFVKi?t-muK^9sR6hG0^b3FF;#RE(sdND+p5[-"
"UD.&47%x[-&^,ju1s+,HdQFeu7%1k=ME1Q#7MVu3d32XBeA'bGA?dATLGc;-i69$.]DP59]kJq`?4eV$nVs^u,7qF?rC7EXfI#N#PqN%9-,*3Ni&*+M2MLZ-*W8f3DR'DMc#%uLJS/[#"
"moJF*1RN/1B2v[-`I*onTn0a#IxLp./mn`*$^Lmhhln`*04s=-)9/_%XV###qJ/[Bwfg$BfqkHVx8C(Wpp$&uA]asf.;Wu56VXs.w#sHMi3jb&<ACPSvxhc[pn^7LAjkeuvt=GHY@stu"
"GxY6=eVdMCd^[6DogP</=$(,)emwiLQmrA5<R`GuoH#W--rre-P#<5A.D###pH6^46n@X-4^]tu$/UBu;6q^uEB@SRY#U%FagB6/[rgo.-<3jLoYkD#v.15%<^*P(7sPN#_VmIU<buQD"
"o;#F>o]nJ.gjdoJLxrI=g].VOvL<$#?f%&4Bc=u%rHr8.ML,T3-:FGMwc=5/:PYcCKhRJ1QI_Xu2X5Dt5Vh;-pA3+0^3Ok#x.&QCQ<uwMKJXPAQf?K)$>V=.bpi[%jax9.HFIw#BKc8/"
"Qx([Cd>WD#9B:*d,C$,*vr;'4j-:5A$4Nula:ViT'SqU.]?)i2-b.e4VCFR-H9mZ%r-YD#Zee@#7.5I))E6C#ng:V66ssO',<a.h/K<O'$A7MTt6H;-.qh0(F`n7eASR&$/og%%#2ofL"
"D]j$#dMOV-vu.&4h69j0m&l]#3qOA#(_Aj0Gfq)4mXfC#h:hh$md*acE#3pJOs4k+`druKDZAp7t:hB#@%x9C_3%qC?bHp^=W%iLQ;H)4A,m]#peMs-ZQ3R8n:N`#^UMs#'gep0hiY98"
"YBlRC/5Z8/7;PI:B*OB,E'0%u(6>9/%/d8.2L/m&?'Z;.f6h?T`CI8%]/]]O<L?s.NDmX$)M,)Kh?<**t2%.)/BOI[J-Pg.:LF1pBuD#MnPp9CQa/a+3-JX-B,&NU9/'`&A;1<-TmC-/"
"4CW:.i]Z;`jE$(N5ZM3R2<u_NmK-2&nj?D*(7l)4nJ^6(eSic)M3P4:kk9^#>C;Niv1V^u;3gg1m6TLp$].,]?$xRCIW/gMT/Wn'HotM(iRG)4G)6OC_e45A:W1?#mYYP&6>fA#X.[K)"
"`5qB#UD.&4:PSj0RJ))3YSYvC#EmH?m#1k=O2VYK+cYJ#,TH_uSU0;:v@'bGBIb]u+pPwAZc7',f$t4o>%//(76JT&#eV[,FwGZ%p1f]4Ij6Vq<%%P&)gZr%n0r@,JDGu#LCkA#ucQd)"
"-W2O''0p@#t+,##`#j>$GJwA-/1nMMPsID*KG>c489WfMwP#x#-qW<EnMWOa8P[R&d%YFNahJi)8`#,aHqT<AY3AS%kl@A4e2odup,DT.v@uu#2d]$&b0e##OMOV-(hro.b^A@#1LO`#"
"u.4sO&PDoIO(4X#221$[$E_CWUf'p%tKm[tpQ?Eu%5,GiiH;Z$?e^-6P-0@#dE1,)uwdi9@g_EOFE.fhf(.Q#,rJauWM8GN2uQlLRuxbM9)JT&j,KZ-Xt@X-8(OF3T%Uxt+.Le#$O8a#"
"xtLr6$k6cVq]4Y#*L,l&b8###)k@+4VRG)4^NgIh+x@C#iHp=5hNNR'[NZq`*<u(8I6x9.f,EB#nf5/1l*QC8uv4g:d[b&#5W%.M*^)u0k[UxtI5(KC>BfeCi#IAu[quL9/vH#QfQwu#"
"lS@[0.$tLu6Dk>7gnT`,f-OxbaC?;$jc;F3`#++N@:>05jt/XBlQ/W-W+ujtW_fi'Zpr#$Sl:?#]K`M%P?->YVvVW#[a?(u9.H`,)C'u$xS42C$A8cMkwDS%.hqe3ZxLQ9='-g)cTx<-"
"t(u4%nMuveKPp`(u/5T.dR;NCP*bc'd%39/lq`^dV:I`,gQsj&vkY)4,m@d)cCK$-.de_sCcrH>=DfduqeN<[Rhe8.-E8uSQ1$-F;E`hL$rEb3Ni;m/t(4I))CuM(j5w*0uF/?10t%t#"
"o?pZ.*&4I#tLE32oJ><.vgMau:F+G#S_9'#^w7W-]FO@RQdL]$s_-lLtnOe)#cUxt$$G]b%VO&u0Kkdu@]b6;1jiq2v;m&Q*$AX-8t@X-Oj9-WOw-S#v>P+VgwXdPjKJL(Lov[-KOsG;"
"m]?jUtWVrZ-Q?E2Y2-m0$f5xteuptu]wiE#sOaMC^.Z58.8Z;%?,j;.2K4L#']Uxt+Z%l#[(o+%L_.W-iLoEe;d;F3L*XlC$n2f%St0DtH&>6']b>K).?3jLW5TF49<C^#VYRx,.sOu#"
"Jm$UCiTt.)EtbKE#iJ+MxmJk9sn;Q/@I']$TEW@,[M8f3l'*[C<2?Xh2aPY>mk:[8xd55ASrf+;8cx>;P4,^#o&5a4i6xL*RTv)44nZ<McriV$i(u7E1b*W-#QOw^8P4B#HsXq.U,>d3"
"fAxiL`LOD7UE2I#p_rH>g3He#8Q@C#$M%H##ps@=.[_H=j7T%teRY,MY/q4.hPO'ODto[#3tEh5Pv3I#Qg;eN:f<g;x@Fm'smFW8SO%F%`?$>%0h:*3-K^lS`VmIUeuU$-(<(m0T7@#M"
"a@EG#'YW/1Le08.?p(#v?=/U/RBNj$jGP/:+FDd*$IDR8HJ'N(+CNZ@rd,I<#x19/;*)dC>nU?I5wtkoU.3Q/EZ`E4vs2&5BF8q.%F9D3AHV[.sP(u$RMi=.%)TF4_P8(NgvEL'>cwZ^"
"VEMQisCUA>@&wJDZ#:GNFq2T/V'pdSYI>l9<b#<.<TPs.fk%E4P1&3:@TM)b>MspufJ/O(';Yw/:IKd<9i'n'@%$##J0fX-(ZvJ1lZD.3o:YV-dZoA,<RqWhgY8f3^5C7n>'N,>xmAQ8"
"5XPA+scYG]:6$UC?g72;gwCO;_2A$S%3Lb%/n9@-ZEa#07.5I):2Cv-_2pc$+>tQNLPGZC8Z9o[/XQ$8/=Z;[c=]u5a;(T.i^921m*5[$e(R:.I,7qHohjV._%*)#P4q1&oD[9MVv@RN"
"Z+$XL%pCq.-b`ku<kVqMQZ%du=ffK<>7fC#.+;H*n31,)@Z=.b-kL`NMonsuRkeR(h](T.*j.-#1&KV-RG1l/Tn.i)ldH)4>,c;-dN9b%/Qpiu>1YSC,LF^Cso4+r+(5)4ZH43;JMdEu"
"R<ra>$3032:tYl$dpdA#Y57B=:gwA,wMM+=>Q9jCuV/T=ft`G<OlU5%F8q_djqWB-#57Y17:b=.OXkD#lB7g)'uQ*RXEW@,Yw4a=urd_u#.`m#]?$j8*ebI>rQ;.q^IC_Q&$Pe$.o#gL"
"pPJc;,a-g(k=^l8MP0NCE,;$u#v6^&bu###gaf_%gPZ'=n;u`4/sLm/cE9MD)?>>u)RSZ$UA@_#EY,cu0NVwS@:YH=xWc]u8%3X.b-lc99Ol2iNIdu#vtMFN8&+F3(5Rv$>NjJM1Jc)4"
"+ZIjUvar7[+VfX>JF4I>mjP7et#$Q#mr1^u2F2K=8&1xtk;(9.Hj98I%u)W-`WmB$8bkD#9,B+4V,>d3J]2m9^>m;%2'4L#<QpiuH:tB,1)b[t42XsLG0A07Lo+G,$?ZlJ$s_lJwBuMC"
"2E'LCx.)O9e`[=.A?<E>DdZ&QG]XjLrA6##M`e2.CCr/:;9Ha3r$eX-'SAXu_e`S%H%gh(;9^S%Dr+I#xiQK#/v7OCEgV-#_,2>5aA5/17#>;$,>###S75%(Nw*2WRR?##^,>>#A5_W."
"-Mc##R/:w-w.5jLNUP8.#c0U:,%XMCGKUv@+XPgLEc@?6jn0N(9,B+4_T/i)?FlW^LTfQ#$BDO#qIb&T6=T4Mv1#,MY9MhL77>x7G[=D6*%+`#VJL@-c<<Y.k0@aSx?vpLc(8qL#bl]#"
"u)q^#j&Fk4),;:%hHuD#KjE.3#G#v,?%<9/Me:s)CT6T%JauN'<I<T%VfjU%q]%v5Cs0W$.Pc>#DLnl)7PP##w3O9i$2ffLu/gfLj/d&#Dc/*#/$S-#P+:8.vTG'vqVGA#4(XD#a-s8."
"W<%gL<KihLQFA,V&N@jUur/v5tn-i#^$79*=5n/1md>`0]U)'Y_F]C#`/N=-bgVI2$E_CW-_S*9nreh(K5bI)6R94&bDbYHi=p?7dk_=#U3=&#O,>>#Mg6N'TCh8.Fc7C#H*fI*DZj1)"
"V5qX-.Va)G@FD'<r61^#36^['e-;$<-'G&YwSs4]W_>'#U4NT/$s%&4t7Ih)n&PA#MN[t)AUa5&t4Pw$.Y(Z#/BMG#u*>gLrA34B?,`v#M6b9%=S<p@*,@j09?65AU]W]+^kYg)$6BQ8"
"QM;h)P=8u.Jc.Z$U1UF=d'h#$K*M[Cul_5/,OPr6Kc#L=)eKNCXk5UC>nAZC_`)30#DP##M3=&#>6rB8.W?Z$6otM(5)c1)3TgMue%Vt/4D35ApH-I#[8Ak(XAfeCm6VZCaSRcMjnugL"
"Hvnx4ut.JU1a=;$lur'407-%5<$o4]%U:5#Z&6>-V%I]-a^Yk4bkKL5;m*+74j&(8e&<^#cHbGYwCq=u=rii'7vK2:)H,H3#=9PDXv+W-Z>I0NR:-##T9LX++IRVQJ;26/^kX=Yi&<l8"
"E(Z,EvV%&+g&a#>[+]]4m7%s$ikkj1]Kj?#n_Zx6E1x0`q/[H)P;3:%I7DZ#P$o<$RtYnAVwC0(1*aI-H(][>8Pc>#B=`Z#H%S[>3;###a7a`#kX8a#dNc##NpeY/)vsI3sRg_4d(%b4"
"?Dsu5AB:a#VD%@'G.,Q'Gp?d)e-DU/R8;x-?xtBG5Eu;-WH3L#iBPN'F_*X$dq8e?Wh)v#MTTu$HlLZ#=7ho)#%X-?3^=Z#/&$w-dn;.$Rt%@#Pj>R&rUQ68APXm'tAu(31wS=-`PeY%"
"X1[s$+f@C#.#?H.a^D.3LP`;7lXt_$=k(S:V3]pAs'EQ83k'auDsOw&r/c'6]xCO;Li>E5W=$##^%*)#T,ls-JU@lLrodLM=#YI)H0pi'vPQS3e1.>-1koC%(`vQ82&#^$-FYhUs.V>$"
"*%vN>G%DD$;G%]CkgB215MM]bgX*6/lRpU/MU5[8w/AT&d6EM0aVH0:Mur22;EO7%Ue.W-P].</R4Nq%P9DO;OSJaC:bPxpYG:;$A($##P0D`s1.no%A9GJ(i<J<-9Tn#%4^<h<ddS8S"
"vVCk<[KcD48HNfLq;nx4lY(JUtu6i$)(3:.Pg;hL9:wZC=t-DW%hQ%t7(]20ZoXxtcnb`*ce4wpA;Rv$m&l]#Q9l>[8f*F3IO#<.>1w9.0,6W-SO:lMxMsKCj.5ZCerijK7>7h#2kh=J"
"9iu+HR%Cp3Y*opuR&W6&Z(dlL.e#98`S(*4fekD#7P1gMbEE2MQS_`.MB7g)(V4H6=<VG#(dg4J*(A^JWV5t7v<Ie-5HPA#^j5m6XsQ*0MPG++(&pC+UnI6%7Xgd<lZb&#qpZiLAT'(M"
"%F,&#b$(,)D7w'6V^wb4RJ))3wRoU/?_#V/Uen5/#3m;%T^A.*H7XT%=IQ&8g``4=LcHP9]iE@KO`^jOak=e+i0Q0jQRU5DYn*^@mE1TL*?dm3h#jm&Zqq[HQOGL>'.U=SOV]U9OxXR:"
"$/YwKvCJwKu,@D*h&^;.>kt,%)ddC#NIHg)0']T&pPg@#%vw$MP-A8%B(,.Uvn?3UG,-^:rl,I#QnxCM]Es?#5F^EekPpKW*F5gLF2x9.x2k-$ej8-vTDYYu'FLn#x3,F#Z_vp/P-Pu#"
"$Zt&##NZT/0VKF*TEW@,cXc8@JTYQs=d8pACs]G3aE+W-ji:[0r9P_lkJHVHfGh],i/<1pfU$*5+hWm,]D@,)R(2au;@ia#2<F$%/OF>76]-&6KR9qL(&=/6:0+Z6XAkdu_pp0#OFY^#"
"#73h#Vd=$%#a0i)ckY)40rPHlJq=98/4$$$5o^+ieE.F.<*Yc2<@9kX>I#E3?@i?#a%NT/Jj:9/xH:a#j?]s$ILN,*Y(Ds-r'UfL90S_#mh%s$'K8f3Q/`:%S$]<_`0ptRr4<k'D_es$"
"&SES&_N,n&c:pB+C-sH*Rsq,)J@2Z#pRk**mx%5'wbhs-Wln;%mq$=-<emxOQNp6&qi***eGQ;%IH,n&.UIX-*RW6/or71(I1Vv#nkKN(dL9J)]/Fs-V8;>$&='H<Q+&t%@%$##vufG="
"#+-Z$luoN%/VYV-o#Ap@OHO]u8sDm&SP-A@CG>D'$`Vd.fKIc9dW*HMSO9P#ZXx5#^d0'#ChiQL1V@C#3xDX-$C.*5rEn.QqULM)'whvRu<@>#,tio.'w(2B(2###)kH)4<u.Vm4u[J("
"/_mdu,o<vLc.6Y#+Owu%vnHguxZa)u#30p7;Wo/1L=#+#4%(,)6'PA#Ynn8%a8qB#s^v)4XC[x6S4-J*hp?d)?PkI)*AWD#j6kn/3t6l1/A[&4/sdX.$DXI)$4$A%CMrB#.$uU%]39f3"
"q>Sp*oMHV%Wi&+*vgKD3T+Mv#]D7-)6>wR&O;nH)VE(g(^b@W$`[PC+;$.g)3`1Z#U?+9%RTB:%@1[8%Xa^6&20nxO)q`h)[gT6&rN]/1l5dN'WTXX$$@HK)_?+=$SQGN'dHFx#m])o&"
"a'5Z#67RW$L=<p%fie-)2[:*4BLes$^)2>5+EjuP1Zxu#$*5>>ZqB^#Ch,W8JNO&#c4B8%KnE:.s:j=.,(l<9;Tj=C`#Z>-Xpi'#_5YY#Ppd(#fE9D3RiVu$k:vj)4Ub`#dE1'i4g1p."
"w7_ahx#?[0-/ED#NgxvLULs$##[5<%1jic)2'iD3>+UF*SrU%64e,Q'eUYV->cgN(0A4K16A-[-6UQ@tF:+=$FY*8&om(v5FqE9%D;>_+N7c-=-Osa*FMP_+D@9+#D%-eQBrB2B?=gr6"
"SRH]Fi5UlJ:h$>P]La(WInwCac%b1g)sGe3j?lD#2h,V/VIF<%.`rS%Z=@8%On?g)pW^:%_Z-H)4QId):`x_4H/5J*Cl$],b-ikL`bxR0iKwb4_i&f)8M4gLeVjfL9i?lLdYlS.LMx_4"
"`A$t.]#[]4(Yl<:32+E*2w+F%DPxS/<7$.3f%_.*t:7<.YFn8%GjE.3H6)hLhE4V.&7&s$%Ols/?XgU/[5MG)EL@6/@<Tv-FO@lLdfRI2k1E:/R[K]$rL4gLDUkD#.SIdDi^X=$O&n_P"
"OqX.%?S?v#g29N)amMC$oG5m/IKA71wi>O^]Oh;*=9Hp8mLFM(77;N9LN&w62KcD65A0B%>,/aP]ILv)qNJV<++Q@$%@+b+dLm*5pE5/_uj`.WB8NEG3U.d)V>Dk'PLdM9sw?;'u*NM0"
"gS2O'j,?k*Bpj1)b-B.2ci0n',6-Z$p@V)F[cdT.=1M?#hCOi(N:`v#ZKG4'W50k/+0J9$]]R-)_mpQ&r&sl(q2dV%$#4Q'qd#;%Wn+v.20<d*3)BK2;pk>-)`^F*xX9'+bkt;/'gcP&"
"DV,r'MwEp%+=+9%#>iV$MQ,G<ja[(+Bn7T.Rhg]$3>4T@`THX/MU.*+P+^5'?r@Z$TKDW%t@%]G9Hi'HB-GD#/ZW>5[(SxGXb<Q&2IVR:`qW(5W;r.;]&$5Js#KW$`?*Z#kLcC+KfG>#"
"cVurHXIRW.O696&$>=Q'T*@AI[T;a4g'oD?u*CB#[w$##v'7`?6=i7B8N,<.;^9Z-p+jq%ER(>Y*C2[8)oqH>:p1?u-mO8(F),##S'h&=UdPr^K%q=#g?<j$/'[)4n[KqC$g^S%P)<5A"
"_#qTVeYq8.XL3]-Whe;-?S2a%=p1^#E%[%=N-=W-=*/D?d8Y<1$K_(WbLZV$Y'3:.rn%72Cd2fD]TR==_,2>5tgSiTGvFm'0Y#REO3gY-)L91E+N*Mg=Q:7/^uv(#@[-R99PK/)<6KX-"
"^fC_?(O=S9sSfN2bQBO&`l###BbJ9(:i*F3hB58&C`o`*]1'Z>b3hNCg1NT/G$6]+]cPiC=S?T.a%*)#2&fd#:#M$#jWt&#trgo.nG8f3Vq.i)6`p>,LX3]-)gTc$4o*T%Jkh/)Qw;?#"
")wZ)4cd.dul9n.2o8Rh(-3e8@EZsH*ggn0#8;HUpa*]5^CLen;`pA_+CMUg*g[n4=nRQ_+0eC?%@ru>#JZ%l#1?4WkKSRY'N4]20jtuM(I^Bv-%4:EQEhg1(W/8'#^uv(#NV7+M4#9%#"
"tjP]4b/v[-TbNnL;t0+*KIBZ-L4xC#)7RNUpiYA#P0.on16k.=$p&JhOf_*$E*af:errM0D>uu#'d]=#j9_hL=Qx>.b#O1)SW'B#KDWD#7ZRD*FUo478h@TiER-K#n3v(+^EKq%.f=2("
"k#FSR8#u7%$*IY,c&cS/a2n)*qq[o%%uYGM):iHMxw?AOg&)B#b3Cx$,WTrH7^m^,n&dj'%RV%,9w%<I%4Ks/VJIU;W33-*r&pR/JfUZ#X@upLgK(DN[d93(G:$##PHCD3+E'j0VE/[#"
"l5Z]4qg8x,WHlj1?f6<.[@i?#I5/vLAe0xt'Oh]udAM7:vUp:`sPkD8W3>(fqL$##$n-Z<+%72lujn$n7jEU-t7@F)77P^$HoK=#GF.%#>Mn/(uYnF#0]#S.].0cC.Z/=8'[_%O#JccM"
"`Tic)q(_$P[0gfLi4t=c^]xS^q(p2/<J[9C*EIY,k])T^&KYN-I5F;05365AKv$)*eed&679SX-&cYV-c0;hLO2s3(LW`cM$<_uc8'0W-H^Ta,*elUC-pndu,:,d$OdRd#.ugW0CPUV$"
"I,B+4C2#6B1N1C&`2:T.YZ'WfvpC`$[+cJCtP2N0KckqWbE.UCQt59<=.N;7&2ds-;wMAF?h1T/nR>JCe#MB#REKQKPgAYCfjU^#)D2Hu]bI#+0-2>5#vo=uIwh).VVF,Wes@'7a#gK#"
"&o.E.H`0`Ewmt/)Zt$##j8a*W5uM^8?h1Al^I?KE#6[Lg/IH#$ZRe5/u7>##-j&kLVd66%6%?mU0r]TCoN:$Va,J6MZWe@Frv^2VNCHu#)i1$#?;s1Bssr]-6n@X-1mLT/RuED#&)0q#"
"cwjT#5paZ2h#PNCnmKp.vqbMB%-G^?bLwA-e$Tv.?3Cx$lOaDunQG</I:>055Un#MThuW/OA>vCIMH%FtB8^OJ0liCV(%W]B^'k&DWF/*%5pr-M4Md>VRD8AkLb/NS1$##NjFs-GGr*M"
"B<W$#Y=d^</a#uqnpWHl-rgC-WrAZ$**2>5RU^^PGw#&+l>,<.S5^_%#OL,3#r]/1'M3]->/nS#Ipb31r6^r%HVD`aWlC<.v1VW-`=@W8L=Zu#R;bJ-G'm@.jn0N(8tf<-go<8*Rs#=-"
"OlNo*q+RX-)b''Qgh'S-eC@>1=R@%#H,>>#b3e,*2.rA,O0Hs/v(7B?1VjjCE-Q[-[^iuKOs=GHJB>vCS8'7D6KL#$ERc(.R2/jUV^%'71&q^/Rl'?$+K*dVuX&%#ki-r8q:'_KmMYK*"
"/mL&T6YGx'P]vnVQ(^%#`iPlLBa<9/(6Hj'A<uD#=a[D*3%I=7W?j?#h@>M,H4T<%Y^,n&X%pn&JgCk'F0Pj'Q:9U@bB`K(l9vkhWRET%Hr.[#BwaT%8_8m&DM)?uUR*M-xU&0%FIIs-"
"Rvkp8ukv^TCBSHl6j9WMl4N6MJqRo%`g$6/B5SY,O0<`j<UNP&dR&E#%F$`4`W^:%^L]oS16<aS5Pi#:p#1WM2=P<S3?W&TE6Iv54535A]@PV-ML$##,1#;/SrU%6O6$`43&'f)@qvm0"
">%NT/qBhhLqbmI4,>@<.uiWI)*sj>d:6Q-XKNO(7`SAh<#EmH?Ki]].vn<ucv;<lKxrTlKYvWY5r#aTT3a_(+R#w5=`((T&-lrkuN$opCij7UCZBu%=QFRB&]dZ9M8_;P(J:Is-DRI1M"
"*Xi8.Jq-0)b3e,*lI5G%B^>]u[eYat@:>05*`.X-Y@He4#Lvx%jx###pI>c4qM3I)rLC,MdNl]#L*$30TX)P(FhuM2A@TJ(S;BOK$9fa=rK*>?xxs^#fX49Ufv5XBe0xr-[nAqqmn%r8"
"_<.m0-A*7ShUv]8k)lA#Ff?^8?OYD4KKV-+]>B88n%dG*#ZUs@)S8b?O`@2CbVOPTT<?/4I%_=#1Yu##tx<r&<J>c41p<7'BP#(57n*r&M7$n;?^.E+lur'4jQoW-)MLNaQ^rA5_>:EE"
"pBtR0KkaGmr_7'5tT?D4saFglgums.]rJ'#ivnd#,d%-#F$v[.GuEb3U=.E(]rV`R0=,Q'9I'UCO4@EH#+:^uCFhW-qscOoWT.:/L3D%(m-&@#.ZOm#@C.cGtI6S)mu.-)YNMQ1%Di^#"
"v15##MIPnA_41B#rNHH3qT^q.XI#N2L38Q`>)GSR#%ft;a3Cx$7#*NC@:>050jviC&)Y8&>Ki[--c:?#:%xC#B4vr-_CT/).vfk(ASs`ubmDsu=^Dj(_^af:K(h4/JsHL1?%xtB.B5ZC"
"3s2D#6c.NVBC'l'l4Zj).ug9*u[TDFZ;U@PG`]K)S;]^H&Ji^#&c($#A4i$#75I/(BvpVQ8EkPCMX,>Pi-J6Mw/-D-v&-D-oFK('7_.SUWC+N.GE4w.,(Tcsn>@d2`%*)#E=Uf#</`$#"
"MXI%#_ur2soYYA#Z0fX-BVjfLGELZ-kU@SBKap`P:VQx=#paHteun@t7K(Ru4BC(Cv,i12c5IQC_VHtCf_3.+?D%e%8b5Z-'qWBI2TF:.I=1582Z=Uh[CV$-I7+jf:J+V9@:YH=9<@<."
"nY1T/^rKcME.UxtV#l'&YRjl&&q-'#?(NT/weW<USDl-$@UeX-pi`37a#gK#3>F+&8v(K$FD-)EMu^>$hXa`8a3Cx$`NNmT@:>05$]5`8dKMdu/.vs/MXI%#^3=&#$r4_$Yg'$P+*A%B"
"k36,E.Y@AY`U*X-bjNOF%S9)N:a5l$bwfi'*lqKGYC;#PA=:bCr:lV$EQ6-XLRDV$uSa^#<o###hJCW8x+*,)fGgI*<ax9.6&2SKIfJqCvqbMBax]CW+&_@0muQS%$>V=.]:@<.3+B,V"
"w;M$7YY[`#+P0XBd_3on^bWiqscs#$:i###SW4?-Yq@()RIM>?P%*:.$E_CWDM2:.FRX7ed$a2(#jmaM)8W.NX?9C-fBqS-Gsmp%L^'T.8m:$#k^2i%,.j;-$v^%)$HSF4QsQ7/8LqPD"
"@>hwIuK5_-a9E$#lMOV-QPXZ/4t@X-,CS@#^XbL1`eq91MHuRC?;7PDR=('?cgr7[r`:W-8.V9p2j-.%;/U9p-bR.'/6*#9),3X%#N4-7.-:lhY?KT.HBoi0mN$h%WFnQq3W8c$er'gL"
"'?I9%i-N>P'q=c4m9U^[Z0.&/(Q#(5k^20HUp.HuaH2).OGZ/;Q5cA#rf-'mqAMQTWJrq'FWf[S$nI7&viou,H)b=0cZ@c*Ue/t-_e<?M/,af:vIO]uL]kd*%Bh=-g(0P+2)Bl8XrcG*"
"h`pp78SNs@'@Ne#(*#>-3U0W$$Bhr.S-Ki#9_=tpR?H)4.IE:.F3k-$0bNLut)OLsPI2-unA@?'pu:8I@IXm'fh18.Y:a;._H7g)W@o:.'@SY>xgf=-VNBZ$8xNLsfYGw=Rhr+;?atA#"
"Tir[A%Lm=&1Bt;-FQFf'<v(K$]LTK.W7w(F/sp9Tmk*0;qX'^BJx?=->,1A8NjO]uBvO9;K9vG*n>E'mUHnx/sv@+4=Q.I#0wF$/4HISR(p&/?S.X9Ci#6N0qf]=#X'+&#$f;@GQ$&?5"
"d&+Z6qkXI)^R=F3aYD^#TPIx,,g=u#J9YSCm1DQC2[Z(7]Wj/u]]ki(.*QV90axF;;'ft8S[3krl30W$;<E`s8CX&,40w/Z8c;sQ$vuUC^ClF;p/LU%b`9x[]b$##ghW4o8(X`AeI1=#"
"nNd;#EZC5guL.QMYI>-rcBw4v=Gq+$P-%bNuwSfL<[8wu(2RW$<PO;.b-u.#]=eL,Y.,)kMQx*%F,>>#%i0^#UXwm/51ED#pA&&$B6T;-S5T;-0RP8.W'*)#'lhiUFLk-$*r#;#VHDqM"
"7aLD3xxVGs#sQA4@$@v$o>E_&..C#$#jN_&?XC_&qC=R<8L$#,.Q1R3XbO_/xXb-61,lw9u`xR3e>#d3u7ZD45jcG*QA+_Jg(u8NtMh`Pm_-2MNM-X.IE9>$GvrqL44&GrI$8R*9?\?-d"
",mZw'72#F@<#h%ME5.;#@)NbMk#uONoc>W-Oc?FIVjNwK;r@FI%M=F%kpq&$S9iH-S8x/M98,,MIL9C-2@RA-'.[a.s@uu#f0X_$>gv#8#]'^#K6D^##sl1M=hHM9-f];6]8g9MelO8N"
")Iu9#PT$W].:=D#7=TOMs4%&MipO1#D*`MO6A^rML]=`sL[/R39DM-mDC5_A`)]Y,lxUA51.lA#e3RA->OT_--.h--XG`w'>q>:)?>dxMm2#,M/:Y9#<s0*8`ufG3^,7:Mo-RA4`19Gj"
"w0f--=I<&5Il3dX1+](#.bt&#NrpV-Rb9R*O;#q7'&#d3k*l.$,p_wT[.mlL2cpV-:0@_85IQ&Q?:#-M<&rtL^RtlAsVR/$4%e+8t0`JsNreQ-?l1p.:0wFii?7x9PE_w^MsuI8]mdp0"
"4C7Q/$,>>#qwL/:d*%bk-c68%eTWV$j&6`W`)Ke$QH1/(AE`7[FF,W.qbQe$NG_e$:%N(a``UA5eu-^5,eJ_&:c6f_]iQ>65t,p8,9wf;DoC#?&E;R*dvc=c.];<@:/if(1AI]4t&Wg;"
"c0CA+pG*XCsaGJ(IfH_&F/_e$g:`e$NA%/(DWc?KvwQS.x[d%=o3MS.2#=T/,#8lfcu-^50LRe$j6PX(_x_e$8M]9Mlru?0?uH;@U6M50^hY2_;[_l8wFg;-nAg;-d#;P-<=K$.^]>lL"
"Iw'kL[5s7#3/N%v`nA,Mi8V'#q_`=-KV3B-okUH-AZ`=-0;)=-@fY-Mv>`'#_XkR-Tx_5/]:q'#C8?&Mt1i#v[,T,33$K_&X0g@bW3WV$PVPe$,6^e$gGlF`<s#K)2RRe$?>V_&wE[%F"
"G+O#-ZuPe$K<NuPTpS,3=tRe$V`_e$wFl[tblhA5B+Me$+c2@01_jr$hLa;7D6Se$_7l'8B.;F.B()F.u-Q?gJc%)3v,w(kZS_A5)()t-jO8(Md<EMM7Lb%vDqcW-^C?L,&B6on(p0#?"
",,hY?@uH;@Sm]G3Dla&P3,v(3F9Se$V`_e$d6tUmaiq]5aud>6*_J_&b?$GMa^Q'vRgG<-6Y`=-pFU`.6`Q(#as%'.n7MMM'QD&.3*uoL[[-lL5e::#j+rvufTGs-pp<$Mof1#vxSGs-"
"v>%+M&c[$vni#d3g[+p8*'@/;8^wf;r@VA5G$NmTm`-/(reQe$Fv>iTFF,W.C.Me$Do'eZSKFM0cv'B56p/VQ_2B,3eP5d3n'J_&-a,D<lE?/;6dEg;JOOY5[)GGW2<b2(*:Re$P%O%X"
"FF,W.mTNe$<HR1gOBwM1LJPe$&m[9Mq9`l8t8G_&t0X_&^uq:H_Pd?K*,Qe$+Y.`aL'%Q0lRQe$NMK+iV,5d3wtQe$xZ>X(bD3_Ao`3;6Fv:>Z2?tM(5@#-MhQF)#:WB%M.G.$vsSGs-"
"QDQ&MVhZLM9'U&v'#)t-Se*$MHpQ'vhh8*#@AJvL,k1HMZB&wu@$)t-=+W'MbmfwuBCg;-N_`=-P()t-R%N'M3f[$vXCg;-eL`t-0_FoL4:F%vkSGs-I8eqL_BNMM@_'&vDx(t-^K0%M"
"x.2PMm;DPM65voLgNh*#V-l6#cE?EMnA^nLvMpnL3Uv6#'dCvuqK,W-mJU_&6)C%k=,dG*DSrD+s5G_&kg@o[D4Kv-8dOe$`<pRnTvxc3[G1a4U8L_&v,Kc;]c-^5tjNe$1_jr$b:a;7"
"C3Se$_7l'8@IQ@t*,hY?<>p`=+wc&PS7w(3F9Se$d6tUm]c-^5;nRe$P#sOffb4p8;?xu-ut>tL*5voLc5*,#F-E6.7&mlLA8*,#2Ywm/4,rvui1;,#<<Y0.f4qHMuf1#v/G`t-v>%+M"
"'f[$vPCg;-VGg;-#``=-<wX?-0(A>-]D3#.E+uoLtx_%MZE/wuMX,W.S-F_&>Z3igKwqP05q@u-d#suLZ[HLMchZLMssANM6H,OMJdQ'vC61pLgZ]#Mu4i#v8UGs-YuD'M)rn$vACg;-"
"x4)=-_[VS%mgHP/HNLfL%?*v,IaAG;pCk%OnZCYYK6B]b3mPrm9pR>,7/bcD'++>cINqY5ruifLmd6;Zl_Yfhv-%g:1^lfU'<5;m%jH&4DV'dDNlVGVZ,D;d-X0K(,WN,D?0L;dw(1?#"
"JEEj9=K=pRU#rVdM(J5oAE_g(*H5K1[8[,MOm?sdh,]At.g:H2tqEZ>5RZ#PVpLvcPrB<-`&;NKI[*H`iAk>u>4><6qr[gLBru2^u:vW$V?5#udT3t&n3Y#'o=?('7uKJ'W6jD'h#^i'"
"gmjT'O:JX'S]T^'@OAa'8xRl'2pNx'GgSI(:U-4(7cp>(j),f(MxlR(i(%`(i&wk(,))o(1;t&)&BcF)':+Q)Ac>V)5OxX)ICv$*J4Vk)qS_v)+;7)*$(x1*fH;[*.TAI*:olR*qRn`*"
">tRp*6[i<+;mx*+Lgt6+>epB+g43T+M:9^+gcSi+1s';,MYL(,U)_3,c`?W,GcfI,aelR,djr[,GW2d,U:5n,e5h7-9gO#-P#q/->9;<-r-5N-`?MW-g1lb-%gK3.C.nw-%kO1#$####"
")oE9#2iu8.%/5##?EKj(L`^f:x@pV.TZ`_&T=jl&:3ZR*Pi68%:@j_&]$cf(AUj_&B'&F.t6k_&^wFJ(`Zk_&8l4R*;9l_&a$,/('^l_&2gC_&$s#v#1:<p%x_X2:Gim_&aTZ`*:Bp_&"
"WRJM'R5q_&mrKS.<B7:2d^Z`*;3ZR*ofkr-Gej_&8l4R*3wk_&q`4;-,jl_&2gC_&Vt_L2Ho`M:#m9oDYUfP9>=+,H^KC;ITWHhDvCHl1cRJ.>2d1U1XY^oDhFJM='DvlE?gWu(x45/M"
"/_Tk0pkn+H5-xF-E;u$6CQ`q8m&JUClgQ;B.fViFkXR,QD2v(3/pYc2#:6;-%*ViBVU-AFC#w1BBxj>-P39@'-=auGd#fM1A)K;Is+B;-)Q^`OsC$LMA(Z.#20f-#7H5s-v6]nLxwXrL"
"Y_4rLq?;/#uSGs--)trLm(B-#tE5?-rY7NNXr'C-f1'C-qw<J-x2Zd.wVH(#Z65O-Z1AA-3mRQ-*^)..v/(pL7x.qL&xXrLCQLsLRdr/#u:],X?lvIU>Ap7RjMa/k&;cY#(Duu#+P(v#"
".c_V$2%@8%6=wo%;b/2'<bsl&DBGJ(HZ(,)Ls_c)P5@D*TMw%+XfW]+MH92'Qfou,T%PV-Vv5/(m3io.qKIP/^;QJ(#'bi0'?BJ1+W#,24[.g29oMJ37Jr%4;cR]4oumf(C=ku5GUKV6"
"w@+879:1wg],DE#OU@%#YuJ*#^+^*#b7p*#fC,+#jO>+#n[P+#rhc+#vtu+#$+2,#(7D,#,CV,#0Oi,#C]I%#FcR%#*rw@#Ytn%#0.=A#a9OA#eEbA#iQtA#m^0B#qjBB#uvTB#)RE1#"
"W.hB#'9$C#+E6C#/QHC#3^ZC#7jmC#;v)D#?,<D#C8ND#GDaD#JGW)#DW&E#Qc8E#UoJE#XrA*#X,gE#`7#F#dC5F#hOGF#l[YF#phlF#tt(G#x*;G#&7MG#*C`G#.OrG#2[.H#6h@H#"
":tRH#>*fH#B6xH#FB4I#JNFI#NZXI#RgkI#Vs'J#Z):J#_5LJ#cA_J#gMqJ#kY-K#of?K#srQK#w(eK#%5wK#)A3L#-MEL#1YWL#5fjL#9r&M#=(9M#EXcf$LXvlE):`N;=Q<.38W#<-"
"YY#<-ZY#<-]Y#<-[Y#<-^Y#<-_Y#<-`Y#<-iY#<-j`>W-%PRF%kSgG3s:2X-krQF%Vw@)4`nb_/&Md_/'Pd_/1L[hM07W.NX7W.N>L4S9hPT,30*IR*.Beh2Ko/F%%<RR*Q?l-?/K*.3"
"#K.F%C1M,3$f`=-ih%Y-r((:D0TEI3nU6g2P?BW$1XwLMV4TOMo-pGMSFlDN%o*s7MiJ,3$c`=-8vN$%]QSw^oH:_S1g/+47t*W-Z/i9V3#gb4R[)K2Kn[hM?mAjM-Kmt7wikJ2cBm`-"
"MOq>Iea&NM#lgt7`C/s7[U9_ST0':DL3^v7K8:K*F6VIMuN#<-xMSb-#sQF%WuQF%sd3g2``>W->H:FI.H:FI&UakF&UakF&UakF&UakF&UakF``G-v=+3:8&5N887XrJ2/]:d-6oVkF"
"/K:FI'XakFR3Qwp/K:FI/K:FI3oHs-MZp/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N7+p/N8*TN28(9p8iIP)N81#0N81#0N81#0NHlxv7R_+p88x/p88x/p88x/p8v./p8v./p8"
"x=S59Zs`a-&sQF%w7J59ouI59ouI591iJ59V,I59w7J59,ZM599+K59^&kwK9DjwKeuY-veuY-vGgmk4uQ,x'QsK_S7+e_/@wRhMK?,k2$dI_SB:CRNZi%:VZi%:V:GjwKRvK_S:GjwK"
":GjwKf,).?([akF7#Ls-Pm50NUlL99%:`N;f)iT9;QUV$%Km.d8####";
static const char smalll_compressed_data_base85[32600 + 1] =
"7])#######JovG?'/###[),##0rC$#Q6>##R%_O;GjNT#Ga9SIsA'o/fr;x7=(;ehx)m<-3B^01O[n427>j6=h->>#CEnB4aNV=Barb)ekYqr$Y?uu#Wa(*Hlme+M]s:SIxC)m0#-0%J"
"U%k.pk:jl&f823C_,d<B'-/5[HRt-$f'TqLNqU976]-R<_om92E3n0Fv0D1EP]^w'nO)##'`#iFYLHrP/D+##YR$##_cV=BG4ZY5TQi---1o92?4^=BmB>O^@h(##:LHwKNvAiFGBOMY"
"P=%q.`+*##F6sQj6@spoGPFZAeI1=#c1f+Mq<(q#2;FF%re?in*x/PA;N&m]LH@v$sLZn*[5+w$5].-#4p4oLo5rf%HKM.M<>pV-AnFX(QM#lLV;#gLH$=/1H@_f#+BP##%V%h$9P*B-"
"HIRm/_5WfC7Y###GQ7fMVH]0#sSV+#UEB@'KYu.:ZEG&#?W&]toxGju^/g2%S<cwL++p+MjOH##LD1F%0F$?$`l-qLP@?>#R^&.$[GP##r:_'#FF>##V?`$#daVmLv4W7#_$u.#cPX&#"
"4w'hL.K&0#j@I8#L]r,#8Q,+#agR%#F&6tLl+q=#V%auL[RGgL[=:=#GJM,#Pku##Fxo=#;@m3#(66;#@$)t-:#[iLTM^-#*NZ;#<H_hL3:Y9#BOH&M$%k4#]ZU).u94GMxx_%MxEUQ$"
"/6S>-7gF?-w_>W-i:p9;`51R<=&7R3q9Dig%O(Pf8(Fk4K_K`tj`=W%o);,M0qugL32N*M=dm)M*ke;#mm$0#gfl)MoPm`MNYoo#s@uu#&uqtL@pv.q>HXH3'Lx+Vm/LSnlcZSf/cU_/"
"D13F%_N7wgFkw%kj6%BlUr)j'0RjiTm`?gM)ve`NSP4/`M`d9/JeM4#QHj'M-A6)M8(/0#<es)#^G4v-=H9sL)RM/#.$ugL$/2PMMmbP$e.[mL$r^M'r)mfL+lL5/$E)4#s'brL)e9=#"
"jN8=#EPff.&WSX#7MPH2'1###0#b1#h_N1#GCC/#IB;=-4fe6/o6YY#3K./N`%g+MpYpuG-R8/UqYN'#)*NxtSlK##(JJR*%de-6(^Qxb++)##3`/,M>KLlo-lq;$:=)W%;?:@-/&kB-"
"VsP8.b.(##-x,Z$ILwA-05T;-3/kfLd4,.%8_-Z$YS(IOwc*2g2J&mAWIhxlP)XPT7x,Z$6Z`=-R6T;-capV-)bBwK+og>$+&kB-=Lx>-$.Q8.uM7)$7Uh>$w`gDOYw5/C_K-F%N55##"
":/###UCT;-%u:T.Y:>>#b6T;-n5T;-VeuH25`w8#K,v+#d;###R8h'#.7T;-LG*j0x/LGVa<Grd,Z#8IN.0m9ehbP9+F1KiW].JLK[PrZ2C'NC$&AuYc2bJ2nZvJ;D/RfL&pjIh13l=c"
"^eb9MAoZc;gZsr$DFEG2V1@SI&XS/.X$:hL=0_a#Ml3$M/xe2N_fSD$fg(P-^lL5/xiHO$^ug%Mm_4P$0i82%FGm]MDBC*#8G&=#&*$;#J*m<->O#<-8[lS.VtX.#C0r5/:rf=#v94GM"
"f_e&M-MwA-d4_W.3XW)#cYkV.aqX.#Clw:0LJD,#-B?;#q@g9;>&_%M4_C:#$XjY.&X9:#)U<^-0I&:)ARKwKPWd7eVml:dZ;QWe=$1Vd2s`4fMb9_A_RFwK',j:dL8('cOl*SewWOxb"
"=Vl-$a3vQN;k/F%,F/R<(pp-$]8&PfZj5Yc9bjQaJe4]b76)PflZ/R<`il-$_fk--M#Tw9%c'^#V8E5^dqUw93I-^+AWslTa[kwZDEsY#VW0Ab$N*8[U5W(s2-@wgc)78#uUB#$0cs-$"
"hG.-F:GUlS_Du'&hF;;$>IPk+7qHS7@aZ`*ahY#>jqH0#q2A5#'1PY#vAno#%'Q7$UZC;$6(%<$w<rC$H_LD-<Bx=-Nsk>-oXEA-L.aL-dioi-I2Lv-p6Ms-3*ft-AZXu-[lHw-9h>9q"
"#)YuuwVi].@'+&#?<dD-l=dD-#>dD-;>dD-S]D&.m9hHMqpDD-96f=-W2oiLXuQlL$b^kP0.;hL<-F+NKh59qNc[fLPPHuuA-?;#hJ0%M9n-haWV+xt]hA1pFp#D3O[$##+ni_j%Imbi"
"QHC.^K*cL]2a&cUZk2Y4Ih6`2hfj_`D]<@j0?GIgqs)##eVEC`ZAl_Mb=sonZ.P']B_/A=s#sc<8=^i#uaP]'Z;)d*UWn$$fjbc2w=v7Id`#s$%_6L,9CP'$V*.e-UE31#'PF&#>@*LY"
"@nD##,AP##0Mc##4Yu##8f1$#<rC$#@(V$#D4i$#H@%%#LL7%#PXI%#Te[%#Xqn%#]'+&#a3=&#e?O&#iKb&#mWt&#qd0'#upB'##'U'#'3h'#+?$(#/K6(#3WH(#7dZ(#;pm(#?&*)#"
"C2<)#G>N)#KJa)#OVs)#Sc/*#WoA*#[%T*#`1g*#d=#+#hI5+#lUG+#pbY+#tnl+#x$),#&1;,#*=M,#.I`,#2Ur,#6b.-#hZhpL7PLPM0%,DN>6<VQVlh.Uf[*GVk-B`Wm9^%Xuju=Y"
"wv:YY'E7VZ)QRrZ/vNo[45k4]9],M^>.Df_CC`+`^r&MgLJWiBES4GDo$arH1</AFm;k@kV7PcDg->.NL[*Vm(V%Snt(XfC#g0]k=mk=lsd3vm_at4J(kFEX[wSiKH%h%FBZ,@'rsOxk"
"am9PJQm&v#'Gj+MNLx9)vFFrdj.+Pflx.SeS[Hi^88qCa_R5Li,L?fh;G`4o8_Cigj'c4f7jZq)e7(AO0=C]O9e$>PA3[uPCQs7RQn9R*7N1MTX`l1TP9X%b[lK]FXjp=ccb@SI`5Quc"
"2Ak--F-GY>%`4ZGK#8P#_?3L#kv1c#&eGj#I0%w#Xt:($^(w,$7$t5$cEPB$F9Tm$>)4a$L7]5%mAb&%gIq/%pmN9%p*]l%a46_%e].1&:*.w%#1<-&S*nO&sfg>&ZDrg&46RW&V++.'"
"kMTu&k$E)'q8e8'%#2xL++:GbF7#0qhh?t-]?%tZWn*O0>HkTRG>b$,M_a<HpF,nfH-Nn8+cI*apN]n/mW2[Ysxc[#(Cw<Q%GM=$<Se&,Pwqt6Y0gKMUxZh_fLD1::mvO'wSFE=`+M[u"
"vN/V.gI&w6AH;u?uKqbW`3/8oht_V-U^UR#7R<xP:p:oCXZaCOK%M7]A_FV%)%tC=c/K%PKouU[V];%lT-[u6#puO^3u7J;d<b1_ZP6cj-Hx1C;4kuHsO*Dk)&$p8sk+2UvAv+aSruiC"
"rA`caQ7DL#0)9d*L)D8S#)`&#:T-pS^DSj(BneDOwxq&#S(%KD$A>vde-2E4hx^8f-c<K;Q[f2_BSSK25E/EX.a%k1QB2Eb/7PE=MO+3_kuiK;vMedacWAw6MO=3_&=A_,RHbEO-hdWn"
"0]:kL+$/qoAn(F=(Ac?d/]Wk:H&nEkf^dwH1*j9oYGTX@S%ewZ[5###6co.Cnc(/Uqe$v#N(LS.[w$##DctM(Fn@X-3P,G4_R(f)R35N'eUKF*+W8f3pT^:/v?]s$1hUk+<uSfLwNs?#"
"HXX/2vGUV%/`5#5GNr.hr8T2-ahZY@Als>7rjT;.jL?;/fjWV7%+06&%^16&&19Q&v2BW$QDs33hS.<,U9[j<XZ*i<@HBTAZ<IF#[^0;8Y$&%usuUQ&)4KQ&/8`6&1%06&C:f:di:gl8"
"o9SP&quc'&K(^L(*I,gL^l)P('UD.3kpB:%pT)*4I,kS7dao8%M]x9&JOq7'lL[W$7%-4oR'UH29OJct=SY?62.vC5uYnU0pKT6$H4x%#vQ-iLrhV@,kx#be-W&J3h:]%'Pi#j<g;R7&"
"9<<U0(aP9O$lT#,il.moqNem%0u1RW6S/&$/Xs)#n<BoL8MdD4O,k.3-x4gLr7Bj0`55F%9mPb%Bm0I$X4;d3qJ@-dH4vr-vIn8/xQ*c40MoHdXtTfLGAZ0)3F(a4EkxY.n-:n'8LY:&"
"s^hT&=wdW0rU55(VM^#0imGn&$tk]u,2JiLX53Y/.C[E5Q@anB6O&n/K/(F*h6<?#4?drdoiJWZojRw#UrUM6.-3d3_Rd2&l_K*W_oHS^FuRE3V14#%NsBZuAoVPp&>uu#<J1D<bM9g:"
"VLA-d6C#edWHW@,?vx$Me>C:%N]>02Vu]>,Ek[s$3^>g)&.wW_i(UgMSF^I*$]K+*H&X/M=1,S.nh+D#g+)ZYv?]s$Ivnb4OD,c4&udY#>as%$*S:e6_+WA#nUH&HoMr&$+ph_SLr=:&"
"u$H]un3=@I9(*Zut/.7$$PxA#K:-,6&][x*RYY6/_U?QD.@lp%^6PM4EA*5vbk,e8.Lk5&4wZj'couv@JKtV&^7f@7e64,2pcjwY&(_l'j<RIqY;7YlH16uYa8)w.1akW6.R###F/@8#"
"Yj8I$?<r$#xD-(#31SnL(2^I*f@Yv$W4Qth)RL,3U4d##;qw6/+r9C47'$gLCAE.3@_#V/FU1DNsiK,N=#Jd)O06GM>nD*.u>tB9%Bfw,sPjs&<-:>G,%%gu8,3o&_?,HVcxpv)31-t0"
"]9O)%@4T%QVHQ-/.p8t&sL@a=irDvHLdr5GIr.MN/prP*7/d_/c:#:eiMEo'&le@#o$Vxtlq5_.B-*=0&PH1GDoMxJ6>4/,S*E+.<U@n0m@N$#T++,M%i+Ds^sJM0ePB3kuMNhYus-)*"
")dE.3%P'f)_.4n-ucn$p/Ug:/xQ*c4qBbKl[1*C&DM[v$oH%x,=*GdDU?]s$WQ?&8OlB9A]^6u%*`bg1D/0i)P_QMUrRt0$fS)i1%)?f=[01SW5,IjrEHUw#_3KV@PE=?-:x9t8jU6k'"
"'m'1Cbrxo^V_j8.d'fr1q5J&/wCZKDfx1Zuj0q(-O/TP/g_N9`iiMxbJ2exXK'kl&74*X-H:RgNQgaR8d&AR34pb%FanD5SGL/R3p&uK)sM[L($V'f)a#uKlcm;hL/8UB#oK(V&P$tMF"
"%@u:&lv=@c4pBa8g-W/ufi+r&QemQ8r-O($ZwcP)n2I&#TUP#v+NJ]$V%<fM/LihLsg>9%0F7lL*veU/)QOZ6_<*v#X`.h+Xha?%QVr=Kh?cv#v'DG[h$]104T;88&KK'PwkMA0i5(Q&"
"DduH?sn^4fK59M^XE^`3j/Bm8>ei-*]3B:%]S$w-%Fo8%3X<N0NAg+4CY@C#o'q+MC]Qk%./^C4WCH;-HUd:A/lQT.I.(]$/'(Q&/CG**Ax<B4`6Tw#?^9,5ISl^,Dm0,+^WBH21)iE6"
"4:uk'%wl,,7^'97DP+*$OYG>@k[E89/.3-$d6Z'#C5I8#'J1;$21JS8]$6K)mAqB#F?+W-<c1LPliA+4?:v7$<k.5(Yi&1VJ`ot%V*CU&]rZv#guqFXW7vM9L8`97jO0'$PO4t;x1B(#"
"+kJE#Vfa1#Trgo.@uh8.Eo3ed9cJS@9<<U02jiR:8mb@9-erQNiX:`sf<<>GAq#I6iX1f)>VZ8/r'l%$SLtk'A^=E;bB#53Pr;-2eAUw0R(IlSt3r7RpsQs./oSfL40)Q2j)mb<ouuH;"
"luoMDrb+fEDbV.0C7YY#q[g2#tbK`$Sq78%2g(T/)]28I0+9,/AL*?#OtbSRe*@^tFU5O'hjg_,m)l5/^4/5#093jL[ndG*FF=K1oUFb3=sdJ(&i^F*/gSW&@[4?.]l`iK0):%0CQL.,"
"ui>B#rYH&W7':`CoNsu-Z%fYYX04,u&rd'-</5%$bG:x%9mhILhgl9%w0lx#-OL$$Qu4wg0O2g`3jHG)6^gN(.?Tv--N$?$3/s20?\?Ea4bf*05JV$40rnaOo+1c:&xS6t-n*j$:Y*qv%"
"jN&9X%JTb4KCkw93SJ]$,*DiMwOGA#E4n8%;Q:a3e.^C4=]U@,o29Z-@g(T/?D,c4XSYS.sf6<.bNx>-^E=g$l>H`#4ap%O*AGmUBuNq.BGTUWRd6_u*_Ht_mW,nClHIY;^/D,PgeMQ&"
"+N3WFesJ,8:^Qjuc-6*.me5+'ddt,2v0#p@jB:?8R(.cQ6w]^/[Bd0(^J8*3V]6t08WK^cOO2m/XIGP8HPlG3`cld$ur(K)oSng<(eX(0BfWF3U77]6lei*/CT(T/S<opKFVOjL9_vxL"
"'q7^/=33E4NuY?#=,$DFOs<d9ddb(/Lb,s6-h`Pg_)X'.Er5n'xDpE.jfgr.P(mS&AYfx$FB(]$.nB(5;+WTC(F%&;WT#T9T`JE3,FU$$FJA?lPq)t6+W%CoqG/s?c7=c61B[d9.5YY#"
"B-*##Vr?/UO8[`*CCj,*(rF,MNo@X-`H,T%r9%J372tM(`?=%7Fird2&U<d;eX`uPbJVZuBc6gu1WgB'aJ)76e+P#%x`H/;)&2UOCxBJ#3riuLf*)SeYTB)3HqMP/PegZ-l5MG)(n@X-"
"^>>W-@ON'6)&d9%dR;Z-qh'C4tjc.qJGe:?IwQ`EcsrPGM'1.77fdrHLW1Kq]c#SRfuNDWC`7e2uR`rpGxM:m6xN)5K2F^O6.-5R@0q)3;n=)#uX9^#AD2_Jc]C5SwP:D3un0w-VM[L("
"sJ))37&Us-hcXjL$_+c4@,+gL,t&8%kiY$0S3KPJhuYY7isaEB&[5p3mH&=]B3sYO>/b?]a6l2(70=tmKeE,B'10B'?u+u%wRA[uxuh<9Jw3JGWU:d6.&C5OwE71g@+>v/Uv;+*e;w^."
"Sdpn)mTmB#@'*##Lg>,V[E]?Tn^D.3,&1hPa4d##GX4T%u<7f3[>:Z-N=+D#.C5XIF,ej(R@Lh/<X_n'kl&_+(6@q/8Y7,V9]A2Bleb`Gn[%n)q7`v#R6i$)-Q3_Aa]m@b3mcK)3>]]+"
"8.gr6-5b>$*Q:-*cQbX$GVkfMe+#o.gIKF*,dA7.b7m683fB#$6Il;H,K+P(mDUv-M6sxFI>&w%FdqXlBL,onGRiCA;p?7GcsHXRK1T(03ubjHV;$B$Q8]Yu8Sgi@-@9''=VJ[uIFS2;"
"O`/9VHk(x1,?jtCL6rE#jecr&AhE>+Y)9q'.;6@-owfau>cCt%Z%S@#jI`1C_wnf$$NmZ$xekP9e_jDYX'xf$qU-1Md4Bj0:)Ml-$A<Sa^g%?>oT.BNoglqL>XI#7hg<.Ap2e%(_h>--"
"^0(-kk.$r/lN#2gL6Bt[-h^PSj%p(uGH]#/BJDH2&fL=-Rs;9TYUp+Mg`)*sag)/3]I`@#kRYw$nRbW8V+/8@`lUP&q,U99Ms849/dqKa[Pmv$UekD#nL[w#_YKp7^?1$5$TP9%iWtZ#"
"5w^G=[Lb7:fv>q9xV,<-qAIU0F]7H#m8A5#764l9Zg5w-t`k1)^b%s$&@xf$rx&J3jik/:s5In&iE1'-.L'X8jj.&(Zl+;&h;EEu]sm0)i,,j'IOq:#LlE9#H*Fx#_ui[%FVK+*RD+G4"
"0_#V/P-Tu.uf6<.Sq%s$u'rg&JSpOLleXY5@_G;@5nvJ#7.bk'PJKL#n;/[u]YUfLNbP',?==f2#v)F=R28k5CGJfLiQSS#w;-_#Gx2FM5ql*8w#:<Jutq_%S`M^#=T1$5v8Lp9M*7u&"
"A$lO0QITV696v;6NuH01tQ*ZuL6P>%.PE_&#m]E[odxr$CvAM^Qij)<U:d##aU)Q/?\?Ea4X3NZ6_Pj.3huJ+*dL4GM@o*L(8`hJ#6?.AuJg*/:MNh]4:-;fqOt4`uoBY>#$91lq>lqo."
"X7'$5<naCa)`JfLQ_6##EI:;$);d3#p%eR936q#$W5MG)Z%c4%B4'E#17w29)QK/)'TUe-A@:f3s]XI#hjL/VeS$Y%&WvL8k#@)QWXm5&=MSx$xmN/4*Uqt%LkRH[gJf)41J`=c+mRq&"
"JJFm'.wS`Ew?4E.]nOu$VMpg<?Y]^tm4[n9%nVQ19LXwTBnc+M?kbA4*-v1B/f@h)rh,K)^]?<.jw<K;biUE4*%C(4oJUv-7U.:.xQ*c4FJm,*uIKF*3`BgLouR)*BI@lL1-cX$hpOp."
"/33E48jJb.-Haa4<@w`43rr58_SG8%V`GUIm:o'$+P#>5p(4'H.D6U*%>ms6XTLo95`$f2?S-E/IMGB#oq`fDYpFu%v>7duZQ>A$q6hK,dPufLt/FLWEE_A4hHsEu@n$j9X[Y;)K0Cv1"
"5<38AO?W:':PVN=8j8(5M:s;%x8IlfN.5v0gCT*W6(pL;9vwr<[53q,P)YU1o-j04.RL7'u*5gL6K7S'M@sM0CI:;$G;d3#UDHj:ib5<.aQv)4sJV@.__R'MJE%f3_S$w-Jqv%F9j(#1"
"JA3DuJ$E[$wY:2'm5gcDMI-=-Z^nX$H9lA?Tn9($b`_]=OD,nLU,#d;5C([uAKNL#7I:$$JlsEIg=f:d6APmTY7PV-&IML3S/pk9+YpZ-kUFb3NO@X-X]j/%'9dJ(Jc.T%MY<9/)OU5i"
"5g;HcJ/D'Qh#Oe4GtrMgJAD))[WXP/;hUJhvRwiT,Tc>d+4;2BAYoM@C&d5&:u-guJ`D[&PYR1+Q.tTufN3l'/c<g5.),##s.b+.1=lt7p,OB,Hnr?#pT)*4'->g)kSnY%L@qR1?wvM9"
"-M>s.Wd#X$FAjk'T5gXuufl#DsB<a5@_`#5LTH>%nG4Annbki0DQd^T8$KE50=JMD.MmfC2@6xOwZsgC^4o'7&08#<U-G99M]*];1/5##08@uLjlgi'N+lKP-t/3MAg*P(`bp&$hlQC#"
"?q77jp%9HB4nj%;#fmi0:?RGiT3#jT-S5)u_WFv/3BX204*iOAu.Sw##<jt%/.c%O/oBgM%Mi8.r9]s$5KMA.u_:W-0UY-H2SD^mv*Ta#G#Ar2hc6_u@iB95fq`$:k+KY]qm<GDR:Tau"
"%)I`AT&W:0@C.^6n;iZu1xvQ'/:@+5R]vc2P<Kp/FJ7h8ELuG-sHk3.,JUTNb(XbNUU..MpwgN(@f)T/o23E4x_0AO@XAn/Xi/igT,r+VQg$CuDRi.3Xi^-4^Eu&$pCQt0J<>Du[@7B$"
"))T$%JUr;-IHvD-^[uh%W%`8.T@vr-o&1L)p1pb4dbZV-;vjI3c*/N(@41gacXme43$?o)0Oc3($:M:oP_i&%2OrhhJM4rdbeGPAo/NhB.ZRr2D($jT]P;SKHv'RBO;kMKZZWL^j+M0,"
"q,QE3>=G%Xvb5VR%4-,MU;'XLvdoud1YA_,45&&+jc;F3IO@X-@p*gLh4Q)4?+1H2DRu)4&gm+)cVNPA>5_n/THGDuKk]8'RFjCu`k<L<S%C-0f.rf1`a-n':jpJ1(/+R-pvG`-&c;-m"
"0g_$'-CsJ)xD[q0;Xbg1^2I^$nn[hgRTr>$We-LWTx`60@+</U@%$##oa;wIoZ,e<M0x;65tFA#0/WF3MD^+4N$FYl=7ZCjJcS#mWDwA6W8U^#VRQ[$KC1bt@?$u&5u3]/pG?OCmISG;"
"ZOH29eXp_-KPgQjfXocVE@Aw[M$L,3SdDb3L$3XC8O_hL7wul$bf6<.j>#n%*,Fb3K&+<6-flP?N9)X6BRvd2f?oV4Xm,Q6C5a[$P=:^uD`u?#;F0w#0c@lJ>`>5AM'FW6$sPWGZluI:"
"P$)_$SmZgL-R<igj0M21PNO/):&;H*NKR,*OYFZ5C'Ch1sH3A6dRjP:Y;&GD&MnW$KPC=Y<Fd,Mj7'I(qE4`6_'>80H?*##rb%jTnxep0`QXG%#BqB#ljYY;nd5g):xc<-6*lg$u?]s$"
"je#B=Z.L>,f1iDIGH3tE7Ga%$c2`M4)F-?%ICKv5:RZ=RQTM#5k[VP6SYTfG9iPdtmn3C$OGu1)%GW_t_4(n/Yu5v0iVvS),vZ$;TQ*j9mdgIM*t1e$PDxx+%S:aNA-%?$lJIuLo0#n2"
"qkn<%*Vp@men^Lp,Gj%$emja$D<(^?,pp3=1)m72hZ7kti-IK1rW_-@edpdOL%1kLGNs$#mD[v8o).m0]vu9Kii=c4wV/gL]wAa#QsEo3?#s9,`*Q2qVQ1C9OR**2[$@a+^CUW$_ZukL"
"<B2N5]KXj2?jVH@*Rm;uAQu1)rK0n&v$I;1Iq`0:)1sEIxuou,_xwY-.Ad8.s29Z-%qs;-(Kxn$bx+P(sf6<.+IDJ:KRNr(^b@UBC$TH2:U'NK/A/j8e>)2;'),G1'?>3@2oBx5oO@g:"
".@1(&*Gx@#;*a2)>c2]b8c[A4pDvA,twVWfjGC:%hFs(=qPY8/Hl8g%ac230iu@A4[m5%-pnrsf=)Sd#05CLL5qCm4J*XLD8B<#&c'Qh,$&&<ki-Uc30mQH2c'RLM[;-onw)#t'Yn(t3"
"7jt3FQuHD(qElT@VdTS4f]c&Sm$.lf-iUv0&m'N&(ZrY]:gTG;RBn4*KqWC&:b&/1TuFgLDcWR8@QY8/bC`+8ExJ,3kE'd%/2VM'aXec2<$R^TdoOE*wKQ4qFrn]4Vl,v#?hGc6JMP/3"
"&;_w3C<n`A7dWfu5`Rm8Z0G%.(FZu6ob[g:0=>J$2=3>7,Ys_7l#L-%vewiTxI=Q1oHnm%mf6<.=Fn8%l1^F*jpB:%o*&T.xQ*c4DwO,%.doF4urZW.GL4T%a7wK#1Q:v$b=?DcpMi@4"
"NQkA#KLflG<Q_4,v8o'/MxXU&YiuD#&*A)XpE4kG@g$jTM6_t@^#PUA/07n&b+=TBD_(pE/:j^?MjCa>ht+jDrBBw#jm&B,(t0tN@-8BXZ'U6W.J-<-*o^w%Mt+T%nKv)4bV1Z#<2Vau"
"rcHq&<.ls&X];*3`w_]tSC^v5KKCB4xw>1%)V+wp1Z_dO*ggW$nh'C4[Vaj$(8Sv-W.]w'jGmF)Zl(v#/uv#&H(Ob366C&.#$vn'LxvbtTES#HI4hP82bo`t+`qc,4uUA$A-RF@UA&&+"
"O:7.3t='+*'TXl(alK.*G4[s$@3d`-OWuQWF1Pd=H7f7V&c),+v$$P;?lbc9&'<n'?tHJu%ESvL8KNh#r'2-2@]XjYq[h`<w,]1Mn]o8#4]h;-RQ;a-`hwh*^Ou2<T&GnEirr$>s/j*e"
"WKpC#g((F.$Lmx8V/0cXDJY@PK96*3e*x<7XDflEgi>$E54bE&>kM2I,wp3*s0pl:p@db`:pnlJsO%$73#fhgr59tHOJE`,IZkQ9#:6?$6)H3#FqKDM+U[#%BHg?TSF57_D6Zl$)J+gL"
"&H5gL>@iS(?bg:/IDnC#3_x_@f*gs'#&a&T<s^n/Owj40d<*$&J(,q&O3`MTVG)f4ZYW1+,/]+0jV$_uxqr)?Z00d4w^>oF3^Vl*s,Ua6(PLi^J2J>>E5:-00RLs.oq]9^loBg-7Wi<L"
"?i,Q8f0Bv-]p^b%F`4Y%q4S`c$2K&$($q(PBS`d2E9d>L^95Eu3uWr&r-u]#-g:E<#Z_#;#px:-%A$Gi;T0g#nmAKW'YnZ$rx%88*ckA#[->w$ZekD#wFKV6%5Hb%?_+D#Nk457%=#j#"
"EMvs6?/%dFQVsICj&ZMTCn,j+7PP0+LuOU&?='M+fjeH%'Ms%$a`aj$v**##wbdPS0J###nDK%#]3B:%CL]0>A@E;$*Su+DU*bZubFi,@:_es$#;UF$CTEm/2WcvdV+Y;-E^Z`*w'Es-"
"(97.MQL[P/mm+g$$C2E3R<&)EDOoC#.e):0q.$I*VT=S/],kj9x9Ub*NILJuZ_o?5b0/;Hj[/J1%=T=HCWY7&.Jt'#1wk2vf+:+v2h1$#%a-Y8RF*T/2Y?:$Aj.+ue-AB=Rk5W6SIjL1"
"q+r58NLeS#5;U'#0,>>#XpVa4;(]%-Gq[s$K3pG<2)o8%-sY8RF&k%tbx<M.H.]u.)jNK)%/5##JI:;$b]w8#v3:+=dR5r^KiPd$FlbU0[Is$>KB6$$$]K+*t?(E#q*$B=+N;;6u+F4o"
"cW6sOi/xrC4^Ws;0]b:9>j9.lvO>rfhA,T4?r,)$9o)./YWZNUm>w^7I`?5<<NR]8FfR0>ULIURgq?1gGG1t%4c%R5DJR6M^),9#Q;QZ$s4=1:g5VC$M5U&=IN(E4[(KL(9DHE4,K+P("
"iM+jLk`&q'+'F@q/$'&ED[P-L)s;[$DhBs8sPNs-$=@AC@FB''#POE==+;au1n$d,Tw/D$;O%>uB;^I=:H(WHIsJi^6Ir)-hLsJ1F@uu#jN]5#M,>>#B<9;K#KTW$2pg;-uk6a.)gK.*"
"X#]/&@4W^#cFwB/>,vG2D9Xh*(pJQSc_jt4KhcW6+],Adl-hf1Yeq)8w1#d=5qK7)=`b9:93g#G]n0-2T+d6JIs+>PV4'kt9&#ktQ#cSRgpIkto/la4+g^I*Kk4D#W2YW-?'sjtUa';m"
"ZU@l<bkKTofjgUNw_T'[v+Z5?mA^+(SCUW$<]f`t+J1g+1/#D#AV:g+*LJ_2]MQ_uN)To'u:A@#$*axG%dA7.mYB%M'd<8$+VJGN`JGA#hJ9s7#[La4qJ))3Z]Qc%v(G)4sf6<.1<##>"
"M50T8nJNi/5,)%7fo]8[$f9-LXmhMXH)cc8ljP$$A'MA6$&0PFuc-K>lY,52vNvA#4UL23kL.9<FoOgLC@+Vd0fCDbFx0gLThXI)b<Fg)B)MA7?A5d$ngBu.2'mk*4-4bH?Ucc2Vd6*3"
"[*i,4Ps;u/^amr&Jid#-Aqc7'@^sV3V+E)3Fj[##D5RouRKIw#dl9'#7Igw'src8.(cK+*8V-W-d[EM*9H&(%DLVp@10(:qqCF<>WW`=O5obq&=pG,E6,?T>UmU3XSbF@m9Ct:;IR/W'"
"KG9[uxmleSZSm@=:]_OT(;k#5K<4H*4$;wG'Aav7lrDN>598tuVYHf*d7A@#aRZw$`3n0#lRb7eEJxY,=o/Z-V,M]$7&'J3^[7W-rxY1WPP+o$O%A['m^aV$?6HGMmEU;AYuq]Zjtsc`"
"_;m]6S;HH2P=:u&$)T@utf]<?q7_e4)]C=-(cxm';s5g1L5YY#t18_AN122^0^(;?W2mg)H-*Z68PSC>Ag+REM'(11jl*_$@4OW8dbag7V$[3B'ET0'9WeB1DmxY#8`)#MR#anud*9Q$"
"g&kB-5kWr$4mR8/fMmw9*BqB#)KjI3OV>c4=<Na3I>N=(2r[v7mM+acaQEc3LU&gHu8m]4OhM&6Dq+k0DoVj&BS=dP;[u89jT&DXMC;f6ICHX0IY*9#Q@gm$(cxs7,wsY-H(Z5_jZ@S;"
"#L(a4Kb37%Xb`v5mfi>5+:D&9s0h3(Un'wKJH6>%`5k],q8t]6S>Zd2MLXi+j-E`5mrDd>(se_6YTV^4uQ2x$g#%7'leYGM&0Qf_H@OfLil)/:f$Zg)xnh8.daim$:Y0DlGk)'4>*jr'"
"U;$h1v4Cr1fxR-)SK_k-+R1;?b'Tv.%U5d)3o(Xom>C:%x&gW-Au7@'_S$w-q$cGMeLZe4]x*B*.8*$JS0j;'$>td,@m;=%<@5=(58W9&@?aD1gK-4E>x5AuTg6R&xRiFR%w=;HR+9iB"
"id-_#)o1$$2TEs8h)euYMuF$#Uen8.P%ESn's,W-9p]32I*w]/,9Hj'PdB:%TS8K1ugNJ:o=:*.Mh,w5[B?0hIbr-*P,oZ5E2bL6TAVv:F/0;Q%.1Q&vt=rHU8%@'M.lt<15YY#D3*##"
"<pKYlW7lr-C?+<-1AvT%RIb%$<YE+3Ba?T%=Fo8%4DLmI+Km1.[@mKJA%M/:QuEc*s<82pJEq%$*0kr8R7S18AX*;84wlt<vjVsu[9U$$our?#w[HW%dr;Y0NDqN$p1b9#Xl;0;Fi8vf"
"I/t'%$*l.HB^-T%8JhJ#o6%,s/NITSu#8&4-e*-;.[-=-lRmAbWhXEag?8Jh;,5`u,F5/+Hk-Y2(Jgo[J(:[u1_$&I/grl*;lf9==BZ4*#lhl/A#7ouU2Ox#=sd'8^UrRs=TQT%g4vr-"
"PQouG&AI<%sRiiMKbDxNTT_r?0hZ`5C-PJq-<%peUC$5fKb@+u_S&*3^D3=SOT[uY2I:[u[]Eh<9^mlJ=Ji+V4q#vGp?Fm/O@uu#R:@8#/)WF&:o)69hai6NE4Fb3jr@NiO02h1^0,T^"
"#+m5&?S]x$nj,;dt`iH4.n6p)InYI6S0nmiIfW^-ld/R<C'<Jhvk-(dMc$w-'Cs?#8XQqT@`)T/ej>j0l5MG)YK[+41`NT/cTj5AOJ,G4[L$$Z>7o9.pP;J%&+>&$GBWfJ'.Kx@0jTs'"
"JUgV6,_/7$&[>nFmj3+$o'OO11[o9.rYD#$wNZ*=3DPR:_obVR7.S3:&Dkm1^;D$>J6sc>NYgP1O4OmLSAk=c3Zo._;iXY,J8(W-:LEf4S;,l9nn(9/pFxU/=c%T%R2tS73vhT9eVc*/"
"WI9300hN(/#>7,VYNcf$D4@>u]w]o'Nd3Z62jf_#p';0(c/IY2ERb7e<SQ`aVFb`*Gjc-*uIKF**W=P()g^I*<t^T%<&+<6&SYS5(7X^ksHf4IgooI&MrM.Hw'eg#v=BCuR(gi*U60d#"
"&(gpgTvirZ_kBA+IOV,3ON>3Dsc$i$DUnG;HK)B4^omC#i.Ma<3Do1Eqx^i)6<IH3(DRrBg7dD59h&2@t?U/6LQD/(0N_^uZ/2tGkl*R#CX#B;rr]E[QT.)$#_]L;))>NDx)-M;OpcG*"
"cJ5W-.5@bY/CuY%(gac3f=fP/MrpoK/KiL5`xVw$kIQ85jF%lF/CVfV5$9Jh<<@xO&]8w#eP`Z#AePt$6FK+MpU/<$fEXnKT-_H2K]WP>UT3`R-gCPS,$B#dYX^`N?_Q21E>1H3+]Fb3"
"R*B6/oUFb31`nJ;Q+,d3KX=U%bN.v5?TRih[6*v@qxTj(@L-9TQ(qj(gjT#Ax+$n/dA^g*(XgE#,Zqm&a(4-9=9.bu``+U.A(I%-/H$Y4t):Q9@N@F##f?>#[m^=c/CEYlXHlX]cSob4"
"wh?&/`4pL(KBJ^dVRDe$KeTau0OYh%-d#p%eVxl>+LV&%J=[Yuq+7bu[HjQ&CrSX%Q]NpSoCA$T<MTf6Mf7Eu5E#p'iP;Z#1uEN9$B-d9,(C`1AHE%Ip@(E+h;_$9.W%R3vZjabYX^`N"
"e'CA+,<t-;vOvv$qt'f)Ie1m;+++D#<r0H2YqDJ4NA>V-tpm8'@x?N6dVl(N.H;($n7FG4aiZAu[Lg@6t>:j*)X^+i=/CR/%(IM0B/@8#oHu^$kpPQ8g9kM(n]N&4f.*p%ET2^4sD^W$"
";&+:mVM&]$.vb*.Wm[d#FDM0$'/LhL)'&i)x,Tv-?;Rv$IBuD#'cXF3*SeiTNT9A6D`MCGZI0j4fbQf3MHL:U8W6-5<5Hh3bOf-H7kq^fNd*sZox8_8Hj#Q/xIkI)<0fX-CL+T%$Rob4"
"DF(a4?_#V/tKZ)4;W8f3sJ))3%i:8.+E/H:<_B'@YpvC#K*Sa'PhWO#Oxvi2fQZC#vq;O')+$Js^pK-kUYpP8Dl0^RS`FOO0n<;7lkx^M-u>Rp2i:B-&qAPF)`JJ)YD[Y#@IDG;Iq@)<"
"8's+;5]GwK82pb4c`8GMd#NT/Wuk;%)c:5/$]K+*CEBiD*%vG*v2Q6W+?jv$pH3Q/[7*T.I$4Q/8J8r/OJ,G4;Cq^5Au-20k*`N(odSn/oh8@'H4aT/W^(0(PA5%I5k(O12<IP1)FE,-"
"^)`K()>5%I3O5n0eh':)J/S2(Nh@[#?KCU%s9jfN[<cp%iAf^5B$s%,YhPwHo#A2(gFE>.9&3s1=LW&5FeJ4MFdD0(Tqnq.2.P316'fTifV1vuq:uU$o(02#NTdd3cVhv->;gF4kG_Z-"
"wH`Boki5-3RJ))3ig'u$kv+T.,R7x,d;Jj/KG>c4Co%&4IH2hl7jE.3j>ojL$4_F*LCJZ$w+YV-&$;Z-lkgDNpJ(u$$S0+*7RL`N(XpoL.h+G4mY$HD2pB8.*8>YuimY3'+g+0J>S%4'"
"t&CD3tcW$Bb79+*FtDB?4.QG*al<a*r&ViU6gt^,C.)?#_,IH)AAe.2S*0m&9mFi,0Iuj'fShq%n#CW$vCsp'QRiZuK#He#Ephk'-[php$ZqV%-1sW)A+&'-MDZx,lSvr%K_BL(o+wE)"
"b$92'KQ.<ZTW#R&:TSf&^Sr0(XQ^m&]`Ih(.2[C)J8;6&/oT?,VHOX$@W?)*I@@8%Qf]#,=kxi'hU?5fTW,R&0DwP&VZ#R&IZ<qG3r*=$eE9U%KE,n&;]1v#?_)n8%5YY#-x/PAKP(N0"
"-l68%WKBD3@6;hLJEZuYndLP/+inko5vqkoNHV'#0.=*$#MS5#aaFoL5)>c4?_#V/loXjL9DUv-f14.)[B)t.g<7f3Dt>V/kM]^-YA=KM>r,Z,TpB:%nE[,X8hTx$BKc8/mGpkL;_dV-"
"$b-F#?T?)*K,'0<:X*;:Uq7fJ;j%3DfG&W6c:fp%_JxX3_w^K<5OCH#Wk,VCwA5r1+T(?T$=14+;'UE#0*^s7K%#N'xp=E,>$O/u:L.Z73qSd7bV5g?ct-IMiL^@%wMQCb0S=@$)Jh3O"
"qEH+Za+Q%5tY<+ZSt]>#g#fM1I8w6gbaC)*C=+,)JC$##,2'J36PDX'dZZ;)3=i9':k`39:,gQ(;?FH;7gEgPx5Gp%$1fK:WglN'7T`Z>T^P3'$4xg:6.r5/9^%w>t*lgL4BW%$wh/ip"
"ZA]S[jgx+2(3&##rLfD*u7XI)6+r;$_o;T/`?7f3rT9Y.Hghc)-U%],k(TF4UKKW$KF;8.ootr-g<7f3&kG11DfWF3,#hI*e.<9/xS-=.YiWI)M._>cD`E+3,a0i)3(;/:,)[HD,8q4E"
"l([3SngBCE*j'SDE2iZuXFIqCbqq^NfkC<B]ITvA'wDOtEK%VrKq2bMkqfZ$lW/N0qWdI<rk'[>g$2^#G5a8:kro44bXiPG4g&ip;l?+r(5)iFVsZP&]iXM'dW+fuW>e$Od_(wA[_GWB"
"%qDkt[Wn6Dfp5Co=:Z&N^c]Y,+7PD+w(r(@-M9rIMhr^#mHBq1w/5##9jCC$eh,3#e,_'#n#]I*h>.H)SLxnhhoOZ6qI,G42*E.3[k[s$Vi&f)W=FT%e8^F4=93m(`cD>,x+,8r`J/B#"
"w1Kq'AJuG#&=%U1O+6a^2KKPSaPCBY+oA.q_l^6(vmkG*&U>n@swAVBHcam'Ix'Z`6.@vZ>-/bIPJdu>/c%,V+]$s$WkQX-pO0N(<s=/:J6Zx+96q(*XZN1#$SS2`#Bt$#XbY+#8->>#"
"#i^F*_bpr6rC^+4YlR_#@GI['h_G)4G&9f3GT(T/3xWD#BsBN(d5%&4)tB-%)gC/s3^H_#N9wX-+]Pv,)V`?#cTk&-C<Z33nN1]1Q4GU0Pu[_u^*es.Ip)_7tNBZ7kA+.1SmA,;BGe#5"
"FCH29,qi7'cG+&/omHJPfEW@,SI60V%0ttITp7Z9_jtvQU@J/$n#:J1c5YY#.lvrH557)WEj?D*F]tr-iL0+*I5^+4?G269>_`x->;gF4I(HYJpvT]I_Bv4WQ?RSVVUU5M9_S,?4SMKW"
"Pj4:WYT?4#<mQO$J04.%wXbgLiL7.'4_)Ojn@tA+<e/<-JY260+<&##iL%jTlx_$'9%1N(N93j1#[w`%w*^cVESP4>(<gK]Zt8Ht$agItgr[l%,k&qaP`.JL/+APJ*M*,)2@@:7$K+O'"
"ISBu&I4&r%McT>&mMOV'QRo3'YqeP)[nS3':S4B#Aw**$K%T&#?of^$AbqT/@Dn;%v%xA4<MVo%8L;GD7+8E5vMb5(u)Qv.n>huAhi2l<a.Ao0KY/1(B$IF$a*(O;G/$##?mq7#;CLt%"
"Q%vqAO+aw$VRI@#YD@d)2ia@$kXV=-<i__%TjWI)H4n8%:R1x5cKNu-OaW6I+FD>,RBVJ(SIUZ%P2MQ#xTvNCFY<t?<SV0:KkkEMpAIYm$#gB-<^rdCim;k(F;A>c7uX>-H-A?>I#WFr"
"tMd33hphm6rLMO#HR@D$Uf1$#R[2Q/%a5J*:d*E*uvQ_sX1Wh#xM$qLaQ%)EBh_$'^5>##k$/9$wP]5#?_R%#c$(,)P%1f)?l)r(3Ioq.q7pE#sM@^HE>#[P6e:DN,6'xps@)X-4a?>("
"4?%B#q97w^<*#)a4V###<;SC',l>c4YbS6Cpj7n1[nuEk^iwnZ6-hP#=2b69@*,##?Cj%$;)H3#DmV]+8m4:.nKSknQ&UunI13D#Q$cWioSx>-+E6T/c9$`4Z$5)k(.f^5xo^MTm,tIU"
"[3`_u-L%Z#Sbvu#lur'4Zrcu#TL,DKa1x:.U8kCjs7]59#OLk+jv-b#7UYH3x,Tv-j1uO(:]%fGfq@UR`KZg$9NZW8]&^OO%2G>#8a6g#Jer,#P?#h1x]DD36*YA#f#`O'dU4GMdij/2"
"3>%&45U(AX.ua9%.F;j91YC;$/5mT%A_[<$')@s$*'V$%xJAL;Dtap%7dWX&5jCv>@Ues$RO>'#vN<D<iux4]SV`&d7w1M%>;Rv$mH7lLLqAc$@cQiTAWx^5AW4$6mq1O;3ocn:L*9g0"
"?:9q/cn40;1ll3;vwH-Zls-PAuvTBo[]###Bfgl8<@(a4=46xL&K(a4<siK<@a+$6:+W)F'Q##Jr1ki4v]lY-SSrp9*rcn4]s7J0)%v`EeT)gCt:`$'..ji0>x;9/wtX;.,KP,*O_+T%"
"XE+m/@CYC$]xBN2c+OB4m#8o10+G@$1*,X$o=9O*W<9.Eg,gF*K4*R<w$$Pf0sT8%39pl&3Rrv@E_6m8wW9/DQpOW-m21`&7@a(9#qR5'pIR6/Yx[L$HnVr7qpq&5ZG2DW_Q:hGK),##"
"%Fte%=HFV.JH7g)?I,hLgL-##0ffX#6rjjL.`X&#LNv)4+d0i)[+KF*O0d51CUUQ:Y)J`sV^V[o/QZGIA5Pw9mDq92lJ6:2G`#'?eioF4@6**4=PL[-a*Fu1O6v]u,=UJ#_'D^R8p*&+"
"^ar^#?[EDaPK/Q/4j%W?_4$Z$l-S<-Q(8f&eEEl?l^Qfr#RJ<->1Q<-#lhl/I`jP$9Bl#%p]fH-Z9Z&HAo2JU4CHv$MDlD%]1HpKVL6##/YMs#5sv5.tkYxOB]^s7--lA#wSCx$=;C<-"
"PK%R&R),##`Ho9$w<d3#V,>>#:%Wp.jpB:%wPV]fLiUv-XH3-*cxK8.@d<c4YCh8.:<1T%RbL+*AUWg1pkVD521ht%Vxb-,Jg7P1`[*>AWc9(%x['rCbw7oL'Glc4.T>I>`c66MKuP<-"
"pUUl1C=lduV/lu#X1w`C:RpKMN'[l1U/bf-2,?wTgjBwTL6&##^4[r;=8P)4ZKb+RTYMT/cwY8/&B+4%(ba#%>6/H>f0Ab4hG5MCbr[g1q'8A60.LX%akHF-DqelLd5CuA@&aFeFn]7s"
"rsDe&kC_)=IOe'5OF?N1i<w1Z@NhS-?hYe)+@3MZUxSKiJ</m/'lVP&%R`n8ImZp.Kj+BJwo=^Jr_4gJs`xAJ/N%v#K5=xtZG(p%^hHP/_*%##dBww%pd2/)U(r<-$x7$(5R]`X-]d<-"
"b5Ck0(LLrZ=;%g(;778%fkCD#,wC,)aZpP##c8/fiq,V#nASCs>B''#VZ(NCIW:Vd/(ja4<Q#x#U)huGMFr^>YJ=5&Rpt]uIA=_/^(S1vdZbi$j6>##]ZBD3&@42$xs@u>KL&Tt:3H50"
"S_$##F1[MT?I;kF&EsI3krjA4QY6<.qL]L(`3lD#k_Y)4WCuM(.)@j:Ul`#5^QX@D,HP;Dh;#hudkXcDPr74C?]XUbeDB1gQHAJC*RFhoJ1kQ#C%:I7CDCM6/`oS6g1C.3rQP)'%4K@["
"<q6g).DXI)7Fp,&LOTfLuV#h%(bC:^(slA#C&0''<d7duO8V*'5Eu1Q6uHLGLSo9=$:d,E]Hg],#@Ve&QV;&->ime>i/`,2V3=G2sKZ8[/pDD*#Yr4Jxf#N(+'>,%Ior20?f6<.q%:8."
"8IPn*>_4S9aM:a4hsdI<c);t.?@i?#ax;9/lf&bGKJXJM3JbF3U$nO(7q<iMh3CkLt2/n$lUPv$f4:lLu@i8.kA,n%Zpp1TA/cT8Udup%fM',*n8->8SmUQ&$_x/.B+6k2kQGS9R^/&6"
"19=e>U`=>%C/$'CuG1a+Hf.T%5]rd#I5RA@?q=5&23*v#u:JA4mj[PJ:Y2Xo^rFoC'Bv',*ol$,*81_%:AfHuZ`CgC6L]S%wi[]@?dd%fq7-Yu?Gg.=/on`aTCf31FSEoCLAsJ>NORJC"
"^i#b7%t-lf`8<UoO>(B3i_=&HvvaiB)'F@#4u$F8j;nfENICE@bDYc#<uqV$jr(8[NQiIhRk.j0:EIP8d-LhLCr/J3<I'>.PJ>c483E.3WOT&4A4n5/xa)*4@Dn;%?1[s$t0;W-*H0I$"
"&4$gL-?sI3CU+T%6ea+7[8Vw>bm?[5m%xF#6.^310qFT%n<1'>VU6s0k2oO(`ZsZ3eu)Ab+Rlb#,eR?u5.Zm:.FOr_SgQbF9LCmuUTGPNuo52(3hmoNSI-6&i>h^uj4?=1V9G/(T$OPZ"
"Q6$a,S/P3PUbVE#8Oa>Ai8?G4maPfL7pg:dV4+gL18]]+4Y3>5hgQ?g@EK%#`b'C49[MOB^UX&#PMdb%?uA]$0o>JCZ-Bv-5xhp$$,KF*AbT)Zo`5/$MX1f):2Cv-R8YOq'><;?i%YZ,"
"#3Qv$]&3+rdptV-U-As$/9<16PB@)+nkx%$TGwASln_O1p^P11vACV%l%[1KO4.W$S8HIh1O5D0Zfu'a[SSYYq*u81lKM227H4/D6?;sHi=RK>GG^19WK$3+B.qP8[Tt#$BLis-%/5##"
"[_`8$0m+6#F8^kLB<LF*pxJ+*W[s:8A3*uJgfrG)x,Tv-unAT%fi^F*PC(*41t@p$n1%[7b.)N9nL=X$q@@w7&N8BHe1e%bC)d.GP)-Af,7;I,fO(fh__ZC#`4c40+Z:U57;=,MUGPU0"
"2d::5ND-hGq;&[pYPWJ1[V_'89QEW#,2RCum5n0#]`qr$XK'd2p[_Y#(2###&0wiL]0nY#[MoV-tvbM'Ox&vYj&Nv,2EXw0%.=G2AQ4,`om-<.F]tr-d6gw'`1`AP(j(B#STij22<n]O"
"D@TK1xhkYtvBhI3V3'Pol4N_&8RC_&K),##T6XE$HbDE-N56c%S)0J3^5W.35G65/_ZnG*[>:Z-4*11p_hb-6vDfFD'aCPSJHNw6Xp]n2PHex+`dw[F*E?+4<>@8@.Lif^vs/$?Ol),V"
"=+;;$K<5[$Bjxi9:J'1PMwPk+$xYQsjZ8vP*8###RH4J*:#G:.s))F>2p'?:ibeM_PdslLM3wu#rTclArqxY5d<ai0sg%##`4QT8T[eA,:WR/&B*^5/%[*G4)NUq8,*UR'Cp<c4stC.3"
"lYWI)x,Tv-&HnS/*mdA=?7h)3&hLw59BhQ&+edI)N.2C,>dh-2jYIB=_dC6&^cGD+sD$v.eHaR86Xhm&F1SW8T-(3Mu<Q).DFe8%ZO1f3JV)rAZA[g+22fEDdwE5&J_u31j<3S()rGQ8"
"APGM2jQx_6,(?<6T(]<$icX8.a6,wA?R[&[a@LA.dpFL:O?(s;OJ>i<,m>>#n#lRna'.m]A($##1XkD#[Dsu5oC,G40<+G4cFVC,M:CkL'dJ8%:X&m&sILP8a?:`-D*%[%n@xsLtgOE,"
"h5cJ:Q;mRn67Bn0Zm.k#01cW#i6RB4f^uSu<AsCN%/5##Z@N-$55+&#a*6?\?V&L/)k#6?-;'+C(iO0>?_YO]uIS4,'PC6##)E(v#KN0:#4f1$#C^qc)dW<?#P%1f)S^[:QL?WI_I(m-$"
"L$F;$BdGjuKmr=lXfButeeL]O)xH#?\?$H.62c4GMi6V-MZ2)5MEE9>G6+kfLbk1qu[3%;-01oH#1WD^ME:cS0:I:;$<5Z3#33*jLOreD*nm'EEkeYs.9i?X-6/NT%->UJ#4V/n&@Yfx$"
"KMDE3fNw>#-/1t#^mS22iQ*?&BE_vc.G@@bIEOJ:U,?p9r#vD:oQ2suxH:N=K;/m*&/.t-593jLF%W@,a_:W-&hi/uC`Z8/*-+c4qD_'=sLt87B.&p9%DGJ:+behD`vCoR5euD#7&J-,"
"tjT]$_V;-*XHl:?1njfYA[(A&^=Pd3/HiGuoTn/20O==%@oMxbD(/T.W-4&#bx=G-1eBDM;2_F*I=:Z$AL%LGU@pL(8Zf+4Q*.AOrhtA#ib8E#fDkgCA+'[urdhduu>EWH,+Im0aoaIq"
"(PL*B)FGtLRgCF&nvh^Y2>(>IMBJ*p%*IE3a0.pK]:*cdoHOCjE0.e-QrES3tlAr-1ECupN:?>#$B,W-l9iQ;98Uv-v>)6/VX'/Lnh<p9*m4m?RngV6:,S`$UBN%$JS+3+e+Bw2CRgD*"
"0fEhLC]ZY#j)fo.-dqcVO:/T.0V'f)kc3$%ef)T/i2Cv-#mqB#afLa4'PFb3oTw+'>_u]++-w--F3Nx5WsW/:X-+%7%mx)E<'vZEet`%A,LIUe,ZncV2ematL-96:g3%q7xCcx71]#=$"
"WYo#/KN<Y#KAAZ/CI/&#K1fQ-O:iT.LOlI)Z@r&Mx<i8.^U3W-0#)C&Bk,T%)xF`#GRYl3IKmCNQ+YZ#k[_Q&dq-P`dO9JLLp?_u`TULJ.E/b$=%nU&bSVZuvLY`u:-'8'[qXP_IZB>G"
"g>-jL$J0Yc^wPAOY:KS7`J5H3</4I)f>4B%%Qob4+e7:)Xc^gLOMr8.X^7eMh4Bj0e6fT%jLx:/SQ*c4[<An//xrx=BfR*3`hI_6]G_n/GsSv&>oxt%OKar3k-3Zu1O2#$D71H2bpMv/"
"RO8`uZX@E#uY(auX4RYGMA3`uD&N/GJ^wn5_WGFY@&7;8B.?ci::r^uW;9O0R*3EETM@@#4DP*EjMn21Ka^c2&iM=-Ma*vLld6lLCu;9/XR[E4b.u`4rV_Z-;bOU%%Nl>#25sK;K8;R3"
"u4(F;[-f,7Dj0;_T?om.C_$7'PsQF#h?jPg(/8_$=EZ8+V<*7;R(>'>:w%/+F(X^4Em^8//7Fx$-?vbd(_2^4o6I*RoRap.1/4&#Qcqb?gi+G4E0Hs%hq7W.OeUN(HgrB4Z0k8&`Hfj'"
"]08:fk-gF`>Ou/(Ngtj01(r;1&P^C+Y`S4(s6snOp=/h_L:EN3A(/YcEJxY,Oxqo%JC$##Nl^c$'K8f3-.#rCfj?#6qEIi&L0,D#o4#]6<o>(jL28b3&Oilgx$wo'^;<1B#<7r2_Qxx&"
"YSS90m`o`t-M($$e%o<$?e0ct1D#j*4lUA$M/(UD2Bt$M1O1Y$lb&0MPYDa-+o<E,Pjsn8m*#d3a+r;-]<Nl%%8WFtAF%Ej5ukE4WCemSQ<E%$oV2N7&S]S65Q4Q/SR8`uo5CPJMA3`u"
"afY$%p4]l&E5=fq-`[>uH0BK:#w25(9;qCauuId;1ZI%#jTD1)djB:%<7D8.@Dn;%Q7h8.swK_4]I&@o'?qZ7mrD:2N*Xw092iR/TN4_?G&J.h<-L+MLF,B$J28juAce'1jK&W$PEQt:"
"hs$8#wnIh$uEpkLI>^I*OP,G4aN=R%T&sS/+aL9.GMrB#eB-U%Q^2hH,8+)>3uU+-A/_30J?=^PC@&n/N/=^OH=4qI]3PK1_1]R=fGT;1MLZL6fEp17vJo#I:HD1(Xd+v7Os/i31pi(4"
"3o05(*KL5MqPj^otto^onLdERhl###s(]L(l,+c4J_0$fB8xiL1S%:/G5R_u[&aZ8D(K&$9p0I7]+F*&G;Mk#P59Z52/3u%U5CA=gdPx$;>I&4#4n0#e9]uGI9U2U[[-5/8teG3tE^&F"
"USO*?F$2x5'x4_$0[]p7Ql#?##1E@ufjJ=PQBG#>/kvX-`Ww>&l>kt.Ke$X$1CJ.3]1F1?ouf`>'d@^;mXK:uhIU$$fuRw#0008'RofBJO)N^&Jq)wCf8QK)Af)T/$A_s7p,R@'@hF`#"
"#9=CNpcH40kSN48(IS`4lBW?#3+xiTRE=gt;Bqv5_%U#0_La_tf,hv5'?2];a3QL/NI:;$xlovL`p0;I#ZZp0u[oL(cU4HtgxdC#FvCBoU>>+JLlak61BBY#EFDQ].V[MTPrY`u;%x$8"
"p3PU&9aT/1D2fCNs`-@d@Ft39k)^G3aMa-2$Fo8%d(4I)R4sX.N,'J3A;$T.#3m;%FD#W-<EpjMgY'3CBKYx0LIk^4HegnpsSw$;.l?=-K6Y`uu:&s&<@n8%u%Eo3nw,jL#9n#6sCLs&"
"O8?+5lv4^&lB,j>TqdENkJ8*3VPqt&KW;/6Y:)'m;rUNt*X=<-+O<a%EXl[-N=+D#H1.'3hc6_ueMY`uM&BK1@C.^6uW:R'I<grmO.etTYfp$&;&u;-*^(&M)B]s$@0Ct8dTml.MD^+4"
"OnYhLg4SH#t1Op-os<l?l,c5&c0T+?]Mf_5`v$^X%v:i@3&Y,fDDxiT5V5(j7w#vGe.cV-)o/m&2TQ+Sm#TG7Qixp&PVcl(ao.@#?,Q8;+1qW/&5>##LRUV$D0Q3#fd0'#Qn0$e*SrB#"
"Xnr?#mDoEN6H:oKA.w<($VHp.0H>wToVmD#sf6<.NO6##+G[=?eckf/--]in:k056q]L,*FeX25k.P4g(F=^O`cviT.'@&SB,@euNdPt$CXn=lX#Rtnn3r[uX]T4JCSXcM9i,QukU]>-"
"4*$v%SjZd&AUt2iAtHg)i6a2MS(_1&[CMd32`NT/9ik,2H^;F3gF6w-SZfj'&H%rS;1`A6Wu^lgNsl]6ZjUe*8eP?(T;+?I9GOJ,-oPX3<f4K1sW;)$19Ol8B3CH2rfxE.x1jZurTUQ&"
"2rg0IHDo)=P2BfhW),##*C8A$*mx2DTshx$Uc-F%E?`F*xnh8.+_#V/m_Nx-r,+c4kRN`#P5SA4nN7S't$KCuP?o>#hb>$(`$t=$Nudj'kv-l'XJxE7I<Cw#.(wP/UVY4/6;F&#SIW-?"
"_Q/o8^Cu`46S];.8:FT%&/OCl.]l=ZjAm]6w$LJL'iuX1Qd+R/IXv>0&F<;.+U5:&.&t*iB3cK1=-Z[R,>bY5hpCl-hGbKN(J1NCdp?#6F+D*%rgM,M2AC:%%GNT%KE2B4Vg/Y-blF20"
")4LR4V4[Y[dDUl/riXr'['Tdt$;Hw$GP3u%C5wxG&,S;6]B1bt-%Ea-EBb@$pUKfLNR-##)+/x$?/Q3#9%(&8mrA,3&U/T.s'#V/_J5d$M<q-2Z(8N1qSlD#H)H<6p#Er&a+B-)n:Bqu"
">S*-M/+S0@J7+8nQPqKGS)>GiTWqd2h#?2;N#eI>u=/j.#/$.4B1Juc@9f,3ndw+;)8BZ-IO@X-M^dj0Ygx9.-moF4%d#W.86LT%wx?8%:RFG25TW*.20>.Ob++r^$MM?#fFbA#cRkfq"
"^Xk`W:7Y_bsuL4n0.mB$,?)t6PmL+M9SE1(8%]%$GXb7evSN`slkUs%d-U9r>77<--ReE.u29Z-&N^D49&/*3^E&^6ATQw'+):8.1ax^/@UiFMdTk'GrR_U>]7qw,S;HH2*s%n';p5g1"
"@x/au>/R(G1JoC?l[$^5Y1uUQ(gGpo;p?##2@WYdh+&^,_)c/)$THQ:w&C99UNv)4@6=a%Mm7_4'Wcc2<#e;>ZUb]<gpD>,gFS^XJIxiTY[);$MP^[uIb9b-:5mG2PUPFu3k%J2lcWi)"
"$),##ROo'.E=J[:KiJ,3Qr1Z=Ub1e3:Qob4lTAX-`$UfLBxEb3^-c>H0Q9T7NO>Urdxx)Clij07.&lxFa;A>uL-ra#@xlqg0]05(Jrbg6pM5eQE<bl(KU-h,Pc5?&B]Jt%W^mY/L1Un'"
"=1=(MxhBm&ti7Z-^.X6Nu59H3+J,G4aYfQ'Lp;tg,%oC#U97r:+/D9/x?]s$xn-sAw6pRr+MsF;YK7mQJA6U.pINV?$(?<eWUO]uFLf-,.DXg1Q1]P#YUf4)H?,99mbf8=fUM<A/2<xX"
">#3[$pS8(s]A9v0ipg7&2>@x':,(58nBH?$@)H3#AWajLE6iM:'x:9/WQBv-4%hDN5j?lL<a2#2T^bX$%Bh>$<HWl]ri>4MAdj`upBBWnsLA=%RrxMc?D2##oD9xkh6u#%O)?d2/;/V&"
"A-89$0V_7R>BUB#kYa:BP6h=Q%HH+`+r2_#OIeT*t#(<ew`&AtK*NP/p.7N9%lW>-tQSs-T-xe*ftn5/]AqB#'7*iMjqf(%womD#w4NT/Ssqr?p-rE.iiEiu^wM%ubq]>Qt3%CQd&'b*"
"$Gfp&VdV^`D2YXZot[h&-Sc)$IUo@?'sWK66YAn0eI=q'^SYx/D;wH+T3$R=+l^j]>;Ev>2-PX;WDWPA2*a1&*bWQLpYC:%t?]s$^,T%6YA%^$qKo;-=#d,%[G;e;b52N9srL&%`x[?#"
"$hA]urB(duPFY?#5>ZYblMfXdWTk`8^^'eAa%:*8E5NT)pMh_ZTn$JCSHS7&;7M#$Lovq'E-i19=IHgL$D)G`2ClUIi3n0#vXb7e?nDAF-j))*kE*20(;HW-ga44M=JtA%:2Cv-`aoI*"
"*2pb4O/`#$.%I=7`^#V/rbD;$HIt#%&&vF+$u[bugW[]SR.16CS>eg6'./X.`j7E.:Yot/wjK60ebgN)mI@g:0N5=@%50quLuD,NH:SG;SUT?dxlSxt6s-,)WKBD3&LxX$P3+L:r<CW-"
"#>'v5`vauROYl`#/.^s5TdSQ/_),-;T/%:&@$)VVxgR$9t_'SeGk5s6HeQS.wkBr0FMG`%EEmZ-hEB:%&X75/lg1T%K-+c498tM(DM[v$agjL#;BNs-T@0&$MecRex(kI)(`doBJ1[>4"
"?-mS+d4:c/rk%NT+=?xOtEbs'jZ9^@><NY&sn0n'j&wY#eu^u%XV+)Etk.K:qxc8.U8))W;Tt;-)@7I-kZXY$eo@A4xk=X(rhX;.vX#gLT1fX-D$B=&#I,b#8xwiJv2:BurN5x,([R[6"
"03f<=h%e#0,E$p#PY?>7LSt%%FP/n4?#*EPmU4p%efTVSXn1p3LK9R`#[7(seKK03+H<E[qkx8#pkErL^GF)#<ac20,)9f3=)]L(lC=5*%(:+*CpON)A`?<.R4D'S4aZv$]3B:%UekD#"
"Zb=Ug2W@`$k`SN8.&F:&:AAx$rj=6/AmGg12E.F4+Oqe3*r:D5U5LK1./9AuLQ_^u'dHWg5o[pOSm`bPn1scbJ4G4oX^YP&WdCh.Bal)kGPo7CEfK'd$[I5/U/_c2x6dq7TWHdFp]Z.%"
"l)9o88e:4DbYob46DYjLN0h-4AA5c_K`eV82GDR<2J551C%i)/g:S[Hl$lp%U8A*7.*bY%fWHg,oa%K3n=ZB,M6xZ.+$ST.K4io(_Y>K*AgH.<]gML1o?RpKmRS8#QeCxL3eu1:?4cKN"
"Wv^>$KKFA,-V_R(_5,l?=n2J,[D:01YdRx/'3qI2Z2%:&j>@BPm)k.VM5mrHQa`&.qrg%MUtYM$Ma($#)o-K=sal8/3'b/:&_:E4SdDb3]JD-O5]Mu$m/D]XsT]V8gs%U'MIoW*IbV65"
"Hb,W6qK]5hDp3@$+6jw$EK2^4[5$R/I'7=0]vBV()uf'$FDP4SolfQSEXC;6o'CwKaiMxb$<'d3wLpP0ql1g:_gUa4+g^I*V/NqM%>:8.m%]u8;5>)%GInes=$bYlXn930eC+q&vZni("
"D+R+%jSWU&a7rv#*lM4fOcbYHAO=,2sX>e5l^ud1l*s20ns/5)mmJ43OkcS7=hdp-CJ2_J-R0_JEP`$'K=5i(Z+t;.hg+)<0xPm8U>Zv$U@u)4-?=c4[=MXeRlFV&*<]32PWQ=?Wa[S'"
"dmTu$XjID4WhQFoEJR</w)xCjPHxq9pN2_(qEMf#,Mv69WBZ1/3#%)W<S]wB4)qQ8bCbw7HYY`%RUsEINOFb3bs.Pfe,U]I03&7&:GJx$gb5n&<WN>5<axG*gE9$$@c$GXYYTbA0lT70"
"9h/89r`;U)SjIi(Y<lt%PmFD<@?6$G4rs[XRdH_#:/7S(Qp+<-1=Nq-PAjeFDN?,@3xsY-oxd20;2WD#XsG122+N*I]nQYu#5O>5[GLK1tOjo@ksrkfKG7>>CCkp&E=gV6K5YY#>w)##"
",a38[YILS.RF%N9?6ts8?cuR(JX1x5sO,G4x9Q127@[s$q-7V[=Isj?M-sJ,>N<F]0fi,``H^h7$BWv#&$/w7NP;I?Degr/f>H.?+X;suLb6w$oJ.i(C3<'/]Tf='cF&?@NW2;ZZS`A,"
"g.X;.70039YfOg1[5T/JZ5:7/(.k=Rlq;l(xW;$<V=,k5in/L7'HADE8'74*PZMj5/D6;HUKthL=UJouJLuu#?(mb<WN@k;,Z;E-f5-I%oG3I)x1n.%B@vr-oq@T7W9-`M:eX?A(#ON0"
"An/HB_qF?,)>,^k=x:&%Y=gj5/QMFP9C-buA.UN0iDHi>):drua#&#H+lo+M@TrSIlbKk.E@uu#EDeH&otD)4t1RQ/K2'J3sJ))3#bqT%f';(vGA0&$aW]in8&kv2veHu&Z0+x#`&sdC"
"?XS<1eZ18[^%;o0aw3?'aJMZuC$Aq&/+eW6fJI[PGdSo[P2qiLvS-##K@uu#g@u6#6v>t$xAqB#DP7T%n^DE4#@.,;u%#poGBQu%LG:6&jDk9.[]ACsQb[>#^,4F7-EV7e`nV9`%6k;-"
"%JkZ%#kn+>rjP@.s^v)4D43g)W):W-g4LgaaOQI4bq,O(W3&o^r<1-2P7r'<J':OJ.M]t%mU)c>M(VFA:@01m<c8w#9;`@OrdfdDhK<AFJLH+D1(3IVi,7M;cu6gDlA^P<5+`a#-GM-Q"
"ob'SeJrxrZ(ICW.7c3>5?O`=?(iV6jHCTfLZWkD#_S;N0t<7f3eUKF*pP>D<H7N;7%mc/CDU[n51PKM*14ctZ<2Zk0t1nfRA1dk.GxD%beKu%Pe@Zw$Eq$PO,q8.$motm^7Eoo^'pwuu"
"lEHZIfN)p3pcZh7cUn^u@RGe,_FndBtO2J1*HdJAH),##?@uu#Pr=6#(==g$OcaF3;MH[&)Nc;HvdCC&chfw'F+k:6AwGH7O/dA@-4Z$2xPi`5;V)2^GW_LpqEHF#/gQN'j[th88wUau"
"CJL6&F5S_4rjkUm<W(C&F_A?7r3wr-L7+_JN4kx4V%3_J(N6T%foEb3A)]L(,CV@,bhUs-*,`Z-kUFb3B3ul&Nr_m5[#Xx5f4E:miA(2^X1:=u3;BkLSwHIqa`5:A,[H3B(fG'$Ai*v>"
"')h#$E?u6#U$s,3GF1x5YR%'M7;Bj0IoXjL4:oC#Bo.E3H$L43>JVS%NESv&DQWv#Vav_jn8dc2>n=01dmh6'<9.AO0^L$'E:XV/<P$<-I]AN-OhDl%vuY=7Ol3[8b+l/E:/:Z-Jc.T%"
"GH%v53odn']C[lF5N`>5DG5p4YdkXrnW&2^Ps0]=uB)JqO66&4_nO^$t9Wc8;[=SLnN79*#5O_1wX15/C8e4v48ofL7ou&#vurEei^iI3V*,30JIV@,p;Tv-1ISLGU%IK1Z=-aRw&hf1"
"k$&t-^#;-23pP4S@Ptv#glwI:i=8t>CELLpoqxX%DZX&<a92v5OtAK-))9W3%/5##F@uu#`N]5#Svkp88e5g)0*rx$mnJT%QEOZ6n%NG)e,]F4rFxU/Ti(?#NNeh)`o_IcMar':J87n)"
"o?YP&Dk4]Ya4C]Y2(I/7lZ@X1j:kjH'B(%0bL;@&2H_Bu$pZx#XoLJ17K)Z>jR#(#E5I8#xuF:$7[u##p-nguXW5*nUv+W-9;rdmC;HE4?caF3qEQcMRru'$<H%&62gh*3j0utgCdmm6"
"4-Ov&acYl,;x6>Y^;-#$c7('uv[-n&pgV6196TGjr0R)+Uc*.6Q-@d*`b*CuN_xF<Hp0m9j9<YJuLJ88wxAgLfNGf*EWSb*HBb/:<cp58V:wo%'B^_%EGKqR?lw'CZ>GlVcId4,Q6U?-"
"6K(2^aPFF1DO>]u]eDB-qTjc#21tZu;f9.9D?g&=NknH+GOWoIx`=Ppo^*g2k,u9.-s^I*s1])3OwAv-,7F]-/Y<9/hj-H)/EN/M$[8K4Yh=HaPT;ZD-0fm*RSq2^In_&;)jcp2C_x1K"
"/+xMp:Q_q%<m=&<LcO$9)u%7L2>(s3v*DT7,58TIg^me6Xl-lF2D83KQ8fV6,UL%#Iq^4f>bm`EL_UV-kE7eQ0)]L(LD,c4K%@t-->4a=_8cD4?mAq$mJ+P(J0@Z>Sfu>#WRwR9ROe?."
"7*39]<b&8HNk%&6,RjJiG6h%$%(#XZ&x-8[@;:lSjiFJ+vfS_usmR>/mBANUIb':&L$%m8BX;suFUhv$s1j?#?ULv$X@4D<WnK#$Np#-.:BN/Mp)VRBxN0N(Jh1dMK[qh$d*c%$Z=61M"
":QPG2p$[g13Vk,2FF>`5J0pUp]dHWjeKW$$7(WOfN=clA&e8,1hPhB#St%E5hF'S3(KuE9V+8H<EC:(#IGe8#sY+U$]a($#nid(#:-:53#oh8.iu@A4.DXI)pT)*46E^,;p%tY-+HlG;"
"-?)KC@_8H2NAT`57U1e3v>D-2gOO3JAi3iKFOoP'O(O22pEBoCRbu2q#&OA4R[v;/0En=$2r@m8X?vw5>9F'6B]FQfFd]W]j=%5F,)s2KCs%n=dAf@?OPI<<`r]WPI<lL)0FpQad.Juc"
"3_ORpgc_c2%+u`474gm0Fp?d)$g(T/;vWZ$-;7<.<pnh%flF+3nVe)*K29f3elm8/:%`v#&i^F*^5<<<Ea0H2;%4310AZlhE62w%(4s)%J8PB5jVOK1J@iJugMJQ#K`QnaTB/oURZvE3"
"2;&N0's%p%rT2DNrH7K#KYVx7kSae3U;-_>'EMb5nGWfL<W6##CRu>#qUf5#A%@p7nxoG34@xZTMJ'i)d>Zv$^p*P(m[&6&MRhr&KdDB4GvD[$w>9w#vwCw68Ri%6'hrkf5c)6/rNMkL"
"BG?##gi>%.U&OZMdac&#eh74=mh%s$6$qC-&wpO0V'Y:&R(,>%ACD.NC`S)&Sk?8'k'Xn/=BD61BAda5sS8F->%)IMHK:2#x.:7%HUd.5mhXb3@=Vs-gspD3cag:/;op>,w'XD#eDIB4"
"V@vZ#D@]/1oxjo7X9$E3KfVd2%9sFNXME_$*Qp<$0<e<?3Bjc4V2=<6sR[F%AuF'#1tO6#aIJ]$00PG-?:Gc-.BC.?7SaAntl?##DI:;$3kN1#BL7%#ZCsM-IjHi$.moF4aBdl$GJ)C&"
"uBIaH$$3E4_JRv5MNH>%f48x$$,.F%X&ME#jLrp7ijw-Ab>[Y2hVhBuHmo.3IQ.9'7'Biu@6&A#k7'aNc)N&5m0[<&X_1n'O$FsomxVWHo:S+Masq)&T(J$$VLK2*vIPS.O#.8#2xAgL"
"RU$lL0=`T.,Sl##o3xU.);G##j.)t-t8/cNaLH##=F`T.XD-(#;Xx>-8X`=-^xWN0mIa)#]6>##_RFgL_S,.#NB`T.57%@#a@`T..]1?#q.)t-8+reNaLH##JF`T.4pRH#SXx>-8X`=-"
".EfT%Sa2MK(`YxIl*m<Bae@AYTc>jF9i%mB'*s=Bc)+k1,Beh2=g0s7ogVD=&>.FHoZvRC:1k(IA)NQC*a1eGrRN88H(5e5pkn+H5-xF-8-IL2]w#@-lhwFHiN`TCr6/+4Q5TO2G6<LF"
"wj2=B2rCVCuY(*H$A'C-Y1wB6h=r*H2.vLF;lY>B77sdGoAXVC;W1,H-U7F-xRV=-'Op01^8>&5^fuiC='oF-U82E/tJa7DKREkLZOhx=c0exFDDSfC=sViBH@9?-BC:;-8kTq),@AVH"
"#EG_&p:H]F6e)F.k+-AF[N`50<kt9)Vm>G24Ar%4l_As7i-7L#mj0A=IYo+DUw%;H:eHe-d'j9;<Un-$.R]rH14O2CD.Me$uV<MBKve]G/?m>-?dY-?pGs.C_1IY>P5+#Hu:k`FI2[>-"
"M=-j1UbdJ2kXk>-*?Pq2J<EqDpx_?T`kq34QQ'/1-tQ_&)<,R<V'A_/c@D3kMoOk+p(Jk45@n-$vqoQWx@;GR7hEFR7:B-dN0U-d'=P3XvwY'82du7I'l,#Hn5-mBbqWB-QrUH-9)m<-"
"ceF?-A<8F-8gG<-=?(@-2_x>-B)MT.&vv(#sx33.,#@qLBe=rLoLG&#5.cw$jZ8G;a#;/D67xlBv3)KEK=6##vO'#vfV+WM3`^;-LZ:]$MDuu#?^Z`*IkqH/KA*1#>1X$MD9(en8h?YP"
"LS-JUrBB`W3#T(j:6s7R*J(v#H#5PSpL7]b]AK;$mW:YYdQqFrhod(WEH1VdDMSrZ>vViBn_t.CTp;JCbMMrdku.Sek+f4ft(XfCsOFlfOuo7[&+T.q6j<fh#+$JhxUwOoErf%OLoOcD"
"Q@h%FSL-AF3HJ]FZndxF_6auGcH&;Hggx7I1$BSIm/YoIrVq1KXpa._D1SiKx%n.L<U=lox/Ff_)OvFiaSgV$1*8`j7TOxk2?4]k4;0P]<lGi^G%Ll]I<p=ci1r@bVqTuYLwwCa-lkCs"
"2%@8%6=wo%H)PlSg:2MTWd:ip[>XrQh6>]XM&ToR:UWP&>n82'B0pi'FHPJ(Ja1,)N#ic)R;ID*VS*&+Zla]+_.B>,cF#v,g_YV-kw:8.o9ro.sQRP/wj320%-ki0)EKJ1-^,,21vcc2"
"58DD39P%&4=i[]4A+=>5ECtu5I[TV6Mt587Q6mo7UNMP8Yg.29^)fi9bAFJ:fY',;jr^c;n4?D<rLv%=veV]=x':oDM]#03Ys]G3`SUA5j1D.3fdo`EgQ='%'HOVCB'K29Sg[7Mmvvh2"
"kr6F%BvIL2h@5dM@*3i21/R]-$OHR*0T3i2JS9I?4jje3tx>)4'.bw9$Mv`4gc:&5b7$=LA4wt7qhJ88jXfS8kb+p8lkF59mtbP9XpJ,3VY#<-iIP)N&p).N&p).N&p).N&p).N&p).N"
"&p).N&p).N&p).N&p).N&p).N&p).N&p).N&p).N'odL2uvjG3iIP)N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N'v2.N(umL2v)0d3iIP)N(&<.N"
"(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N(&<.N*.<i2v,B)4gQA)4_9A)4YbdJ2O2YR*w=d_/Q18(#$uTB#%;cY#$,>>#,nnP'2NgJ)IQGSf&l'B#w5m+M"
"jW&%#e-LhL@nWN0NV%JL:tL%b(d(GM3'tN0IeH,v0'v5vAg(*MYEfo%h;#MT[2WN]J^k'&.]^:#]SMwXdUs)#.K)uLdCZ+`VoBuu=[C*v(SUV$6U0>]H$###";


#define IM_ARRAYSIZE(_ARR)  ((int)(sizeof(_ARR)/sizeof(*_ARR)))



ImFont* bigmenu_font;
ImFont* menu_font;
ImFont* smallmenu_font;
ImFont* type;




void GUI_Init(IDirect3DDevice9* pDevice);




void color()
{

	auto bColor = Vars.g_fBColor;
	auto mColor = Vars.g_fMColor;
	auto tColor = Vars.g_fTColor;
	//int(enemyColor[0] * 255.0f), int(enemyColor[1] * 255.0f), int(enemyColor[2] * 255.0f), 255

	ImColor mainColor = ImColor(int(mColor[0] * 255.0f), int(mColor[1] * 255.0f), int(mColor[2] * 255.0f), 255);
	ImColor bodyColor = ImColor(int(bColor[0] * 255.0f), int(bColor[1] * 255.0f), int(bColor[2] * 255.0f), 255);
	ImColor fontColor = ImColor(int(tColor[0] * 255.0f), int(tColor[1] * 255.0f), int(tColor[2] * 255.0f), 255);

	ImGuiStyle& style = ImGui::GetStyle();

	ImVec4 mainColorHovered = ImVec4(mainColor.Value.x + 0.1f, mainColor.Value.y + 0.1f, mainColor.Value.z + 0.1f, mainColor.Value.w);
	ImVec4 mainColorActive = ImVec4(mainColor.Value.x + 0.2f, mainColor.Value.y + 0.2f, mainColor.Value.z + 0.2f, mainColor.Value.w);
	ImVec4 menubarColor = ImVec4(bodyColor.Value.x, bodyColor.Value.y, bodyColor.Value.z, bodyColor.Value.w - 0.8f);
	ImVec4 frameBgColor = ImVec4(bodyColor.Value.x, bodyColor.Value.y, bodyColor.Value.z, bodyColor.Value.w + .1f);
	ImVec4 tooltipBgColor = ImVec4(bodyColor.Value.x, bodyColor.Value.y, bodyColor.Value.z, bodyColor.Value.w + .05f);




	ImFontConfig font_config;
	font_config.OversampleH = 1; //or 2 is the same
	font_config.OversampleV = 1;
	font_config.PixelSnapH = 1;

	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0x0400, 0x044F, // Cyrillic
		0,
	};
	ImGuiIO& io = ImGui::GetIO();
	io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\Verdana.ttf", 17.0f, &font_config, ranges);

	bigmenu_font = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(rawData_compressed_data_base85, 70);
	menu_font = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(rawData_compressed_data_base85, 18);
	smallmenu_font = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(smalll_compressed_data_base85, 13);
	type = ImGui::GetIO().Fonts->AddFontFromFileTTF("C:\Windows\Fonts\tahoma.ttf", 14.0f, NULL, ImGui::GetIO().Fonts->GetGlyphRangesCyrillic());



	


	style.Alpha = 1.0f;
	style.WindowPadding = ImVec2(8, 8);
	style.WindowMinSize = ImVec2(32, 32);
	style.WindowRounding = 0.0f;
	style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
	style.ChildWindowRounding = 0.0f;
	style.FramePadding = ImVec2(4, 3);
	style.FrameRounding = 0.0f;
	style.ItemSpacing = ImVec2(8, 4);
	style.ItemInnerSpacing = ImVec2(4, 4);
	style.TouchExtraPadding = ImVec2(0, 0);
	style.IndentSpacing = 21.0f;
	style.ColumnsMinSpacing = 3.0f;
	style.ScrollbarSize = 12.0f;
	style.ScrollbarRounding = 0.0f;
	style.GrabMinSize = 5.0f;
	style.GrabRounding = 0.0f;
	style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
	style.DisplayWindowPadding = ImVec2(22, 22);
	style.DisplaySafeAreaPadding = ImVec2(4, 4);
	style.AntiAliasedLines = false;
	style.AntiAliasedShapes = false;
	style.CurveTessellationTol = 1.25f;
	style.IndentSpacing = 6.0f;
	style.ItemInnerSpacing = ImVec2(2, 4);
	style.ColumnsMinSpacing = 50.0f;
	style.GrabMinSize = 14.0f;
	style.GrabRounding = 16.0f;
	style.ScrollbarSize = 12.0f;
	style.ScrollbarRounding = 16.0f;

	style.Colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
	style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.59f, 0.59f, 0.59f, 1.00f);
	style.Colors[ImGuiCol_WindowBg] = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
	style.Colors[ImGuiCol_ChildWindowBg] = ImVec4(0.10f, 0.10f, 0.10f, 0.10f);
	style.Colors[ImGuiCol_PopupBg] = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
	style.Colors[ImGuiCol_Border] = ImVec4(0.59f, 0.59f, 0.59f, 1.00f);
	style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_FrameBg] = ImVec4(0.24f, 0.24f, 0.24f, 1.00f);
	style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.24f, 0.24f, 0.24f, 0.61f);
	style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.24f, 0.24f, 0.24f, 0.39f);
	style.Colors[ImGuiCol_TitleBg] = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
	style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.02f, 0.02f, 0.02f, 1.00f);
	style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.02f, 0.02f, 0.02f, 1.00f);
	style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(1.00f, 0.50f, 0.00f, 0.61f);
	style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(1.00f, 0.50f, 0.00f, 0.39f);
	style.Colors[ImGuiCol_CheckMark] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_SliderGrab] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(1.00f, 0.50f, 0.00f, 0.61f);
	style.Colors[ImGuiCol_Button] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_ButtonHovered] = ImVec4(1.00f, 0.50f, 0.00f, 0.61f);
	style.Colors[ImGuiCol_ButtonActive] = ImVec4(1.00f, 0.50f, 0.00f, 0.39f);
	style.Colors[ImGuiCol_Header] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_HeaderHovered] = ImVec4(1.00f, 0.50f, 0.00f, 0.61f);
	style.Colors[ImGuiCol_HeaderActive] = ImVec4(1.00f, 0.50f, 0.00f, 0.39f);
	style.Colors[ImGuiCol_Column] = ImVec4(0.59f, 0.59f, 0.59f, 1.00f);
	style.Colors[ImGuiCol_ColumnHovered] = ImVec4(0.59f, 0.59f, 0.59f, 0.61f);
	style.Colors[ImGuiCol_ColumnActive] = ImVec4(0.59f, 0.59f, 0.59f, 0.39f);
	style.Colors[ImGuiCol_ResizeGrip] = ImVec4(1.00f, 1.00f, 1.00f, 0.30f);
	style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(1.00f, 1.00f, 1.00f, 0.60f);
	style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.00f, 1.00f, 1.00f, 0.90f);
	style.Colors[ImGuiCol_CloseButton] = ImVec4(1.00f, 0.50f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_CloseButtonHovered] = ImVec4(1.00f, 0.50f, 0.00f, 0.61f);
	style.Colors[ImGuiCol_CloseButtonActive] = ImVec4(1.00f, 0.50f, 0.00f, 0.39f);
	style.Colors[ImGuiCol_PlotLines] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
	style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(1.00f, 0.50f, 0.00f, 0.39f);
	style.Colors[ImGuiCol_ModalWindowDarkening] = ImVec4(0.20f, 0.20f, 0.20f, 0.35f);
}

char* KeyStrings[254] = { "No key", "Left Mouse", "Right Mouse", "Control+Break", "Middle Mouse", "Mouse 4", "Mouse 5",
nullptr, "Backspace", "TAB", nullptr, nullptr, nullptr, "ENTER", nullptr, nullptr, "SHIFT", "CTRL", "ALT", "PAUSE",
"CAPS LOCK", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "ESC", nullptr, nullptr, nullptr, nullptr, "SPACEBAR",
"PG UP", "PG DOWN", "END", "HOME", "Left", "Up", "Right", "Down", nullptr, "Print", nullptr, "Print Screen", "Insert",
"Delete", nullptr, "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
nullptr, "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X",
"Y", "Z", "Left Windows", "Right Windows", nullptr, nullptr, nullptr, "NUM 0", "NUM 1", "NUM 2", "NUM 3", "NUM 4", "NUM 5", "NUM 6",
"NUM 7", "NUM 8", "NUM 9", "*", "+", "_", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
"F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", nullptr, nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, "NUM LOCK", "SCROLL LOCK", nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, "LSHIFT", "RSHIFT", "LCONTROL", "RCONTROL", "LMENU", "RMENU", nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "Next Track", "Previous Track", "Stop", "Play/Pause", nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, ";", "+", ",", "-", ".", "/?", "~", nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, "[{", "\\|", "}]", "'\"", nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr,
nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };

namespace ImGui
{
	static auto vector_getter = [](void* vec, int idx, const char** out_text)
	{
		auto& vector = *static_cast<std::vector<std::string>*>(vec);
		if (idx < 0 || idx >= static_cast<int>(vector.size())) { return false; }
		*out_text = vector.at(idx).c_str();
		return true;
	};

	bool Combo(const char* label, int* currIndex, std::vector<std::string>& values)
	{
		if (values.empty()) { return false; }
		return Combo(label, currIndex, vector_getter,
			static_cast<void*>(&values), values.size());
	}

	void KeyBindButton(int Key)
	{
		static bool shouldListen = false;
		static int key = 0;
		if (shouldListen)
		{
			for (int i = 0; i < 255; i++)
			{
				if (GetAsyncKeyState(i))
				{
					if (i == VK_ESCAPE)
					{
						shouldListen = false;
						key = -1;
					}

					key = i;
					shouldListen = false;
				}

			}
		}
		if (ImGui::Button(KeyStrings[key], ImVec2(-1, 0)))
		{
			shouldListen = true;
		}

		Key = key;
	}

	bool ListBox(const char* label, int* currIndex, std::vector<std::string>& values, int height_in_items = -1)
	{
		if (values.empty()) { return false; }
		return ListBox(label, currIndex, vector_getter,
			static_cast<void*>(&values), values.size(), height_in_items);
	}
}



#pragma once

bool legitTab = true;
bool visualsTab = false;
bool radarTab = false;
bool rageTab = false;
bool configTab = false;
bool miscTab = false;

bool visEspTab = true;
bool visChamsTab = false;
bool visHandsTab = false;
bool visMiscTab = false;

int windowWidth = 220;
int windowHeight = 250;
int curWidth = windowWidth;
int curHeight = windowHeight;
int curX = 40;
int curY = 70;
int tabHeight = 30;

void SelectTab(bool* tab)
{
	legitTab = false;
	visualsTab = false;
	radarTab = false;
	rageTab = false;
	configTab = false;
	miscTab = false;

	*tab = true;
}

void SelectVisualsSubTab(bool* tab)
{
	visEspTab = false;
	visChamsTab = false;
	visHandsTab = false;
	visMiscTab = false;

	*tab = true;
}

std::vector<std::string> configs;

void legitbot()
{

	ImGui::PushFont(menu_font);
	ImGui::Text(("     General"));
	ImGui::SameLine();
	ImGui::Text(("                  Weapons"));

	ImGui::PopFont();


	ImGui::BeginChild("agsdgbdfb", ImVec2(220, 250), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::Checkbox(XorStr("Enable"), &Vars.Legitbot.Aimbot.Enabled);

		ImGui::Checkbox(XorStr("Aim on Key"), &Vars.Legitbot.Aimbot.OnKey);
	
		ImGui::Checkbox(XorStr("Smoke Check"), &Vars.Legitbot.Aimbot.SmokeCheck);
	
		ImGui::Checkbox(XorStr("AutoPistol"), &Vars.Legitbot.Aimbot.AutoPistol);
	
		ImGui::Checkbox(XorStr("KillStop"), &Vars.Legitbot.Aimbot.KillStop);
		ImGui::Checkbox(XorStr("Trigger On Key"), &Vars.Legitbot.Triggerbot.IsOnKey);
	
		ImGui::Checkbox(XorStr("Custom HitBox For Trigger"), &Vars.Legitbot.Triggerbot.CustomHitBoxes);

		ImGui::Combo(XorStr("Aimbot Key"), &Vars.Legitbot.Aimbot.Key, keyNames, IM_ARRAYSIZE(keyNames));
		ImGui::PopFont();
	}
	ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("sdbsdfasdg", ImVec2(400, 300), true);
	{
		ImGui::PushFont(smallmenu_font);
		{

			if (G::LocalPlayer->GetAlive() /*&& G::LocalPlayer->GetWeapon()->IsGun()*/)
			{
				ImGui::Text("Current Weapon: %s", G::LocalPlayer->GetWeapon()->GetWeaponName().c_str());
				int curweapon = U::SafeWeaponID();
				ImGui::Checkbox(XorStr("pSilent Aim"), &Vars.Legitbot.Weapon[curweapon].pSilent);
				ImGui::Combo(XorStr("Hitbox"), &Vars.Legitbot.Weapon[curweapon].pHitbox, charenc("PELVIS\0\rHIP\0\rBody\0\rNECK\0\rHEAD\0\rNEAREST\0\0"), -1);

				switch (Vars.Legitbot.Weapon[curweapon].pHitbox)
				{
				case 0:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 0;
					break;
				case 1:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 3;
					break;
				case 2:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 5;
					break;
				case 3:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 7;
					break;
				case 4:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 8;
					break;
				case 5:
					Vars.Legitbot.Weapon[curweapon].Hitbox = 9;
					break;
				default:
					break;
				}

				ImGui::Checkbox(XorStr("Trigger"), &Vars.Legitbot.Weapon[curweapon].TriggerBot);
				if (Vars.Legitbot.Triggerbot.IsOnKey) {
	
					ImGui::Combo(XorStr("TriggerBot Key"), &Vars.Legitbot.Triggerbot.Key, keyNames, IM_ARRAYSIZE(keyNames));
				}
				if (Vars.Legitbot.Triggerbot.CustomHitBoxes) {
					ImGui::Checkbox(XorStr("Arms"), &Vars.Legitbot.Triggerbot.Filter.Arms);
				
					ImGui::Checkbox(XorStr("Chest"), &Vars.Legitbot.Triggerbot.Filter.Chest);
					
					ImGui::Checkbox(XorStr("Head"), &Vars.Legitbot.Triggerbot.Filter.Head);
					ImGui::Checkbox(XorStr("Legs"), &Vars.Legitbot.Triggerbot.Filter.Legs);
					
					ImGui::Checkbox(XorStr("Stomach"), &Vars.Legitbot.Triggerbot.Filter.Stomach);
				}

				if (Vars.Legitbot.Weapon[curweapon].pSilent)
					ImGui::SliderFloat(XorStr("pSilent FOV"), &Vars.Legitbot.Weapon[curweapon].PFOV, 0.1f, 3.f, "%.2f");
				ImGui::SliderFloat(XorStr("FOV"), &Vars.Legitbot.Weapon[curweapon].FOV, 0.1f, 50.f, "%.2f", 1.f);
				
				if (!Vars.Legitbot.Weapon[curweapon].AdaptiveSmooth)
					ImGui::SliderFloat(XorStr("Smooth"), &Vars.Legitbot.Weapon[curweapon].Speed, 0.1f, 100.f, "%.2f", 1.f);
				ImGui::Checkbox(XorStr("Adaptive Smooth"), &Vars.Legitbot.Weapon[curweapon].AdaptiveSmooth);
				if (!G::LocalPlayer->GetWeapon()->IsSniper()) {
					ImGui::SliderFloat(XorStr("RCS Y"), &Vars.Legitbot.Weapon[curweapon].RCSAmountY, 1.f, 100.f, "%.0f", 1.f);
					
					ImGui::SliderFloat(XorStr("RCS X"), &Vars.Legitbot.Weapon[curweapon].RCSAmountX, 1.f, 100.f, "%.0f", 1.f);
					ImGui::Checkbox(XorStr("RCS STANDALONE"), &Vars.Misc.rcs_standalone);
				}
			//	ImGui::Checkbox(XorStr("RCS Enabled"), &Vars.Legitbot.Weapon[curweapon].RCS);

				if (G::LocalPlayer->GetWeapon()->IsSniper()) {
					ImGui::Checkbox(XorStr("FastZoom"), &Vars.Legitbot.fastzoom);
					
					ImGui::Checkbox(XorStr("Switch wep"), &Vars.Legitbot.fastzoomswitch);
				}
				ImGui::Checkbox(charenc("Delay"), &Vars.Legitbot.Weapon[curweapon].FireDelayEnabled);
				ImGui::SliderFloat(charenc("Delay Amount"), &Vars.Legitbot.Weapon[curweapon].FireDelay, 1.f, 500.f, "%.0f");
			}
			else
			{
				ImGui::Text(XorStr("Invalid weapon/Isnt Alive"));
			}



		}
		ImGui::PopFont();
	}
	ImGui::EndChild();
}
struct hud_weapons_t {
	std::int32_t* get_weapon_count() {
		return reinterpret_cast<std::int32_t*>(std::uintptr_t(this) + 0x80);
	}
};
template<class T>
static T* Find_Hud_Element(const char* name)
{
	static auto pThis = *reinterpret_cast<DWORD**>(U::FindPattern(XorStr("client_panorama.dll"), "B9 ? ? ? ? E8 ? ? ? ? 8B 5D 08") + 1); 
	static auto find_hud_element = reinterpret_cast<DWORD(__thiscall*)(void*, const char*)>(U::FindPattern(XorStr("client_panorama.dll"), "55 8B EC 53 8B 5D 08 56 57 8B F9 33 F6 39 77 28"));
	return (T*)find_hud_element(pThis, name);
}
void fix()
{

	
	static auto clear_hud_weapon_icon_fn =
		reinterpret_cast<std::int32_t(__thiscall*)(void*, std::int32_t)>(
			U::FindPattern(XorStr("client_panorama.dll"), ("55 8B EC 51 53 56 8B 75 08 8B D9 57 6B FE 2C 89 5D FC")));

	auto element = Find_Hud_Element<std::uintptr_t*>(("CCSGO_HudWeaponSelection"));

	auto hud_weapons = reinterpret_cast<hud_weapons_t*>(std::uintptr_t(element) - 0xA0);
	if (hud_weapons == nullptr)
		return;

	if (!*hud_weapons->get_weapon_count())
		return;

	for (std::int32_t i = 0; i < *hud_weapons->get_weapon_count(); i++)
		i = clear_hud_weapon_icon_fn(hud_weapons, i);

		
}

void skinchangertab()
{

	ImGui::PushFont(menu_font);
	ImGui::Text(("     General"));
	ImGui::SameLine();
	ImGui::Text(("                  Weapons"));
	ImGui::PopFont();
	ImGui::BeginChild("agsdgbdfb", ImVec2(220, 250), true);
	{
		ImGui::PushFont(smallmenu_font);
		{
			
			int cw = U::SafeWeaponID();
			ImGui::Checkbox(charenc("Enable"), &Vars.Skins.SSEnabled);
			ImGui::Checkbox(charenc("Enable Skins"), &Vars.weapons[cw].ChangerEnabled);
			ImGui::Combo(charenc("Knife Model"), &Vars.Skins.KnifeModel, knifeModel, IM_ARRAYSIZE(knifeModel));
			ImGui::Combo(charenc("Glove Model"), &Vars.Skins.Glove, charenc("Default\0\rBloodhound\0\rSport\0\rDriver\0\rWraps\0\rMoto\0\rSpecialist\0\0"), -1);


			const char* gstr;
			if (Vars.Skins.Glove == 1)
			{
				gstr = charenc("Charred\0\rSnakebite\0\rBronzed\0\rGuerilla\0\0");
			}
			else if (Vars.Skins.Glove == 2)
			{
				gstr = charenc("Hedge Maze\0\rPandoras Box\0\rSuperconductor\0\rArid\0\0");
			}
			else if (Vars.Skins.Glove == 3)
			{
				gstr = charenc("Lunar Weave\0\rConvoy\0\rCrimson Weave\0\rDiamondback\0\0");
			}
			else if (Vars.Skins.Glove == 4)
			{
				gstr = charenc("Leather\0\rSpruce DDPAT\0\rSlaughter\0\rBadlands\0\0");
			}
			else if (Vars.Skins.Glove == 5)
			{
				gstr = charenc("Eclipse\0\rSpearmint\0\rBoom!\0\rCool Mint\0\0");
			}
			else if (Vars.Skins.Glove == 6)
			{
				gstr = charenc("Forest DDPAT\0\rCrimson Kimono\0\rEmerald Web\0\rFoundation\0\0");
			}
			else
				gstr = charenc("Default\0\0");

			ImGui::Combo(charenc("##2"), &Vars.Skins.GloveSkin, gstr, -1);

			if (ImGui::Button(charenc("Apply"), ImVec2(93.f, 20.f)))
			{
				fix();
				U::CL_FullUpdate();
			}

		}
		ImGui::PopFont();
	}
	ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("sdbsdfasdg", ImVec2(400, 300), true);
	{
		ImGui::PushFont(smallmenu_font);
		{
			
			int cw = U::SafeWeaponID();
			if (Vars.Skins.SSEnabled)
			{

				ImGui::PushItemWidth(270);

				

				switch (cw)
				{
				case 1: //Desert Eagle
					if (ImGui::Combo(charenc("Desert Eagle"), &Vars.weapons[cw].VremennyiWeapon, DesertEagle, IM_ARRAYSIZE(DesertEagle)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 37;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 347;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 468;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 469;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 61;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 90;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 185;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 248;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 231;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 232;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 397;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 328;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 273;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 296;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 351;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 425;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 470;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 527;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 645;
							break;
						default:
							break;
						}
					break;
				case 2: //Dual Berettas
					if (ImGui::Combo(charenc("Dual Berettas"), &Vars.weapons[cw].VremennyiWeapon, DualBerettass, IM_ARRAYSIZE(DualBerettass)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 28;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 36;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 46;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 47;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 153;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 190;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 248;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 249;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 220;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 396;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 261;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 276;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 307;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 330;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 447;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 450;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 491;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 528;
							break;
						default:
							break;
						}
					break;
				case 3: //Five-SeveN
					if (ImGui::Combo(charenc("Five-SeveN"), &Vars.weapons[cw].VremennyiWeapon, FiveSeveN, IM_ARRAYSIZE(FiveSeveN)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 3;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 46;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 78;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 141;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 151;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 254;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 248;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 210;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 223;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 252;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 265;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 274;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 464;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 352;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 377;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 387;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 427;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 646;
							break;
						default:
							break;
						}
					break;
				case 4: //Glock-18
					if (ImGui::Combo(charenc("Glock-18"), &Vars.weapons[cw].VremennyiWeapon, Glock18, IM_ARRAYSIZE(Glock18)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 2;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 3;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 48;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 437;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 99;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 159;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 399;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 208;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 230;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 278;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 293;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 353;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 367;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 381;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 479;
							break;
						default:
							break;
						}
					break;
				case 7: //AK-47
					if (ImGui::Combo(charenc("AK-47"), &Vars.weapons[cw].VremennyiWeapon, AK47, IM_ARRAYSIZE(AK47)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 341;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 14;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 14;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 14;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 122;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 170;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 172;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 180;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 394;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 300;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 226;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 282;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 302;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 316;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 340;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 380;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 422;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 456;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 474;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 524;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 600;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 597;
							break;
						default:
							break;
						}
					break;
				case 8: //AUG
					if (ImGui::Combo(charenc("AUG"), &Vars.weapons[cw].VremennyiWeapon, AUG, IM_ARRAYSIZE(AUG)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 73;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 10;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 9;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 28;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 167;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 110;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 33;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 100;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 46;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 47;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 197;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 280;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 305;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 375;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 442;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 444;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 455;
							break;
						default:
							break;
						}
					break;
				case 9: //AWP
					if (ImGui::Combo(charenc("AWP"), &Vars.weapons[cw].VremennyiWeapon, AWP, IM_ARRAYSIZE(AWP)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 174;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 344;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 84;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 30;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 51;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 181;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 259;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 395;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 212;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 214;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 227;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 251;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 279;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 424;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 446;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 451;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 475;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 662;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 640;
							break;
						default:
							break;
						}
					break;
				case 10: //FAMAS
					if (ImGui::Combo(charenc("FAMAS"), &Vars.weapons[cw].VremennyiWeapon, FAMAS, IM_ARRAYSIZE(FAMAS)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 47;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 92;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 429;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 154;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 178;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 194;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 244;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 218;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 260;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 288;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 371;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 477;
							break;
						default:
							break;
						}
					break;
				case 11: //G3SG1
					if (ImGui::Combo(charenc("G3SG1"), &Vars.weapons[cw].VremennyiWeapon, G3SG1, IM_ARRAYSIZE(G3SG1)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 8;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 6;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 6;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 46;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 74;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 147;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 170;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 195;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 229;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 294;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 465;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 464;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 382;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 438;
							break;
						default:
							break;
						}
					break;
				case 13: //Galil AR
					if (ImGui::Combo(charenc("Galil AR"), &Vars.weapons[cw].VremennyiWeapon, GalilAR, IM_ARRAYSIZE(GalilAR)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 83;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 428;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 76;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 119;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 398;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 192;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 308;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 216;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 237;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 241;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 264;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 297;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 379;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 460;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 478;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 647;
							break;
						default:
							break;
						}
					break;
				case 14: //M249
					if (ImGui::Combo(charenc("M249"), &Vars.weapons[cw].VremennyiWeapon, M249, IM_ARRAYSIZE(M249)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 75;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 202;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 243;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 266;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 401;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 452;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 472;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 648;
							break;
						default:
							break;
						}
					break;
				case 16: //M4A4
					if (ImGui::Combo(charenc("M4A4"), &Vars.weapons[cw].VremennyiWeapon, M4A4, IM_ARRAYSIZE(M4A4)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 8;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 101;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 167;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 164;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 16;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 155;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 170;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 176;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 187;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 255;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 309;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 215;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 336;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 384;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 400;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 449;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 471;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 480;
							break;
						default:
							break;
						}
					break;
				case 17: //MAC-10
					if (ImGui::Combo(charenc("MAC-10"), &Vars.weapons[cw].VremennyiWeapon, MAC10, IM_ARRAYSIZE(MAC10)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 101;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 3;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 32;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 433;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 157;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 188;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 337;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 246;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 284;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 310;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 333;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 343;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 372;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 402;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 651;
							break;
						default:
							break;
						}
					break;
				case 19: //P90
					if (ImGui::Combo(charenc("P90"), &Vars.weapons[cw].VremennyiWeapon, P90, IM_ARRAYSIZE(P90)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 342;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 20;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 100;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 67;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 111;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 124;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 156;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 234;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 169;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 182;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 244;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 228;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 283;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 311;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 335;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 359;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 486;
							break;
						default:
							break;
						}
					break;
				case 24: //UMP-45
					if (ImGui::Combo(charenc("UMP-45"), &Vars.weapons[cw].VremennyiWeapon, UMP45, IM_ARRAYSIZE(UMP45)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 37;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 15;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 436;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 70;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 93;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 169;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 193;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 392;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 281;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 333;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 362;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 441;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 488;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 652;
							break;
						default:
							break;
						}
					break;
				case 26: //PP-Bizon
					if (ImGui::Combo(charenc("PP-Bizon"), &Vars.weapons[cw].VremennyiWeapon, PPBizon, IM_ARRAYSIZE(PPBizon)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 13;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 164;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 25;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 70;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 148;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 149;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 159;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 171;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 203;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 224;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 236;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 267;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 306;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 349;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 376;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 457;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 459;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 641;
							break;
						default:
							break;
						}
					break;
				case 27: //MAG-7
					if (ImGui::Combo(charenc("MAG-7"), &Vars.weapons[cw].VremennyiWeapon, MAG7, IM_ARRAYSIZE(MAG7)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 462;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 34;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 32;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 100;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 39;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 431;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 99;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 171;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 177;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 198;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 291;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 385;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 473;
							break;
						default:
							break;
						}
					break;
				case 28: //Negev
					if (ImGui::Combo(charenc("Negev"), &Vars.weapons[cw].VremennyiWeapon, Negev, IM_ARRAYSIZE(Negev)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 28;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 432;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 157;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 201;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 240;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 285;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 298;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 317;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 355;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 369;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 483;
							break;
						default:
							break;
						}
					break;
				case 29: //Sawed-Off
					if (ImGui::Combo(charenc("Sawed-Off"), &Vars.weapons[cw].VremennyiWeapon, SawedOff, IM_ARRAYSIZE(SawedOff)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 345;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 30;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 83;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 41;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 434;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 119;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 171;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 204;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 405;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 246;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 250;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 390;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 256;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 458;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 459;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 655;
							break;
						default:
							break;
						}
					break;
				case 30: //Tec-9
					if (ImGui::Combo(charenc("Tec-9"), &Vars.weapons[cw].VremennyiWeapon, Tec9, IM_ARRAYSIZE(Tec9)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 101;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 2;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 463;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 17;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 36;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 439;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 159;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 168;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 179;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 248;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 206;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 216;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 242;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 272;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 289;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 303;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 374;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 459;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 250;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 555;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 614;
							break;
						default:
							break;
						}
					break;
				case 32: //P2000
					if (ImGui::Combo(charenc("P2000"), &Vars.weapons[cw].VremennyiWeapon, P2000, IM_ARRAYSIZE(P2000)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 104;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 32;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 21;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 25;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 36;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 485;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 71;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 95;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 184;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 211;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 213;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 338;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 246;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 275;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 327;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 346;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 357;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 389;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 442;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 443;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 591;
							break;
						default:
							break;
						}
					break;
				case 33: //MP7
					if (ImGui::Combo(charenc("MP7"), &Vars.weapons[cw].VremennyiWeapon, MP7, IM_ARRAYSIZE(MP7)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 2;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 102;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 28;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 11;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 15;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 36;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 141;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 245;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 209;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 213;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 250;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 354;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 365;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 423;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 442;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 481;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 649;
							break;
						default:
							break;
						}
					break;
				case 34: //MP9
					if (ImGui::Combo(charenc("MP9"), &Vars.weapons[cw].VremennyiWeapon, MP9, IM_ARRAYSIZE(MP9)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 482;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 33;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 100;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 39;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 61;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 148;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 141;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 199;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 329;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 262;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 366;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 368;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 386;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 403;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 448;
							break;
						default:
							break;
						}
					break;
				case 35: //Nova
					if (ImGui::Combo(charenc("MP9"), &Vars.weapons[cw].VremennyiWeapon, nova, IM_ARRAYSIZE(nova)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 3;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 166;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 164;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 25;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 62;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 99;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 107;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 158;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 170;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 191;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 214;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 225;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 263;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 286;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 294;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 299;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 356;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 450;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 484;
							break;
						default:
							break;
						}
					break;

				case 36: //P250
					if (ImGui::Combo(charenc("p250"), &Vars.weapons[cw].VremennyiWeapon, P250, IM_ARRAYSIZE(P250)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 102;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 34;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 162;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 15;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 164;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 99;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 168;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 258;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 207;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 219;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 404;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 230;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 271;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 295;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 464;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 358;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 373;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 388;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 426;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 466;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 467;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 551;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 650;
							break;
						default:
							break;
						}
					break;

				case 38: //SCAR20
					if (ImGui::Combo(charenc("SCAR20"), &Vars.weapons[cw].VremennyiWeapon, SCAR20, IM_ARRAYSIZE(SCAR20)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 165;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 100;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 46;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 70;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 116;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 157;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 196;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 232;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 391;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 298;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 312;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 406;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 453;
							break;
						default:
							break;
						}
					break;


				case 39: //SG 553
					if (ImGui::Combo(charenc("SG 553"), &Vars.weapons[cw].VremennyiWeapon, sg553, IM_ARRAYSIZE(sg553)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 101;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 28;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 22;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 39;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 136;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 169;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 186;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 243;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 247;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 287;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 298;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 363;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 378;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 487;
							break;

						default:
							break;
						}
					break;

				case 40: //ssg08
					if (ImGui::Combo(charenc("SsG 08"), &Vars.weapons[cw].VremennyiWeapon, ssg08, IM_ARRAYSIZE(ssg08)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 26;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 60;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 96;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 99;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 157;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 200;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 222;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 233;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 253;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 304;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 319;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 361;
							break;

						default:
							break;
						}
					break;

				case 60: //m4a1
					if (ImGui::Combo(charenc("M4A1-S"), &Vars.weapons[cw].VremennyiWeapon, m4a1s, IM_ARRAYSIZE(m4a1s)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 33;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 60;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 430;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 254;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 189;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 301;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 217;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 257;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 321;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 326;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 360;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 383;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 440;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 445;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 644;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 548;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 587;
							break;
						default:
							break;
						}
					break;

				case 61: //usp-s
					if (ImGui::Combo(charenc("usp-s"), &Vars.weapons[cw].VremennyiWeapon, usp, IM_ARRAYSIZE(usp)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 25;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 60;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 183;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 339;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 217;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 221;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 236;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 277;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 290;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 313;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 318;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 332;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 364;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 454;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 489;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 504;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 653;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 642;
							break;
						default:
							break;
						}
					break;


				case 63: //CZ75
					if (ImGui::Combo(charenc("CZ75"), &Vars.weapons[cw].VremennyiWeapon, m4a1s, IM_ARRAYSIZE(m4a1s)))


						switch (Vars.weapons[cw].VremennyiWeapon)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 435;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 254;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 218;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 268;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 269;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 270;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 297;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 298;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 315;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 322;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 325;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 334;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 350;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 366;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 453;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 476;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 643;
							break;
						default:
							break;
						}
					break;

					//Knife

				case 500: //Bayonet
					if (ImGui::Combo(charenc("Bayonet"), &Vars.weapons[cw].VremennyiKnife, Bayonet, IM_ARRAYSIZE(Bayonet)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 419;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 421;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 415;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 416;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 417;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 26:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
							// íîâûå ñêèíû
						case 27:
							Vars.weapons[cw].SkinsWeapon = 569;
							break;
						case 28:
							Vars.weapons[cw].SkinsWeapon = 570;
							break;
						case 29:
							Vars.weapons[cw].SkinsWeapon = 571;
							break;
						case 30:
							Vars.weapons[cw].SkinsWeapon = 572;
							break;
						case 31:
							Vars.weapons[cw].SkinsWeapon = 568;
							break;
						case 32:
							Vars.weapons[cw].SkinsWeapon = 581;
							break;
						case 33:
							Vars.weapons[cw].SkinsWeapon = 582;
							break;
						case 34:
							Vars.weapons[cw].SkinsWeapon = 558;   // ðàçíîå ó íîæåé
							break;
						case 35:
							Vars.weapons[cw].SkinsWeapon = 573;  //ðàçíîå
							break;
						case 36:
							Vars.weapons[cw].SkinsWeapon = 578;
							break;
						case 37:
							Vars.weapons[cw].SkinsWeapon = 563;  //ðàçíîå
							break;
						default:
							break;
						}
					break;
				case 505: //Flip Knife
					if (ImGui::Combo(charenc("Flip Knife"), &Vars.weapons[cw].VremennyiKnife, FlipKnife, IM_ARRAYSIZE(FlipKnife)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 419;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 421;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 415;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 416;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 417;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 26:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
							// íîâûå ñêèíû
						case 27:
							Vars.weapons[cw].SkinsWeapon = 569;
							break;
						case 28:
							Vars.weapons[cw].SkinsWeapon = 570;
							break;
						case 29:
							Vars.weapons[cw].SkinsWeapon = 571;
							break;
						case 30:
							Vars.weapons[cw].SkinsWeapon = 572;
							break;
						case 31:
							Vars.weapons[cw].SkinsWeapon = 568;
							break;
						case 32:
							Vars.weapons[cw].SkinsWeapon = 581;
							break;
						case 33:
							Vars.weapons[cw].SkinsWeapon = 582;
							break;
						case 34:
							Vars.weapons[cw].SkinsWeapon = 559;   // ðàçíîå ó íîæåé
							break;
						case 35:
							Vars.weapons[cw].SkinsWeapon = 574;  //ðàçíîå
							break;
						case 36:
							Vars.weapons[cw].SkinsWeapon = 578;
							break;
						case 37:
							Vars.weapons[cw].SkinsWeapon = 564;  //ðàçíîå
							break;
						default:
							break;
						}
					break;
				case 506: //Gut Knife
					if (ImGui::Combo(charenc("Gut Knife"), &Vars.weapons[cw].VremennyiKnife, GutKnife, IM_ARRAYSIZE(GutKnife)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 419;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 421;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 415;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 416;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 417;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 26:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
							// íîâûå ñêèíû
						case 27:
							Vars.weapons[cw].SkinsWeapon = 569;
							break;
						case 28:
							Vars.weapons[cw].SkinsWeapon = 570;
							break;
						case 29:
							Vars.weapons[cw].SkinsWeapon = 571;
							break;
						case 30:
							Vars.weapons[cw].SkinsWeapon = 572;
							break;
						case 31:
							Vars.weapons[cw].SkinsWeapon = 568;
							break;
						case 32:
							Vars.weapons[cw].SkinsWeapon = 581;
							break;
						case 33:
							Vars.weapons[cw].SkinsWeapon = 582;
							break;
						case 34:
							Vars.weapons[cw].SkinsWeapon = 560;   // ðàçíîå ó íîæåé
							break;
						case 35:
							Vars.weapons[cw].SkinsWeapon = 575;  //ðàçíîå
							break;
						case 36:
							Vars.weapons[cw].SkinsWeapon = 578;
							break;
						case 37:
							Vars.weapons[cw].SkinsWeapon = 565;  //ðàçíîå
							break;
						default:
							break;
						}
					break;
				case 507: //Karambit
					if (ImGui::Combo(charenc("Karambit"), &Vars.weapons[cw].VremennyiKnife, Karambit, IM_ARRAYSIZE(Karambit)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 419;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 421;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 415;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 416;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 417;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 26:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
							// íîâûå ñêèíû
						case 27:
							Vars.weapons[cw].SkinsWeapon = 569;
							break;
						case 28:
							Vars.weapons[cw].SkinsWeapon = 570;
							break;
						case 29:
							Vars.weapons[cw].SkinsWeapon = 571;
							break;
						case 30:
							Vars.weapons[cw].SkinsWeapon = 572;
							break;
						case 31:
							Vars.weapons[cw].SkinsWeapon = 568;
							break;
						case 32:
							Vars.weapons[cw].SkinsWeapon = 581;
							break;
						case 33:
							Vars.weapons[cw].SkinsWeapon = 582;
							break;
						case 34:
							Vars.weapons[cw].SkinsWeapon = 561;   // ðàçíîå ó íîæåé
							break;
						case 35:
							Vars.weapons[cw].SkinsWeapon = 576;  //ðàçíîå
							break;
						case 36:
							Vars.weapons[cw].SkinsWeapon = 578;
							break;
						case 37:
							Vars.weapons[cw].SkinsWeapon = 566;  //ðàçíîå
							break;
						default:
							break;
						}
					break;
				case 508: //M9 Bayonet
					if (ImGui::Combo(charenc("M9 Bayonet"), &Vars.weapons[cw].VremennyiKnife, M9Bayonet, IM_ARRAYSIZE(M9Bayonet)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 419;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 421;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 20:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 21:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 22:
							Vars.weapons[cw].SkinsWeapon = 415;
							break;
						case 23:
							Vars.weapons[cw].SkinsWeapon = 416;
							break;
						case 24:
							Vars.weapons[cw].SkinsWeapon = 417;
							break;
						case 25:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 26:
							Vars.weapons[cw].SkinsWeapon = 323;
							break;
							// íîâûå ñêèíû
						case 27:
							Vars.weapons[cw].SkinsWeapon = 569;
							break;
						case 28:
							Vars.weapons[cw].SkinsWeapon = 570;
							break;
						case 29:
							Vars.weapons[cw].SkinsWeapon = 571;
							break;
						case 30:
							Vars.weapons[cw].SkinsWeapon = 572;
							break;
						case 31:
							Vars.weapons[cw].SkinsWeapon = 568;
							break;
						case 32:
							Vars.weapons[cw].SkinsWeapon = 581;
							break;
						case 33:
							Vars.weapons[cw].SkinsWeapon = 582;
							break;
						case 34:
							Vars.weapons[cw].SkinsWeapon = 562;   // ðàçíîå ó íîæåé
							break;
						case 35:
							Vars.weapons[cw].SkinsWeapon = 577;  //ðàçíîå
							break;
						case 36:
							Vars.weapons[cw].SkinsWeapon = 578;
							break;
						case 37:
							Vars.weapons[cw].SkinsWeapon = 567;  //ðàçíîå
							break;
						default:
							break;
						}
					break;
				case 509: //Huntsman Knife
					if (ImGui::Combo(charenc("Huntsman Knife"), &Vars.weapons[cw].VremennyiKnife, HuntsmanKnife, IM_ARRAYSIZE(HuntsmanKnife)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						default:
							break;
						}
					break;
				case 512: //Falchion Knife
					if (ImGui::Combo(charenc("Falchion Knife"), &Vars.weapons[cw].VremennyiKnife, FalchionKnife, IM_ARRAYSIZE(FalchionKnife)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						default:
							break;
						}
					break;
				case 515: //Butterfly Knife
					if (ImGui::Combo(charenc("Butterfly Knife"), &Vars.weapons[cw].VremennyiKnife, ButterflyKnife, IM_ARRAYSIZE(ButterflyKnife)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						default:
							break;
						}
					break;
				case 516: //Shadow Daggers
					if (ImGui::Combo(charenc("Shadow Daggers"), &Vars.weapons[cw].VremennyiKnife, ShadowDaggers, IM_ARRAYSIZE(ShadowDaggers)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						default:
							break;
						}
					break;
				case 514: //bowie
					if (ImGui::Combo(charenc("Bowie Knife"), &Vars.weapons[cw].VremennyiKnife, Bowie, IM_ARRAYSIZE(Bowie)))


						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 77;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 40;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 143;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 72;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 5;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 43;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 175;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 44;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 59;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 38;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 12;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 414;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 410;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 98;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 409;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 413;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 418;
							break;
						case 19:
							Vars.weapons[cw].SkinsWeapon = 420;
							break;
						}
					break;
				case 25:	//xm1014
					if (ImGui::Combo(charenc("XM1014"), &Vars.weapons[cw].VremennyiKnife, XM1014, IM_ARRAYSIZE(XM1014)))

						switch (Vars.weapons[cw].VremennyiKnife)
						{
						case 1:
							Vars.weapons[cw].SkinsWeapon = 166;
							break;
						case 2:
							Vars.weapons[cw].SkinsWeapon = 238;
							break;
						case 3:
							Vars.weapons[cw].SkinsWeapon = 27;
							break;
						case 4:
							Vars.weapons[cw].SkinsWeapon = 42;
							break;
						case 5:
							Vars.weapons[cw].SkinsWeapon = 96;
							break;
						case 6:
							Vars.weapons[cw].SkinsWeapon = 95;
							break;
						case 7:
							Vars.weapons[cw].SkinsWeapon = 135;
							break;
						case 8:
							Vars.weapons[cw].SkinsWeapon = 151;
							break;
						case 9:
							Vars.weapons[cw].SkinsWeapon = 235;
							break;
						case 10:
							Vars.weapons[cw].SkinsWeapon = 169;
							break;
						case 11:
							Vars.weapons[cw].SkinsWeapon = 240;
							break;
						case 12:
							Vars.weapons[cw].SkinsWeapon = 251;
							break;
						case 13:
							Vars.weapons[cw].SkinsWeapon = 393;
							break;
						case 14:
							Vars.weapons[cw].SkinsWeapon = 320;
							break;
						case 15:
							Vars.weapons[cw].SkinsWeapon = 314;
							break;
						case 16:
							Vars.weapons[cw].SkinsWeapon = 348;
							break;
						case 17:
							Vars.weapons[cw].SkinsWeapon = 370;
							break;
						case 18:
							Vars.weapons[cw].SkinsWeapon = 407;
							break;
						}
					break;
				default:
					break;
				}
			}
			else
				ImGui::Text(charenc("Invalid Weapon/Isn't Alive"));


				if (cw == 59 || cw == 500 || cw == 42 || cw == 507 || cw == 506 || cw == 508 || cw == 509 || cw == 515 || cw == 516 || cw == 505 || cw == 512)
				{
					//pfix
					Vars.weapons[cw].Stikers1 = 0;
					Vars.weapons[cw].Stikers2 = 0;
					Vars.weapons[cw].Stikers3 = 0;
					Vars.weapons[cw].Stikers4 = 0;
				}
				else
				{
					ImGui::InputInt(charenc("Stikers1"), &Vars.weapons[cw].Stikers1);
					ImGui::InputInt(charenc("Stikers2"), &Vars.weapons[cw].Stikers2);
					ImGui::InputInt(charenc("Stikers3"), &Vars.weapons[cw].Stikers3);
					ImGui::InputInt(charenc("Stikers4"), &Vars.weapons[cw].Stikers4);

					ImGui::SliderFloat(charenc("Wear"), &Vars.weapons[cw].ChangerWear, 0, 1);
					ImGui::InputInt(charenc("StatTrak"), &Vars.weapons[cw].ChangerStatTrak);
					ImGui::InputText(charenc("Name"), Vars.weapons[cw].ChangerName, 32);
				}
		}
		ImGui::PopFont();
	}
	ImGui::EndChild();
}

void ragebottab()
{
	ImGui::PushFont(menu_font);
	ImGui::Text(("     General"));
	ImGui::SameLine();
	ImGui::Text(("          Accurary"));
	ImGui::SameLine();
	ImGui::Text(("            Other"));
	ImGui::PopFont();
	ImGui::BeginChild("general", ImVec2(220, 175), true);
	{
		ImGui::PushFont(smallmenu_font);
		

		ImGui::Checkbox(XorStr("Ragebot Enabled"), &Vars.Ragebot.Enabled);

		ImGui::Combo(XorStr("Hitbox"), &Vars.Ragebot.pHitBox, XorStr("PELVIS\0\rHIP\0\Body\0\rNECK\0\rHEAD\0\0"), -1);//XorStr("PELVIS\0\r\0\r\0\rHIP\0\rLOWER SPINE\0\rMIDDLE SPINE\0\rUPPER SPINE\0\rNECK\0\rHEAD\0\rNEAREST\0\0")

		switch (Vars.Ragebot.pHitBox)
		{
		case 0:
			Vars.Ragebot.Hitbox = 0;
			break;
		case 1:
			Vars.Ragebot.Hitbox = 3;
			break;
		case 2:
			Vars.Ragebot.Hitbox = 5;
			break;
		case 3:
			Vars.Ragebot.Hitbox = 7;
			break;
		case 4:
			Vars.Ragebot.Hitbox = 8;
			break;
		default:
			break;
		}

		ImGui::Checkbox(XorStr("On Key"), &Vars.Ragebot.Hold);
		if (Vars.Ragebot.Hold)
			ImGui::Combo(XorStr("Key"), &Vars.Ragebot.HoldKey, keyNames, IM_ARRAYSIZE(keyNames));
		ImGui::Checkbox(XorStr("Auto Fire"), &Vars.Ragebot.AutoFire);
		ImGui::Checkbox(XorStr("AutoPistol"), &Vars.Ragebot.AutoPistol);
		ImGui::SliderFloat(XorStr("FOV"), &Vars.Ragebot.FOV, 1.f, 180.f, "%.0f");
		//ImGui::Separator();


		ImGui::PopFont();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("accurary", ImVec2(220, 175), true);
	{
		ImGui::PushFont(smallmenu_font);
		
		ImGui::Text(XorStr("Resolver"));
		ImGui::Combo(XorStr("##RESOLV"), &Vars.Ragebot.Antiaim.Resolver, XorStr("Disabled\0\Enabled\0\0"), -1);
		ImGui::Text(XorStr("Hitscan"));
		ImGui::Combo(XorStr("##Hitscan"), &Vars.Ragebot.ResolverHelper, XorStr("No\0\rLow\0\rMedium\0\rHigh\0\0"), -1);
		ImGui::Checkbox(XorStr("Auto Stop"), &Vars.Ragebot.AutoStop);
	

		ImGui::Checkbox(XorStr("Auto Crouch"), &Vars.Ragebot.AutoCrouch);
		ImGui::Checkbox(XorStr("Auto Scope"), &Vars.Ragebot.AutoScope);


		ImGui::Checkbox(XorStr("NoRecoil"), &Vars.Ragebot.RRCS);
		if (Vars.Ragebot.RRCS)
			Vars.Ragebot.RCS = 1;
		else
			Vars.Ragebot.RCS = 0;

		if (Vars.Ragebot.RCS == 2) {
			ImGui::SameLine();
			ImGui::SliderFloat(XorStr("##RCSForce"), &Vars.Ragebot.RCShow, 1.f, 100.f, "%.0f");
		}
		



		ImGui::PopFont();
	}ImGui::EndChild();


	ImGui::SameLine();
	ImGui::BeginChild("othershitxd", ImVec2(220, 175), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::SliderFloat(XorStr("Hit Chance"), &Vars.Ragebot.HitChanceAmt, 1.f, 100.f, "%.1f");
		ImGui::SliderFloat(XorStr("Min Damage"), &Vars.Ragebot.AutoWallDmg, 0.1f, 120.f, "%.1f");
		ImGui::Checkbox(XorStr("Silent"), &Vars.Ragebot.Silent);
		ImGui::Checkbox(XorStr("pSilent"), &Vars.Ragebot.pSilent);
		ImGui::Combo(XorStr("Hitscan"), &Vars.Ragebot.HitScan, charenc("Off\0\rSelected\0\0"), -1);
		ImGui::Text(XorStr("Hitscan Group"));
		ImGui::Checkbox(XorStr("Low"), &Vars.Ragebot.HLow);
		if (Vars.Ragebot.HLow)
		{
			Vars.Ragebot.bones[HITBOX_HEAD] = true;
			Vars.Ragebot.bones[HITBOX_NECK] = true;
			Vars.Ragebot.bones[HITBOX_PELVIS] = false;
			Vars.Ragebot.bones[HITBOX_SPINE] = false;
			Vars.Ragebot.bones[HITBOX_LEGS] = false;
			Vars.Ragebot.bones[HITBOX_ARMS] = false;
		}

		ImGui::Checkbox(XorStr("Full"), &Vars.Ragebot.HALL);
		if (Vars.Ragebot.HALL)
		{
			Vars.Ragebot.bones[HITBOX_HEAD] = true;
			Vars.Ragebot.bones[HITBOX_NECK] = true;
			Vars.Ragebot.bones[HITBOX_PELVIS] = true;
			Vars.Ragebot.bones[HITBOX_SPINE] = true;
			Vars.Ragebot.bones[HITBOX_LEGS] = true;
			Vars.Ragebot.bones[HITBOX_ARMS] = true;
		}


		ImGui::PopFont();
	}ImGui::EndChild();


	ImGui::PushFont(menu_font);
	ImGui::Text(("       Scans"));
	ImGui::SameLine();
	ImGui::Text(("            Anti-aim"));
	ImGui::SameLine();
	ImGui::Text(("              Addone"));
	ImGui::PopFont();
	ImGui::BeginChild("scans", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);
		

		///ImGui::Checkbox(XorStr("Auto Wall"), &Vars.Ragebot.AutoWall);
	//	ImGui::Text(XorStr("Min Damage"));

		

		ImGui::Checkbox(XorStr("Disable AntiAim Knife"), &Vars.Ragebot.Antiaim.knife_held);
		

		ImGui::PopFont();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("aa", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);
		
		ImGui::Checkbox(XorStr("AA Enabled"), &Vars.Ragebot.Antiaim.Enabled);
	//	ImGui::Checkbox(XorStr("FakeAA"), &Vars.Ragebot.Antiaim.FakeYaw);
		ImGui::Checkbox(XorStr("At Target"), &Vars.Ragebot.Antiaim.AtPlayer);
		ImGui::Checkbox(XorStr("Untrasted"), &Vars.Ragebot.UntrustedCheck);
		static const char* pitch[] = {
			"Disabled",
			"Down", // 180
			"Emotion", // 89
			"Fake-Down", // 180.17
			"Fake-Up", // 271, -271
			"Fake-Zero",
			"Fake-Zero2",
			"pHake",
			"Lowerbody",
			"Custom"
		};
		static const char* yaw[] = {
			"Off",//0
			"Static",//1
			"Spinbot",//2
			"Jitter",//3
			"Jitter synced",//4
			"180z",//5
			"Backward Spin",
			"Spin"
		};

		ImGui::Combo("Pitch Stand", &Vars.Ragebot.AntiAim.Pitch, pitch, ARRAYSIZE(pitch));
		ImGui::Combo("Real Stand Yaw", &Vars.Ragebot.AntiAim.RealYaw, yaw, ARRAYSIZE(yaw));
		ImGui::Combo("Fake Stand Yaw", &Vars.Ragebot.AntiAim.FakeYaw, yaw, ARRAYSIZE(yaw));
		ImGui::SliderInt("Custom Yaw", &Vars.Ragebot.AntiAim.cX, -180, 180);
		ImGui::SliderInt("Custom Pitch", &Vars.Ragebot.AntiAim.cY, -180, 180);
		ImGui::Separator();

		ImGui::Combo("Pitch Move", &Vars.Ragebot.AntiAim.Move.Pitch, pitch, ARRAYSIZE(pitch));
		ImGui::Combo("Real Move Yaw", &Vars.Ragebot.AntiAim.Move.Yaw, yaw, ARRAYSIZE(yaw));
		ImGui::Combo("Fake Move Yaw", &Vars.Ragebot.AntiAim.Move.FakeYaw, yaw, ARRAYSIZE(yaw));

		ImGui::Separator();

		


		

		ImGui::Combo(XorStr("Pitch"), &Vars.Ragebot.Antiaim.Pitch, charenc("Unselected\0\rUP\0\rDOWN\0\rJITTER\0\rZERO\0\rEmotion\0\rDOWN JITTER\0\rEmDown\0\0"), -1);
		ImGui::Combo(XorStr("Yaw"), &Vars.Ragebot.Antiaim.YawReal, charenc("Unselected\0\rSPIN\0\rDestroy LBY\0\rSIDEWAYS1\0\rSIDEWAYS2\0\rBACKWARDS\0\rLEFT\0\rRIGHT\0\rZERO\0\rFAKESPIN\0\rLowerBody\0\rLFAKESPIN\0\rMSPIN\0\rFAKE\0\0"), -1);
		ImGui::Combo(XorStr("FakeAA"), &Vars.Ragebot.Antiaim.YawFake, charenc("Unselected\0\rSPIN\0\rJITTER\0\rSIDEWAYS1\0\rSIDEWAYS2\0\rBACKWARDS\0\rLEFT\0\rRIGHT\0\rZERO\0\rFAKESPIN\0\rLowerBody\0\rLFAKESPIN\0\rMSPIN\0\rFAKE\0\0"), -1);



		ImGui::PopFont();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::SameLine();
	ImGui::BeginChild("aaanotherxd", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::Checkbox("Freestanding", &Vars.Ragebot.AntiAim.Freestading);
		ImGui::Checkbox("No Knife", &Vars.Ragebot.Antiaim.knife_held);
		ImGui::SliderFloat("Jitter Range", &Vars.Ragebot.AntiAim.JitterRange, 0, 180, "%.1f");
		ImGui::SliderFloat("Jitter Synced Range", &Vars.Ragebot.AntiAim.JitterRange2, 0, 180, "%.1f");
		ImGui::SliderFloat("Spin Speed", &Vars.Ragebot.AntiAim.SpinSpeed, 0, 20, "%.1f");
		ImGui::SliderFloat("LBY Delta", &Vars.Ragebot.AntiAim.lby_delta, -180, 180, "%.1f");
		ImGui::Checkbox("Fakelag", &Vars.Ragebot.AntiAim.FakeLagEnable);
		static const char* fakelag[] = {
			"Factor",
			"Switch",
			"Fluctuate"
		};
		if (Vars.Ragebot.AntiAim.FakeLagEnable)
		{
			ImGui::Combo("Type", &Vars.Ragebot.AntiAim.FakeLag, fakelag, ARRAYSIZE(fakelag));
			ImGui::SliderInt("Choke", &Vars.Ragebot.AntiAim.FakeLagAmount, 1, 14);
			ImGui::Checkbox("In air only", &Vars.Ragebot.AntiAim.FakeLagInAirOnly);
		}
		ImGui::Checkbox("Fake Walk", &Vars.Ragebot.AntiAim.FakeWalk);
		ImGui::Combo("Key", &Vars.Ragebot.AntiAim.FakeWalkButton, keyNames, ARRAYSIZE(keyNames));
		
	
		ImGui::PopFont();
	}ImGui::EndChild();
}






void visualstab()
{

	ImGui::PushFont(menu_font);
	ImGui::Text(("     Visuals"));
	ImGui::SameLine();
	ImGui::Text(("           Chams"));
	ImGui::SameLine();
	ImGui::Text(("             Removals"));
	ImGui::PopFont();

	ImGui::BeginChild("box", ImVec2(220, 175), true);
	{

		const char* weptype[] =
		{
			"type1",
			"type2"

		};

		const char* HitmarkSound[] =
		{
			"Disabled",
			"Default",
			"Roblox",
			"China",
			"Metallic",
			"Hitler",
			"Jeff",
			"Boom",
			"Gah",
			"Pak",
			"Skidiki",
			"Skkra",
			"tap1",
			"tap2",
			"tap3",
			"tap4",
			"tap5",
			"bameware",
			"bubble",
			"hammer",
			"error",
			"call1",
			"call2",
			"call3",
			"call4",
			"call5"

		};
		ImGui::PushFont(smallmenu_font);
		ImGui::Checkbox(("Enabled"), &Vars.Visuals.Visualsxd.Enabled);
		ImGui::Checkbox(("Box"), &Vars.Visuals.Visualsxd.Visuals_BoxEnabled);
		ImGui::Combo(("BoxType"), &Vars.Visuals.Visualsxd.Visuals_BoxType, weptype, ARRAYSIZE(weptype));
	//	ImGui::Checkbox("OffScreen", &Vars.Visuals.offscreenesp);
		ImGui::Checkbox(("Esp team"), &Vars.Visuals.Visualsxd.Visuals_EspTeam); 
		ImGui::Checkbox(("Name"), &Vars.Visuals.Visualsxd.Visuals_Name);
		ImGui::Checkbox(("Health"), &Vars.Visuals.Visualsxd.Visuals_HealthBar);
		ImGui::Checkbox(("AimLines"), &Vars.Visuals.Visualsxd.Visuals_AimLines);
		ImGui::Checkbox(("Weapons"), &Vars.Visuals.Visualsxd.Visuals_Weapons);
		ImGui::Combo(("WeaponType"), &Vars.Visuals.Visualsxd.Visuals_WeaponsType, weptype, ARRAYSIZE(weptype));
		ImGui::Checkbox(("Ammo"), &Vars.Visuals.Visualsxd.Visuals_AmmoESP);
		ImGui::Combo(("AmmoType"), &Vars.Visuals.Visualsxd.Visuals_AmmoESPType, weptype, ARRAYSIZE(weptype));
		//ImGui::Checkbox(("Scoped"), &Menu.Visuals.Visualsxd.Visuals_Scoped);
		//ImGui::Checkbox(("Flashed"), &Menu.Visuals.Visualsxd.Visuals_Flashed);
		ImGui::Checkbox(("DamageEsp"), &Vars.Visuals.Visualsxd.Visuals_DamageESP);
		ImGui::SameLine(ImGui::GetWindowWidth() - 25);
		ImGui::ColorEdit4(("##DamageEspColor"), Vars.Visuals.Visualsxd.DamageESPColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		//ImGui::Checkbox(("Eventlog"), &Vars.Visuals.Visualsxd.eventlog_enabled);
		ImGui::Combo(("Hitsound"), &Vars.Visuals.Visualsxd.Hitsound, HitmarkSound, ARRAYSIZE(HitmarkSound));
		ImGui::Checkbox(("Skeletons"), &Vars.Visuals.Visualsxd.Visuals_Skeltal);
		ImGui::PopFont();



	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("chams", ImVec2(220, 175), true);
	{
		//Vars.Visuals.ColorsChamsEnemyWallColor
		ImGui::PushFont(smallmenu_font);
		const char *opt_Chams[] = { "Textured", "Textured XQZ", "Flat", "Flat XQZ" };

		ImGui::Checkbox("Chams##ESP", &Vars.Visuals.esp_player_chams);
		ImGui::Combo("Chams Type##ESP", &Vars.Visuals.esp_player_chams_type, opt_Chams, 4);
		

	

		ImGui::PopFont();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("asdgsadg", ImVec2(220, 175), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::Checkbox(XorStr("No Vis Recoil"), &Vars.Visuals.RemovalsVisualRecoil);
		ImGui::Checkbox(XorStr("No Flash"), &Vars.Visuals.RemovalsFlash);
		ImGui::Checkbox(XorStr("No Scope"), &Vars.Visuals.NoScope);
		ImGui::Checkbox(XorStr("ThirdPerson"), &Vars.Visuals.thirdperson.enabled);
		ImGui::SliderFloat(XorStr("Distance"), &Vars.Visuals.thirdperson.distance, 30.f, 200.f, "%.0f");
		ImGui::Checkbox(XorStr("C4"), &Vars.Visuals.Filter.C4);
		ImGui::Checkbox(XorStr("SpectatorList"), &Vars.Visuals.SpectatorList);
		ImGui::Checkbox(XorStr("Weapons"), &Vars.Visuals.Filter.Weapons);
		ImGui::Text(XorStr("Override Fov"));
		ImGui::SameLine();
		ImGui::SliderInt(XorStr("##OverrideFov"), &Vars.Misc.fov, -70, 70);
		ImGui::Text(XorStr("ViewModel Fov"));
		ImGui::SameLine();
		ImGui::SliderInt(XorStr("##ViewFov"), &Vars.Visuals.ViewmodelFov, -70, 70);



		ImGui::PopFont();
	}ImGui::EndChild();


	ImGui::PushFont(menu_font);
	ImGui::Text(("        Glow"));
	ImGui::SameLine();
	ImGui::Text(("             Colors"));
	ImGui::SameLine();
	ImGui::Text(("              Other"));
	ImGui::PopFont();
	ImGui::BeginChild("glow", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);

		const char *opt_GlowStyles[] = { "Outline outer", "Cover", "Outline inner" };

		ImGui::Checkbox("Enable Glow##Glow", &Vars.Visuals.glow_enabled);
		ImGui::Checkbox("Players##Glow", &Vars.Visuals.glow_players);
		ImGui::Combo("Glow type players##ESP_player", &Vars.Visuals.glow_players_style, opt_GlowStyles, 3);
		ImGui::Checkbox("Others##Glow", &Vars.Visuals.glow_others);
		ImGui::Combo("Glow type others##ESP_other", &Vars.Visuals.glow_others_style, opt_GlowStyles, 3);
	

		ImGui::PopFont();
	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("aa", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::Text(("Box Colors"));
		ImGui::ColorEdit4(("CT Visible##box"), Vars.Visuals.Visualsxd.BoxColorPickCTVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("CT invisible##box"), Vars.Visuals.Visualsxd.BoxColorPickCTINVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T Visible##box"), Vars.Visuals.Visualsxd.BoxColorPickTVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T invisible##box"), Vars.Visuals.Visualsxd.BoxColorPickTINVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::Text(("Sceletons Colors"));
		ImGui::ColorEdit4(("CT Visible##skel"), Vars.Visuals.Visualsxd.SkeletonCTVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("CT invisible##skel"), Vars.Visuals.Visualsxd.SkeletonCTINVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T Visible##skel"), Vars.Visuals.Visualsxd.SkeletonTVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T invisible##skel"), Vars.Visuals.Visualsxd.SkeletonTINVIS, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::Text(("Glow Colors"));
		ImGui::ColorEdit4(("CT Visible##glow"), Vars.Visuals.glow_player_color_ct_visible, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("CT invisible##glow"), Vars.Visuals.glow_player_color_ct, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T Visible##glow"), Vars.Visuals.glow_player_color_t_visible, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T invisible##glow"), Vars.Visuals.glow_player_color_t, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("Other##glow"), Vars.Visuals.glow_player_other, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::Text(("Chams Colors"));
		ImGui::ColorEdit4(("CT Visible##chams"), Vars.Visuals.esp_player_chams_color_ct_visible, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("CT invisible##chams"), Vars.Visuals.esp_player_chams_color_ct, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T Visible##chams"), Vars.Visuals.esp_player_chams_color_t_visible, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		ImGui::ColorEdit4(("T invisible##chams"), Vars.Visuals.esp_player_chams_color_t, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		//ImGui::Text(("Backtrack Colors"));
		//ImGui::ColorEdit4(("Line##back"), Vars.Visuals.linecolors, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		//ImGui::ColorEdit4(("Chams##back"), Vars.Visuals.backtrackchamscolor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		//ImGui::ColorEdit4(("Skeleton##back"), Vars.Visuals.backtrackskeletcolor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);


		ImGui::PopFont();

	}ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("asdscans", ImVec2(220, 150), true);
	{
		ImGui::PushFont(smallmenu_font);

		ImGui::Checkbox("Bullet tracer##Other", &Vars.Visuals.BulletTracers);
		ImGui::SameLine(ImGui::GetWindowWidth() - 25);
		ImGui::ColorEdit4(("Color##bullet"), Vars.Visuals.Bulletracer, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_AlphaBar);
		//ImGui::Checkbox("Show Real Angels##Other", &Vars.Misc.showrealangels);
		//ImGui::Checkbox("Thirdperson##Other", &Vars.Misc.misc_thirdperson);
		//ImGui::Checkbox("Manualindicator##adg", &Vars.Visuals.manualindicator);
		//ImGui::Checkbox("C4##adasdgg", &Vars.Visuals.Visualsxd.Visuals_C4);
		//ImGui::Checkbox("Dropped weapons##adsdfg", &Vars.Visuals.Visualsxd.Visuals_DroppedWeapons);
		//ImGui::Checkbox("Eventlog", &Vars.Visuals.Visualsxd.Visuals_DrawEventLog);


		ImGui::PopFont();

	}ImGui::EndChild();

}















bool EntityIsInvalid(CBaseEntity* Entity)
{
	//HANDLE obs = Entity->GetObserverTargetHandle();
	//CBaseEntity *pTarget = I::ClientEntList->GetClientEntityFromHandle(obs);
	if (!Entity)
		return true;
	//if (Entity == pTarget)
	//return true;
	if (Entity->GetHealth() <= 0)
		return true;
	

	return false;
}

static char ConfigName[64] = { 0 };
namespace ImGui
{

	static auto vector_getterlol = [](void* vec, int idx, const char** out_text)
	{
		auto& vector = *static_cast<std::vector<std::string>*>(vec);
		if (idx < 0 || idx >= static_cast<int>(vector.size())) { return false; }
		*out_text = vector.at(idx).c_str();
		return true;
	};

	IMGUI_API bool ComboBoxArray(const char* label, int* currIndex, std::vector<std::string>& values)
	{
		if (values.empty()) { return false; }
		return Combo(label, currIndex, vector_getterlol,
			static_cast<void*>(&values), values.size());
	}


}
void misctab()
{
	ImGui::PushFont(menu_font);
	ImGui::Text(("     General"));
	ImGui::SameLine();
	ImGui::Text(("                  Configs"));

	ImGui::PopFont();
	ImGui::BeginChild("general", ImVec2(220, 320), true);
	{
		ImGui::PushFont(smallmenu_font);
		ImGui::Checkbox(XorStr("Bunny Hop"), &Vars.Misc.Bhop);
		ImGui::Checkbox(XorStr("Ranks Reveal"), &Vars.Misc.Ranks); 
		ImGui::Checkbox(XorStr("AutoAccept"), &Vars.Misc.AutoAccept);
		ImGui::Checkbox(XorStr("Radar"), &Vars.Visuals.Radar.Enabled); 
		ImGui::Checkbox(XorStr("Radar Nick"), &Vars.Visuals.Radar.Nicks);
		ImGui::SliderInt(XorStr("Radar Range"), &Vars.Visuals.Radar.range, 0, 10);
		ImGui::Checkbox(XorStr("Chat Spam"), &Vars.Misc.ChatSpam);
		ImGui::InputText(XorStr("Spam Text"), Vars.Misc.SpamText, 30);
		ImGui::PopFont();
	}
	ImGui::EndChild();
	ImGui::SameLine();
	ImGui::BeginChild("5e6gtvref", ImVec2(300, 150), true);
	{
		ImGui::PushFont(smallmenu_font);
		{
			ImGui::InputText("##CFG", ConfigName, 64);
			static int sel;
			std::string config;
			std::vector<std::string> configs = Vars.GetConfigs();
			if (configs.size() > 0) {
				ImGui::ComboBoxArray("Configs", &sel, configs);
				ImGui::Spacing();
				ImGui::Separator();
				ImGui::Spacing();
				ImGui::PushItemWidth(220.f);
				config = configs[Vars.config_sel];
			}
			Vars.config_sel = sel;

			if (configs.size() > 0) {
				if (ImGui::Button("Load", ImVec2(50, 20)))
				{
					Vars.Load(config);
				}
			}
			ImGui::SameLine();

			if (configs.size() >= 1) {
				if (ImGui::Button("Save", ImVec2(50, 20)))
				{
					Vars.Save(config);
				}
			}
			ImGui::SameLine();
			if (ImGui::Button("Create", ImVec2(50, 20)))
			{
				std::string ConfigFileName = ConfigName;
				if (ConfigFileName.size() < 1)
				{
					ConfigFileName = "settings";
				}
				Vars.CreateConfig(ConfigFileName);

			}
		}

		//ImGui::Checkbox("NameSpam", &g_Options.Misc.namespam);

		ImGui::PopFont();
	}
	ImGui::EndChild();
}



#include "../icons/LegitBar.h"
#include "../icons/MiscBar.h"
#include "../icons/RageBar.h"
#include "../icons/VisualsBar.h"
#include "../icons/Fon.h"
#include "../icons/Logo.h"
#include "../icons/SkinBar.h"


IDirect3DTexture9 *FonBar1 = nullptr;
IDirect3DTexture9 *FonBar2 = nullptr;
IDirect3DTexture9 *LogoBarr = nullptr;
IDirect3DTexture9 *LegitBar = nullptr;
IDirect3DTexture9 *RageBar = nullptr;
IDirect3DTexture9 *VisualsBar = nullptr;
IDirect3DTexture9 *SkinsBar = nullptr;
IDirect3DTexture9 *MiscBar = nullptr;



void ConfigTab()
{
	/*ImGui::InputText(XorStr("Config Name"), Vars.Misc.configname, 128);
	ImGui::PushItemWidth(190);
	ImGui::Columns(2, XorStr("##config-settings"), false);
	if (ImGui::Button(XorStr("Save Config"), ImVec2(93.f, 20.f))) Config->Save();
	ImGui::NextColumn();
	if (ImGui::Button(XorStr("Load Config"), ImVec2(93.f, 20.f))) {
		Config->Load(); color();
	}
	ImGui::Columns(1);

	if (ImGui::Button(XorStr("Unload"), ImVec2(93.f, 20.f))) {
		E::Misc->Panic();
	}*/

}

Vector2D RotatePoint(Vector EntityPos, Vector LocalPlayerPos, int posX, int posY, int sizeX, int sizeY, float angle, float zoom, bool* viewCheck, bool angleInRadians = false)
{
	float r_1, r_2;
	float x_1, y_1;

	r_1 = -(EntityPos.y - LocalPlayerPos.y);
	r_2 = EntityPos.x - LocalPlayerPos.x;
	float Yaw = angle - 90.0f;

	float yawToRadian = Yaw * (float)(M_PI / 180.0F);
	x_1 = (float)(r_2 * (float)cos((double)(yawToRadian)) - r_1 * sin((double)(yawToRadian))) / 20;
	y_1 = (float)(r_2 * (float)sin((double)(yawToRadian)) + r_1 * cos((double)(yawToRadian))) / 20;

	*viewCheck = y_1 < 0;

	x_1 *= zoom;
	y_1 *= zoom;

	int sizX = sizeX / 2;
	int sizY = sizeY / 2;

	x_1 += sizX;
	y_1 += sizY;

	if (x_1 < 5)
		x_1 = 5;

	if (x_1 > sizeX - 5)
		x_1 = sizeX - 5;

	if (y_1 < 5)
		y_1 = 5;

	if (y_1 > sizeY - 5)
		y_1 = sizeY - 5;


	x_1 += posX;
	y_1 += posY;


	return Vector2D(x_1, y_1);


	/*if (!angleInRadians)
	angle = (float)(angle * (M_PI / 180));
	float cosTheta = (float)cos(angle);
	float sinTheta = (float)sin(angle);
	Vector2 returnVec = Vector2(
	cosTheta * (pointToRotate.x - centerPoint.x) - sinTheta * (pointToRotate.y - centerPoint.y),
	sinTheta * (pointToRotate.x - centerPoint.x) + cosTheta * (pointToRotate.y - centerPoint.y)
	);
	returnVec += centerPoint;
	return returnVec / zoom;*/
}

void DrawRadar()
{
	//shit
}

EndSceneFn oEndScene;
long __stdcall Hooks::EndScene(IDirect3DDevice9* pDevice)
{
	if (!G::d3dinit)
		GUI_Init(pDevice);


	ImGui::GetIO().MouseDrawCursor = Vars.Menu.Opened;

	ImGui_ImplDX9_NewFrame();

	// backup render states
	static const D3DRENDERSTATETYPE backupStates[] = { D3DRS_COLORWRITEENABLE, D3DRS_ALPHABLENDENABLE, D3DRS_SRCBLEND, D3DRS_DESTBLEND, D3DRS_BLENDOP, D3DRS_FOGENABLE };
	static const int size = sizeof(backupStates) / sizeof(DWORD);

	DWORD oldStates[size] = { 0 };

	for (int i = 0; i < size; i++)
		pDevice->GetRenderState(backupStates[i], &oldStates[i]);

	////////////////////////////////////////////////////////////////////
	// no draw fix
	pDevice->SetRenderState(D3DRS_COLORWRITEENABLE, 0xFFFFFFFF);


	if (Vars.Visuals.Radar.Enabled && I::Engine->IsConnected() && G::LocalPlayer)
		DrawRadar();

	if (Vars.Visuals.SpectatorList)
		E::Visuals->SpecList();
	//watermark xd
	{
		Menu::DrawFilledRectangle(Menu::viewPort.Width - 205, 3, 17, 110, D3DCOLOR_ARGB(230, 15, 15, 15), pDevice);

		static char cTitle[256];
		sprintf_s(cTitle, "FPS: %i", Menu::FrameRate() / 2);


		Menu::DrawStringWithFont(Menu::fntVerdana11, Menu::viewPort.Width - 200, 5, D3D_COLOR_BLACK(240), XorStr(" SKYFALL | %s"), cTitle);
		Menu::DrawStringWithFont(Menu::fntVerdana10, Menu::viewPort.Width - 201, 6, D3D_COLOR_WHITE(240), XorStr(" SKYFALL | %s"), cTitle);
	}


	if (Vars.Visuals.Visualsxd.Monitor)
		Menu::RenderMonitor();


	if (Vars.Menu.Opened)
	{
		ImGui::SetNextWindowSize(ImVec2(900, 630));
		auto style = ImGui::GetStyle();
		POINT mp;

		GetCursorPos(&mp);
		ImGuiIO& io = ImGui::GetIO();
		io.MousePos.x = mp.x;
		io.MousePos.y = mp.y;


		static bool Texturedxd, Textured, Textured2, Textured3, Textured4, Textured5, Textured6, Textured7 = false;
		if (FonBar1 == nullptr && !Textured)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &mygirl, sizeof(mygirl),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &FonBar1);
			Textured = true;
		}

		if (LogoBarr == nullptr && !Textured2)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NewLogo, sizeof(NewLogo),
				120, 120, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &LogoBarr);
			Textured2 = true;
		}
		if (LegitBar == nullptr && !Textured3)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NameLegitArray, sizeof(NameLegitArray),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &LegitBar);
			Textured3 = true;
		}
		if (RageBar == nullptr && !Textured4)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NameRageArray, sizeof(NameRageArray),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &RageBar);
			Textured4 = true;
		}
		if (VisualsBar == nullptr && !Textured5)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NameVisualsArray, sizeof(NameVisualsArray),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &VisualsBar);
			Textured5 = true;
		}
		if (MiscBar == nullptr && !Textured6)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &NameMiscArray, sizeof(NameMiscArray),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &MiscBar);
			Textured6 = true;
		}
		if (SkinsBar == nullptr && !Textured7)
		{
			D3DXCreateTextureFromFileInMemoryEx(pDevice
				, &SkinsArray, sizeof(SkinsArray),
				1000, 1000, D3DX_DEFAULT, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, &SkinsBar);
			Textured7 = true;
		}

		style.Colors[ImGuiCol_Border] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
		ImGui::Begin(XorStr("SKYFALL"), &Vars.Menu.Opened, ImVec2(900, 630), 0.0f, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar);
#pragma region MenuBar
		static int curTab = 0;
		static bool canChange = false;
		static int typehover = 0;
		static int animstage = 0;
		static int spacing = 1;
		static float myalpha = 0.635f;

		if (animstage == 1 || animstage == 237)
		{

			if (myalpha - 0.012 <= 0.86f)
			{
				myalpha += 0.012;
			}
			else
			{
				if (animstage != 237)
					animstage++;
				else
					animstage = 238;
			}

			if (animstage != 237)
				spacing += 4.5;

		}
		if (animstage == 2 || animstage == 238)
		{

			if (myalpha - 0.012 >= 0.635f)
			{
				myalpha -= 0.012;
			}
			else
			{

				if (animstage != 238)
				{
					animstage++;
					canChange = true;
				}
				else
				{
					animstage = 239;
				}
			}
			if (animstage != 238)
				spacing += 0.5;

		}

		ImDrawList* windowDrawList = ImGui::GetWindowDrawList();
		ImVec2 curWindowPos = ImGui::GetWindowPos();

		windowDrawList->AddImage(FonBar1, ImVec2(curWindowPos.x, curWindowPos.y), ImVec2(curWindowPos.x + 750, curWindowPos.y + 425));
		windowDrawList->AddRectFilledMultiColor(ImVec2(curWindowPos.x, curWindowPos.y), ImVec2(curWindowPos.x + 750, curWindowPos.y + 425),
			ImColor(0.07f, 0.07f, 0.07f, myalpha),//Upleft
			ImColor(0.07f, 0.07f, 0.07f, myalpha),//UpRight
			ImColor(0.07f, 0.07f, 0.07f, myalpha),//downleft
			ImColor(0.07f, 0.07f, 0.07f, myalpha));//downright

		windowDrawList->AddRectFilledMultiColor(ImVec2(curWindowPos.x - 5, curWindowPos.y), ImVec2(curWindowPos.x + 750, ImGui::GetWindowPos().y + 30),
			ImColor(0.13f, 0.13f, 0.13f, 0.85f),//Upleft
			ImColor(0.13f, 0.13f, 0.13f, 0.85f),//UpRight
			ImColor(0.13f, 0.13f, 0.13f, 0.85f),//downleft
			ImColor(0.13f, 0.13f, 0.13f, 0.85f));//downright
		windowDrawList->AddImage(LogoBarr, ImVec2(curWindowPos.x + 300, curWindowPos.y), ImVec2(curWindowPos.x + 330, curWindowPos.y + 30));


		ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
		ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.05f, 1.0f, 0.05f, 0.f));
		ImGui::PushStyleColor(ImGuiCol_BorderShadow, ImVec4(0.05f, 1.0f, 0.05f, 0.f));


		static float newanimate = 0.f;
		static float newanimate2 = 0.f;
		static float newanimate2Line = 0.f;
		static float newanimate3Line = 0.f;

		if (animstage >= 3 && animstage != 237 && animstage != 238 && animstage != 239)
		{
			if (ImGui::Button(XorStr("##meme"), ImVec2(38, 20)))
			{
				animstage = 237;
			}
			if (ImGui::IsItemHovered())
			{
				if (newanimate + 0.15f < 27.f)
				{
					newanimate += 0.15f;
				}
				if (newanimate2 + 0.1f < 7.0f)
				{
					newanimate2 += 0.1f;
				}

				if (newanimate > 7.f)
				{
					if (newanimate2Line + 0.15f < 27.f)
					{
						newanimate2Line += 0.15f;
					}
				}
				if (newanimate2Line > 7.f)
				{
					if (newanimate3Line + 0.15f < 27.f)
					{
						newanimate3Line += 0.15f;
					}
				}


			}
			else
			{

				if (newanimate - 0.15f > 0.f)
				{
					newanimate -= 0.15f;
				}
				else
				{
					newanimate = 0.f;
				}

				if (newanimate < 20.f)
				{
					if (newanimate2Line - 0.15f > 0.f)
					{
						newanimate2Line -= 0.15f;
					}
					else
					{
						newanimate2Line = 0.f;
					}
				}
				if (newanimate2Line < 20.f)
				{
					if (newanimate3Line - 0.15f > 0.f)
					{
						newanimate3Line -= 0.15f;
					}
					else
					{
						newanimate3Line = 0.f;
					}
				}


				if (newanimate2 - 0.1f > 0.f)
				{
					newanimate2 -= 0.1f;
				}
				else
				{
					newanimate2 = 0.f;
				}


			}



			windowDrawList->AddRectFilledMultiColor(ImVec2(curWindowPos.x + newanimate2, curWindowPos.y + 8), ImVec2(curWindowPos.x + newanimate2 + newanimate, curWindowPos.y + 11),
				ImColor(newanimate / 27.f, newanimate / 27.f, newanimate / 27.f, 1.f),//Upleft
				ImColor(newanimate / 27.f, newanimate / 27.f, newanimate / 27.f, 1.f),//UpRight
				ImColor(newanimate / 27.f, newanimate / 27.f, newanimate / 27.f, 1.f),//downleft
				ImColor(newanimate / 27.f, newanimate / 27.f, newanimate / 27.f, 1.f));//downright

			windowDrawList->AddRectFilledMultiColor(ImVec2(curWindowPos.x + newanimate2, curWindowPos.y + 14), ImVec2(curWindowPos.x + newanimate2 + newanimate2Line, curWindowPos.y + 17),
				ImColor(newanimate2Line / 27.f, newanimate2Line / 27.f, newanimate2Line / 27.f, 1.f),//Upleft
				ImColor(newanimate2Line / 27.f, newanimate2Line / 27.f, newanimate2Line / 27.f, 1.f),//UpRight
				ImColor(newanimate2Line / 27.f, newanimate2Line / 27.f, newanimate2Line / 27.f, 1.f),//downleft
				ImColor(newanimate2Line / 27.f, newanimate2Line / 27.f, newanimate2Line / 27.f, 1.f));//downright

			windowDrawList->AddRectFilledMultiColor(ImVec2(curWindowPos.x + newanimate2, curWindowPos.y + 20), ImVec2(curWindowPos.x + newanimate2 + newanimate3Line, curWindowPos.y + 23),
				ImColor(newanimate3Line / 27.f, newanimate3Line / 27.f, newanimate3Line / 27.f, 1.f),//Upleft
				ImColor(newanimate3Line / 27.f, newanimate3Line / 27.f, newanimate3Line / 27.f, 1.f),//UpRight
				ImColor(newanimate3Line / 27.f, newanimate3Line / 27.f, newanimate3Line / 27.f, 1.f),//downleft
				ImColor(newanimate3Line / 27.f, newanimate3Line / 27.f, newanimate3Line / 27.f, 1.f));//downright

			ImGui::SameLine(); ImGui::Text("                                                       "); ImGui::SameLine();


		}
		else
		{
			newanimate = 0.f; newanimate2 = 0.f; newanimate2Line = 0.f; newanimate3Line = 0.f;
			ImGui::Text("                               "); ImGui::SameLine();
			ImGui::Text("                                "); ImGui::SameLine();
		}

		ImGui::Text(XorStr("SKYFALL"));

		ImGui::SameLine();
		ImGui::Text("                                                     ");
		ImGui::SameLine();


		{
			static float newanim = 0.f;
			bool hoveret = false;
			static float newanim2 = 0.f;


			if (ImGui::Button(XorStr("##mem2e"), ImVec2(38, 20)))
			{
				Vars.Menu.Opened = false;
			}
			if (ImGui::IsItemHovered())
			{
				hoveret = true;

				if (newanim + 0.2 < 10.f)
				{
					newanim += 0.2;
				}


			}
			else
			{
				hoveret = false;
				if (newanim - 0.2 > 0.f)
				{
					newanim -= 0.2;
				}
				else
				{
					newanim = 0.f;
				}

			}

		}


#pragma endregion





		if (animstage == 1 || animstage == 2 || animstage == 237 || animstage == 238 || animstage == 239)
		{
			ImGui::Spacing(); ImGui::Spacing(); ImGui::Spacing(); ImGui::Spacing();

			for (int i = 0; i < spacing; i++)
			{
				ImGui::Spacing();
			}

		}

		if (animstage == 237 || animstage == 238 || animstage == 239)
		{
			canChange = false;
			if (spacing - 1 >= 0)
				spacing--;
		}

		if (animstage < 3 || animstage == 237 || animstage == 238 || animstage == 239)
		{
			ImGui::Text("          ");
			ImGui::Text("          ");
			ImGui::SameLine();
			if (ImGui::ImageButton(LegitBar, ImVec2(150, 150))) {
				canChange = false;
				curTab = 1;
				animstage = 1;
			}
			ImGui::SameLine();
			ImGui::Text("        ");
			ImGui::SameLine();
			if (ImGui::ImageButton(RageBar, ImVec2(150, 150))) {
				canChange = false;
				curTab = 2;
				animstage = 1;
			}
			ImGui::SameLine();
			ImGui::Text("        ");
			ImGui::SameLine();
			if (ImGui::ImageButton(VisualsBar, ImVec2(150, 150))) {
				canChange = false;
				curTab = 3;
				animstage = 1;
			}

			ImGui::Spacing();
			ImGui::Text("                                ");
			ImGui::SameLine();
			if (ImGui::ImageButton(MiscBar, ImVec2(150, 150))) {
				canChange = false;
				curTab = 4;
				animstage = 1;
			}
			ImGui::SameLine();
			ImGui::Text("        ");
			ImGui::SameLine();
			if (ImGui::ImageButton(SkinsBar, ImVec2(150, 150))) {
				canChange = false;
				curTab = 5;
				animstage = 1;
			}
		}


		ImGui::PopStyleColor();
		ImGui::PopStyleColor();
		ImGui::PopStyleColor();
		ImGui::PopStyleColor();
		ImGui::PopStyleColor();

		//ImGui::PushFont(items::letters);
		switch (curTab)
		{
		case 1: if (canChange)legitbot(); else break; break;
		case 2: if (canChange)ragebottab(); else break; break;
		case 3: if (canChange)visualstab(); else break; break;
		case 4: if (canChange)misctab(); else break; break;
		case 5: if (canChange)skinchangertab(); else break; break;
		default:break;
		}
		//ImGui::PopFont();

		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::End();


	}






	if (Vars.Visuals.Visualsxd.Enabled)
		D9Visuals::Render(pDevice);

	for (int i = 0; i < size; i++)
		pDevice->SetRenderState(backupStates[i], oldStates[i]);

	ImGui::Render();

	
	return oEndScene(pDevice);



}

ResetFn oReset;
long __stdcall Hooks::Reset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentationParameters)
{
	if (!G::d3dinit)
		return oReset(pDevice, pPresentationParameters);

	ImGui_ImplDX9_InvalidateDeviceObjects();

	auto hr = oReset(pDevice, pPresentationParameters);
	ImGui_ImplDX9_CreateDeviceObjects();


	return hr;
}

void GUI_Init(IDirect3DDevice9* pDevice)
{
	ImGui_ImplDX9_Init(G::Window, pDevice);
	pDevice->GetViewport(&Menu::viewPort);
	D3DXCreateFont(pDevice, 9, 0, FW_BOLD, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DRAFT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, ("Verdana"), &Menu::fntVerdana9);
	D3DXCreateFont(pDevice, 10, 5, FW_NORMAL, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, ("Verdana"), &Menu::fntVerdana10);
	D3DXCreateFont(pDevice, 11, 5, FW_NORMAL, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, ("Verdana"), &Menu::fntVerdana11);
	//D3DXCreateFont(pDevice, 12, 5, FW_BOLD, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, ("Verdana"), &Menuxd::fntVerdana12);
	D3DXCreateFont(pDevice, 11, 0, FW_NORMAL, 1, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, ("csgo_icons"), &Menu::fntWeaponIcon);
	
	color();
	G::d3dinit = true;
}









bool D9Visuals::canUseSetupBones = false;
int D9Visuals::PlayerAlpha[65];
int D9Visuals::PlayerNickVal[65];
float D9Visuals::PlayerBoxAlpha[65];
#define PlayerReadyAlpha(x) PlayerAlpha[x->GetIndex()]

void DrawStringWithFontW(LPD3DXFONT fnt, float x, float y, D3DCOLOR color, wchar_t *format, ...)
{
	wchar_t buffer[256];
	RECT fontRect = { (int)x, (int)y, (int)x, (int)y };

	va_list va_argList;

	va_start(va_argList, format);
	wvsprintfW(buffer, format, va_argList);
	va_end(va_argList);

	fnt->DrawTextW(NULL, buffer, -1, &fontRect, DT_NOCLIP, color);
}





void DrawString(float x, float y, D3DCOLOR color, char *format, ...)
{
	char buffer[256];
	RECT fontRect = { (int)x, (int)y, (int)x, (int)y };

	va_list va_argList;

	va_start(va_argList, format);
	wvsprintf(buffer, format, va_argList);
	va_end(va_argList);

	Menu::fntVerdana10->DrawText(NULL, buffer, strlen(buffer), &fontRect, DT_NOCLIP, color);
}
FORCEINLINE float DotProductESP(const Vector& a, const Vector& b)
{
	return (a.x * b.x + a.y * b.y + a.z * b.z);
}

bool CBaseEntity::IsVisibleVector(Vector bone)
{
	if (!this || !G::LocalPlayer)
		return false;

	if (Vars.Visuals.NoScope)
	{
		if (G::LocalPlayer->IsScoped())
		{
			int Width;
			int Height;
			I::Engine->GetScreenSize(Width, Height);

			Color cColor = Color(0, 0, 0, 255);
			D::DrawLine(Width / 2, 0, Width / 2, Height, cColor);
			D::DrawLine(0, Height / 2, Width, Height / 2, cColor);
		}
	}

	Ray_t ray;
	trace_t tr;
	ray.Init(G::LocalPlayer->GetEyePosition(), bone);
	CTraceFilter traceFilter;
	traceFilter.pSkip = G::LocalPlayer;
	I::EngineTrace->TraceRay(ray, MASK_SHOT, &traceFilter, &tr);

	return (tr.m_pEnt == this || tr.IsVisible());
}




bool D9Visuals::Filter(CBaseEntity *entity, bool& IsVis)
{
	if (!entity || !G::LocalPlayer) return true;
	if (!entity->GetAlive()) return true;
	if (entity->GetTeam() == G::LocalPlayer->GetTeam() && !Vars.Visuals.Visualsxd.Visuals_EspTeam) return true;
	if (entity->GetTeam() != 2 && entity->GetTeam() != 3) return true;

	IsVis = (entity->IsVisible(8));
	if (Vars.Visuals.Visualsxd.Visuals_VisableOnly && !IsVis)return true;
	return false;
}



std::string SanitizeNameFST(char *name, int pEntity)
{
	name[127] = '\0';

	std::string tmp(name);

	for (size_t i = 0; i < tmp.length(); i++)
	{
		if ((
			tmp[i] >= 'a' && tmp[i] <= 'z' ||
			tmp[i] >= 'A' && tmp[i] <= 'Z' ||
			tmp[i] >= '0' && tmp[i] <= '9' ||
			tmp[i] == ' ' || tmp[i] == '.' || tmp[i] == '/' || tmp[i] == ':' ||
			tmp[i] == ',' || tmp[i] == '_' || tmp[i] == '#' || tmp[i] == '$' ||
			tmp[i] == '<' || tmp[i] == '>' || tmp[i] == '-' || tmp[i] == '+' ||
			tmp[i] == '*' || tmp[i] == '%' || tmp[i] == '@' || tmp[i] == '(' ||
			tmp[i] == ')' || tmp[i] == '{' || tmp[i] == '}' || tmp[i] == '[' || tmp[i] == ']' ||
			tmp[i] == '!' || tmp[i] == '&' || tmp[i] == '~' || tmp[i] == '^'
			) == false)
		{
			tmp[i] = '_';
		}
	}
	if (pEntity)
	{
		if (tmp.length() > (size_t)(20 * D9Visuals::PlayerNickVal[pEntity] / 100))
		{
			tmp.erase((20 * D9Visuals::PlayerNickVal[pEntity] / 100), (tmp.length() - (20 * D9Visuals::PlayerNickVal[pEntity] / 100)));
			tmp.append("...");
		}
	}
	else
	{
		if (tmp.length() > (20))
		{
			tmp.erase(20, (tmp.length() - 20));
			tmp.append("...");
		}
	}
	return tmp;
}

void D9Visuals::DrawName(CBaseEntity *entity)
{
	
	player_info_t info;
	I::Engine->GetPlayerInfo(entity->GetIndex(), &info);


	float height, width, x, y;

	if (GetPlayerBox(entity, x, y, width, height))
	{
		//	int da = GetDormantAlpha(entity) + 55;
		float _x = x;
		float _y = y;

		auto outlineColor = D3D_COLOR_BLACK(PlayerReadyAlpha(entity));
		auto textColor = D3D_COLOR_WHITE(PlayerReadyAlpha(entity));

		std::string name = SanitizeNameFST(info.name, entity->GetIndex());

		_x += (width / 2.f) - Menu::GetTextWitdh((char*)name.c_str(), Menu::fntVerdana10) / 2.f;
		_y -= 8.f;
		DrawString(_x, _y - 3.f, outlineColor, "%s", (char*)name.c_str());
		DrawString(_x, _y - 2.f, textColor, "%s", (char*)name.c_str());

	}
}





bool D9Visuals::GetPlayerBox(CBaseEntity *entity, float &x, float &y, float &width, float &height, Vector offset)
{
	Vector top, down, s[2];

	Vector adjust = Vector(0, 0, -16) * entity->GetEyeAnglesxd();

	down = entity->GetAbsOrigin()/*G::absOriginCache[entity->GetIndex()]*/ - Vector(0, 0, 1);//entity->GetRenderOrigin(); //entity->GetAbsOrigin();//entity->GetNetworkOrigin();
	top = down + Vector(0, 0, 72) + offset + adjust;

	if (Menu::WorldToScreen(top, s[1]) && Menu::WorldToScreen(down, s[0]))
	{
		Vector delta = s[1] - s[0];

		height = fabsf(delta.y);
		width = height / 2.0f;

		x = s[1].x - (width / 2);
		y = s[1].y;

		return true;
	}

	return false;
}


void D9Visuals::DrawHealth(CBaseEntity *entity, IDirect3DDevice9* pDevice)
{

	bool enemy = entity->GetTeam() != G::LocalPlayer->GetTeam() || Vars.Visuals.Visualsxd.Visuals_EspTeam;

	if (!enemy && !Vars.Visuals.Visualsxd.Visuals_EspTeam)
		return;

	float height, width, x, y;

	if (GetPlayerBox(entity, x, y, width, height))
	{
		//int da = GetDormantAlpha(entity) + 55;
		float boxWidth = 5;
		float padd = 1;
		float _x = x;
		float _y = y;



		DWORD outlineColor = D3D_COLOR_BLACK(PlayerReadyAlpha(entity) / 2);
		DWORD textColor = D3D_COLOR_WHITE(PlayerReadyAlpha(entity));

		static int OldHealth[65];
		static bool Animate[65];
		static float Curtime[65];
		int ID = entity->GetIndex();
		_x -= padd;

		float healthBarHeight = (entity->GetHealth() * height * PlayerBoxAlpha[entity->GetIndex()] / 100.0f);
		float healthBarHeight2 = (OldHealth[entity->GetIndex()] * height * PlayerBoxAlpha[entity->GetIndex()] / 100.0f);

		if (OldHealth[entity->GetIndex()] > 100)
		{
			healthBarHeight2 = (OldHealth[entity->GetIndex()] * height * PlayerBoxAlpha[entity->GetIndex()] / OldHealth[entity->GetIndex()]);
		}
		DWORD lineColor = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), 153, min(255, OldHealth[entity->GetIndex()] * 225 / 100), 0);


		Menu::DrawFilledRectangle(_x - boxWidth, _y, height * PlayerBoxAlpha[entity->GetIndex()], boxWidth, outlineColor, pDevice);
		//	render->DrawFilledRectangle(_x - boxWidth + 1, _y + (height - healthBarHeight) + 1, healthBarHeight - 2, boxWidth - 2, lineColor);
		Menu::DrawFilledRectangle(_x - boxWidth + 1, _y + (height * PlayerBoxAlpha[entity->GetIndex()] - healthBarHeight2) + 1, healthBarHeight2 - 2, boxWidth - 2, lineColor, pDevice);

		if (Vars.Visuals.Visualsxd.Visuals_HealthBarType == 1)
		{
			for (int i = 1; i < 4; i++)
				Menu::DrawLineFast(_x - 1, _y + i * (height * PlayerBoxAlpha[entity->GetIndex()] / 4.0f), _x - boxWidth + 1, _y + i * (height * PlayerBoxAlpha[entity->GetIndex()] / 4.0f), outlineColor, pDevice);
		}

		if (entity->GetHealth() < 100)
		{
			char health[6];
			sprintf_s(health, 6, "%d", OldHealth[entity->GetIndex()]);

			_x -= Menu::GetTextWitdh(health, Menu::fntVerdana9) - 4;
			_y = y + (height * PlayerBoxAlpha[entity->GetIndex()] - healthBarHeight2) + 1;

			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", health);
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColor, "%s", health);
		}


		if (OldHealth[ID] <= entity->GetHealth())
		{
			OldHealth[ID] = entity->GetHealth();
			Animate[ID] = false;
		}


		if (OldHealth[ID] > entity->GetHealth())
		{
			if (!Animate[ID])
			{
				Curtime[ID] = I::Globals->curtime;
				Animate[ID] = true;
			}
			do
			{
				OldHealth[ID] -= 0.07;

			} while (Curtime[ID] - I::Globals->curtime > 0.44f && Animate[ID]);
		}
	}
}






void D9Visuals::DrawBox(CBaseEntity *entity, int cType, IDirect3DDevice9* pDevice)
{
	if (entity == G::LocalPlayer)
		return;



	float height, width, x, y;


	if (GetPlayerBox(entity, x, y, width, height))
	{
		x += 1;
		y += 1;
		width -= 2;
		height -= 2;


		DWORD boxColor = D3D_COLOR_WHITE(PlayerReadyAlpha(entity));
		DWORD outlineColor = D3D_COLOR_BLACK(PlayerReadyAlpha(entity));


		bool IsVisible = entity->IsVisible(6);

		if (IsVisible)
		{
			if (entity->GetTeam() == 3)
			{
				boxColor = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.BoxColorPickCTVIS[0] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickCTVIS[1] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickCTVIS[2] * 255));
			}
			else
			{
				boxColor = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.BoxColorPickTVIS[0] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickTVIS[1] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickTVIS[2] * 255));
			}
		}
		else
		{
			if (entity->GetTeam() == 3)
			{
				boxColor = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.BoxColorPickCTINVIS[0] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickCTINVIS[1] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickCTINVIS[2] * 255));
			}
			else
			{
				boxColor = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.BoxColorPickTINVIS[0] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickTINVIS[1] * 255), int(Vars.Visuals.Visualsxd.BoxColorPickTINVIS[2] * 255));
			}
		}







		if (Vars.Visuals.Visualsxd.Visuals_BoxEnabled)
		{

			int i = entity->GetIndex();
			Menu::DrawCornierBoxFastAlpha(x - 1, y - 1, height + 2, width + 2, outlineColor, PlayerBoxAlpha[i], pDevice);/*DrawBoxFastAlpha*/
			Menu::DrawCornierBoxFastAlpha(x, y, height, width, boxColor, PlayerBoxAlpha[i], pDevice);/*DrawBoxFastAlpha*/
			Menu::DrawCornierBoxFastAlpha(x + 1, y + 1, height - 2, width - 2, outlineColor, PlayerBoxAlpha[i], pDevice);/*DrawBoxFastAlpha*/
		}
	}
}

void D9Visuals::DrawBone(CBaseEntity *entity, matrix3x4_t *pBoneToWorldOut, DWORD color, IDirect3DDevice9* pDevice)
{
	studiohdr_t* pStudioModel = I::ModelInfo->GetStudioModel((model_t*)entity->GetModel());

	if (pStudioModel)
	{
		int num = 0;

		for (int i = 0; i < pStudioModel->numbones; i++)
		{
			mstudiobone_t* pBone = pStudioModel->pBone(i);

			if (!pBone)
				continue;

			if (!(pBone->flags & 256) || pBone->parent == -1)
				continue;

			Vector vBonePos1;

			if (!Menu::WorldToScreen(Vector(pBoneToWorldOut[i][0][3], pBoneToWorldOut[i][1][3], pBoneToWorldOut[i][2][3]), vBonePos1))
				continue;

			Vector vBonePos2;
			if (!Menu::WorldToScreen(Vector(pBoneToWorldOut[pBone->parent][0][3], pBoneToWorldOut[pBone->parent][1][3], pBoneToWorldOut[pBone->parent][2][3]), vBonePos2))
				continue;


			Menu::DrawLineFast(vBonePos1.x, vBonePos1.y, vBonePos2.x, vBonePos2.y, color, pDevice);
		}
	}
}



void D9Visuals::DrawBoneESP(CBaseEntity *entity, int cType, IDirect3DDevice9* pDevice)
{
	int id = entity->GetIndex();

	matrix3x4_t pBoneToWorldOut[128];

	if (!entity->SetupBones(pBoneToWorldOut, 128, 0x100, I::Engine->GetLastTimeStamp()))
		return;


	if (entity == G::LocalPlayer)
		return;



	DWORD color;

	switch (cType)
	{
	case 0:color = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.SkeletonCTVIS[0] * 255), int(Vars.Visuals.Visualsxd.SkeletonCTVIS[1] * 255), int(Vars.Visuals.Visualsxd.SkeletonCTVIS[2] * 255)); break;
	case 1:color = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.SkeletonCTINVIS[0] * 255), int(Vars.Visuals.Visualsxd.SkeletonCTINVIS[1] * 255), int(Vars.Visuals.Visualsxd.SkeletonCTINVIS[2] * 255)); break;
	case 2:color = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.SkeletonTVIS[0] * 255), int(Vars.Visuals.Visualsxd.SkeletonTVIS[1] * 255), int(Vars.Visuals.Visualsxd.SkeletonTVIS[2] * 255)); break;
	case 3:color = D3DCOLOR_ARGB(PlayerReadyAlpha(entity), int(Vars.Visuals.Visualsxd.SkeletonTINVIS[0] * 255), int(Vars.Visuals.Visualsxd.SkeletonTINVIS[1] * 255), int(Vars.Visuals.Visualsxd.SkeletonTINVIS[2] * 255)); break;
	default: color = D3D_COLOR_RED((int)(PlayerReadyAlpha(entity))); break;

	}




	DrawBone(entity, pBoneToWorldOut, color, pDevice);


}
wchar_t GetWeaponIcon(CBaseCombatWeapon *weapon)
{
	int code = 0xE000 + max(0, min(500, weapon->GetItemDefinitionIndex()));

	return (wchar_t)(code);
}
void DrawSnapLine(Vector to, D3DCOLOR clr, int width, int height, IDirect3DDevice9* pDevice)
{
	Vector From((width / 2), height - 1, 0);
	Menu::DrawLineFast(From.x, From.y, to.x, to.y, clr, pDevice);
}
CBaseCombatWeapon* GetActiveBaseCombatWeaponxdxd(CBaseEntity *entity)
{
	//CANCRUSH
	HANDLE pWeepEhandle = *reinterpret_cast<HANDLE*>(uintptr_t(entity) + 0x2EE8);
	return (CBaseCombatWeapon*)(I::ClientEntList->GetClientEntityFromHandle(pWeepEhandle));
}




void D9Visuals::DrawWeapon(CBaseEntity *entity, IDirect3DDevice9* pDevice)
{
	bool enemy = entity->GetTeam() != G::LocalPlayer->GetTeam() || Vars.Visuals.Visualsxd.Visuals_EspTeam;

	if (!enemy && !Vars.Visuals.Visualsxd.Visuals_EspTeam)
		return;


	CBaseCombatWeapon *w = GetActiveBaseCombatWeaponxdxd(entity);

	if (!w)
		return;



	float height, width, x, y;

	if (GetPlayerBox(entity, x, y, width, height))
	{
		//	int da = GetDormantAlpha(entity) + 55;
		float boxHeight = 5;
		float padd = 1;
		float _x = x;
		float _y = y;

		DWORD outlineColor = D3D_COLOR_BLACK(PlayerReadyAlpha(entity));
		DWORD textColor = D3D_COLOR_WHITE(PlayerReadyAlpha(entity));
		DWORD textColorScoped = D3D_COLOR_ORANGE(PlayerReadyAlpha(entity));
		DWORD textColorFaked = D3D_COLOR_GREEN(PlayerReadyAlpha(entity));
		DWORD textColorPENT = D3D_COLOR_RED(PlayerReadyAlpha(entity));
		DWORD textColorEmpty = D3D_COLOR_YELLOW(PlayerReadyAlpha(entity));
		DWORD textColorDefuser = D3D_COLOR_BLUE(PlayerReadyAlpha(entity));


		DWORD lineColor = D3D_COLOR_WHITE(PlayerReadyAlpha(entity));








		char ammo[20];
		sprintf_s(ammo, 20, "%d/%d", w->ammo(), w->ammo2());



		_x = x + width + padd;
		_y = y;
		if (Vars.Visuals.Visualsxd.Visuals_AimLines)
		{
			DrawSnapLine(Vector(x + (width / 2), y + height, 0), D3D_COLOR_RED(PlayerReadyAlpha(entity)), Menu::viewPort.Width, Menu::viewPort.Height, pDevice);
		}

		if (Vars.Visuals.Visualsxd.Visuals_Weapons && Vars.Visuals.Visualsxd.Visuals_WeaponsType == 0)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", XorStr((char*)w->GetWeaponName().c_str()));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorEmpty, "%s", XorStr((char*)w->GetWeaponName().c_str()));
			_y += 7.f;
		}

		if (w->ammo() >= 1 && !w->IsReloading() && Vars.Visuals.Visualsxd.Visuals_AmmoESP && Vars.Visuals.Visualsxd.Visuals_AmmoESPType == 0)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ammo);
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColor, "%s", ammo);
			_y += 7.f;
		}
		else if (Vars.Visuals.Visualsxd.Visuals_AmmoESP && !w->IsReloading() && Vars.Visuals.Visualsxd.Visuals_AmmoESPType == 0)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("EMPTY"));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorEmpty, "%s", ("EMPTY"));
			_y += 7.f;
		}
		else if (Vars.Visuals.Visualsxd.Visuals_AmmoESP && w->IsReloading())
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("RELOADING"));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorScoped, "%s", ("RELOADING"));
			_y += 7.f;
		}

		if (entity->IsScoped() && Vars.Visuals.Visualsxd.Visuals_Scoped)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("SCOPE"));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorScoped, "%s", ("SCOPE"));
			_y += 7.f;
		}
		if (entity->IsFlashed() && Vars.Visuals.Visualsxd.Visuals_Flashed)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("FLASHED"));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorScoped, "%s", ("FLASHED"));
			_y += 7.f;
		}
		if (entity->IsDefusing() && Vars.Visuals.Visualsxd.Visuals_Flashed)
		{
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("DEFUSING"));
			Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorDefuser, "%s", ("DEFUSING"));
			_y += 7.f;
		}


		if (Vars.Visuals.Visualsxd.Visuals_ArmorBar)
		{
			if (entity->GetArmor() > 0)
			{
				if (entity->HasHelmet())
				{
					Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("2 ARMOR"));
					Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorFaked, "%s", ("2 ARMOR"));
				}
				else
				{
					Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("1 ARMOR"));
					Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorFaked, "%s", ("1 ARMOR"));
				}
			}
			else
			{
				Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y + 1, outlineColor, "%s", ("NO ARMOR"));
				Menu::DrawStringWithFont(Menu::fntVerdana9, _x, _y, textColorFaked, "%s", ("NO ARMOR"));
			}
			_y += 7.f;
		}
	
		int NewX = x;
		int NewY = y + height;

		if (Vars.Visuals.Visualsxd.Visuals_AmmoESP && Vars.Visuals.Visualsxd.Visuals_AmmoESPType == 1)
		{


			Menu::DrawFilledRectangle(NewX, NewY, 6, (width) * (PlayerReadyAlpha(entity) / 255), D3DCOLOR_ARGB(PlayerReadyAlpha(entity), 5, 5, 5), pDevice);
			if (w->ammo() >= 1 && !w->IsReloading())
			{
				Menu::DrawFilledRectangle(NewX + 1, NewY + 1, 4, ((width - 2.f) * w->ammo() / w->BulletSize()) * (PlayerReadyAlpha(entity) / 255), D3DCOLOR_ARGB(PlayerReadyAlpha(entity), 83, 140, 232), pDevice);
			}
			else
			{
				Menu::DrawFilledRectangle(NewX + 1, NewY + 1, 4, (width - 2.f) * (PlayerReadyAlpha(entity) / 255), D3DCOLOR_ARGB(PlayerReadyAlpha(entity), 255, 165, 0), pDevice);
			}


			NewY += 7;
		}

		if (Vars.Visuals.Visualsxd.Visuals_Weapons && Vars.Visuals.Visualsxd.Visuals_WeaponsType == 1)
		{
			wchar_t weapIcon[2] = { GetWeaponIcon(w), '\0' };

			_x = x + (width - Menu::GetTextWitdhW(weapIcon, Menu::fntWeaponIcon)) / 2;
			_y = y + height + 7;

			DrawStringWithFontW(Menu::fntWeaponIcon, _x, NewY + 1, outlineColor, L"%s", weapIcon);
			DrawStringWithFontW(Menu::fntWeaponIcon, _x, NewY, textColor, L"%s", weapIcon);
		}
	}
}


void D9Visuals::Render(IDirect3DDevice9* pDevice)
{
	if (!I::Engine->IsInGame() || !I::Engine->IsConnected() || !G::LocalPlayer)
		return;

	



	
	DamageESP::Draw();




	


	for (int i = 1; i < I::Engine->GetMaxClients(); i++)
	{
		auto entity = I::ClientEntList->GetClientEntity(i);

		bool Visable;
		if (!Filter(entity, Visable))
		{
			PlayerAlpha[i] = 255;
			PlayerBoxAlpha[i] = 1.0f;
			PlayerNickVal[i] = 100;
			/*
			if (entity->GetDormant())
			{
				if (PlayerAlpha[i] != 0)
					PlayerAlpha[i] -= 1.5;

				if (PlayerBoxAlpha[i] != 0.f)
					PlayerBoxAlpha[i] -= 0.01f;

				if (PlayerNickVal[i] != 0)
					PlayerNickVal[i] -= 2;

			}
			else
			{
				if (PlayerAlpha[i] != 255)
					PlayerAlpha[i] += 5;

				if (PlayerBoxAlpha[i] != 1.f)
					PlayerBoxAlpha[i] += 0.05f;

				if (PlayerNickVal[i] != 100)
					PlayerNickVal[i] += 2;

			}
			if (PlayerBoxAlpha[i] < 0.f)
				PlayerBoxAlpha[i] = 0.f;
			if (PlayerBoxAlpha[i] > 1.f)
				PlayerBoxAlpha[i] = 1.f;
			if (PlayerAlpha[i] < 0)
				PlayerAlpha[i] = 0;
			if (PlayerAlpha[i] > 255)
				PlayerAlpha[i] = 255;
			if (PlayerNickVal[i] < 0)
				PlayerNickVal[i] = 0;
			if (PlayerNickVal[i] > 100)
				PlayerNickVal[i] = 100;

				*/


			int typecolor = entity->GetTeam() == 3 ? Visable ? 0 : 1 : Visable ? 2 : 3;


			if (Vars.Visuals.Visualsxd.Visuals_Name) DrawName(entity);

			if (Vars.Visuals.Visualsxd.Visuals_BoxEnabled) DrawBox(entity, typecolor, pDevice);
			if (Vars.Visuals.Visualsxd.Visuals_HealthBar) DrawHealth(entity, pDevice);
			if (Vars.Visuals.Visualsxd.Visuals_Skeltal) DrawBoneESP(entity, typecolor, pDevice);

			DrawWeapon(entity, pDevice);


		}
	}

	for (int i = 65; i < I::ClientEntList->GetHighestEntityIndex(); i++)
	{
		auto pEntity = I::ClientEntList->GetClientEntity(i);
		if (!pEntity)
			continue;
		if (!G::LocalPlayer)
			continue;
		if (pEntity == G::LocalPlayer)
			continue;
		
		/*
		if (Vars.Visuals.Visualsxd.Visuals_C4 && strstr(pEntity->GetClientClass()->m_pNetworkName, "CPlantedC4"))
		{
			if (!pEntity->BombDefused())
			{
				float flTime = pEntity->BombTimer() - INTERFACES::Globals->curtime;
				if (pEntity->BombTimer() - INTERFACES::Globals->curtime > 0.f)
				{
					Vector vPos;
					if (Menu::WorldToScreen(pEntity->GetAbsOrigin(), vPos))
					{
						bool bCanDefuse = (items::pLocal->HasKit() && flTime > 5.f) || flTime > 10.f;
						static char msg[32];
						sprintf_s(msg, 32, "C4 | %.2f", flTime);

						Menu::DrawStringWithFont(Menu::fntVerdana10, vPos.x, vPos.y, D3D_COLOR_BLACK(255), "%s", msg);
						Menu::DrawStringWithFont(Menu::fntVerdana10, vPos.x, vPos.y + 1, bCanDefuse ? D3D_COLOR_WHITE(255) : D3D_COLOR_ORANGE(255), "%s", msg);
					}
				}
			}
			else
			{
				Vector vPos;
				if (Menu::WorldToScreen(pEntity->GetAbsOrigin(), vPos))
				{
					static char msg[32];
					sprintf_s(msg, 32, "C4 | DEFUSED");
					Menu::DrawStringWithFont(Menu::fntVerdana10, vPos.x, vPos.y, D3D_COLOR_BLACK(255), "%s", msg);
					Menu::DrawStringWithFont(Menu::fntVerdana10, vPos.x, vPos.y + 1, D3D_COLOR_RED(255), "%s", msg);
				}
			}
		}

		*/

		/*
		if (Vars.Visuals.Visualsxd.Visuals_DroppedWeapons && pEntity->IsDefusing())
		{

			auto weapon = reinterpret_cast<Shonax_SDK::CBaseWeapon*>(pEntity);
			auto plr = INTERFACES::ClientEntityList->GetClientEntityFromHandle(weapon->GetOwnerHandle());
			Vector vOrig3D = pEntity->GetAbsOrigin(), vOrig;

			if (Menu::WorldToScreen(vOrig3D, vOrig))
			{
				Shonax_SDK::player_info_t info;
				if (plr == nullptr || !plr->IsAlive() || !(plr->GetHealth() > 0) || !(INTERFACES::Engine->GetPlayerInfo(plr->GetIndex(), &info)))
				{
					if (!(vOrig3D.y >= -5 && vOrig3D.y <= 5 && vOrig3D.x >= -5 && vOrig3D.x <= 5))
					{
						DWORD outlineColor = D3D_COLOR_BLACK(255);
						DWORD textColor = D3D_COLOR_WHITE(255);
						Menu::DrawStringWithFont(Menu::fntVerdana9, vOrig.x, vOrig.y + 1, outlineColor, "%s", (char*)weapon->GetWeaponName().c_str());
						Menu::DrawStringWithFont(Menu::fntVerdana9, vOrig.x, vOrig.y, textColor, "%s", (char*)weapon->GetWeaponName().c_str());
					}
				}
			}

		}


		*/


	}

}






#define RandomInt(min, max) (rand() % (max - min + 1) + min)
namespace DamageESP
{
	std::array<FloatingText, MAX_FLOATING_TEXTS> floatingTexts;
	int floatingTextsIdx = 0;

	void HandleGameEvent(IGameEvent* pEvent)
	{
		if (!Vars.Visuals.Visualsxd.Visuals_DamageESP || !(I::Engine->IsInGame() && I::Engine->IsConnected() && G::LocalPlayer))
			return;

		const char *name = pEvent->GetName();

		static Vector lastImpactPos = Vector(0, 0, 0);

		if (!strcmp(name, ("player_hurt")))
		{
			float curTime = I::Globals->curtime;

			int userid = pEvent->GetInt(("userid"));
			int attackerid = pEvent->GetInt(("attacker"));
			int dmg_health = pEvent->GetInt(("dmg_health"));
			int hitgroup = pEvent->GetInt(("hitgroup"));

			CBaseEntity *entity = I::ClientEntList->GetClientEntity(I::Engine->GetPlayerForUserID(userid));
			CBaseEntity *attacker = I::ClientEntList->GetClientEntity(I::Engine->GetPlayerForUserID(attackerid));

			if (!entity || attacker != G::LocalPlayer)
				return;

			FloatingText txt;
			txt.startTime = curTime;
			txt.hitgroup = hitgroup;
			txt.hitPosition = lastImpactPos;
			txt.damage = dmg_health;
			txt.randomIdx = rand() % 5;
			txt.valid = true;

			floatingTexts[floatingTextsIdx++ % MAX_FLOATING_TEXTS] = txt;
		}
		else if (!strcmp(name, ("bullet_impact")))
		{
			int userid = pEvent->GetInt(("userid"));
			float x = pEvent->GetFloat(("x"));
			float y = pEvent->GetFloat(("y"));
			float z = pEvent->GetFloat(("z"));

			CBaseEntity *entity = I::ClientEntList->GetClientEntity(I::Engine->GetPlayerForUserID(userid));

			if (!entity || entity != G::LocalPlayer)
				return;

			lastImpactPos = Vector(x, y, z);
		}
	}

	void Draw()
	{
		if (!Vars.Visuals.Visualsxd.Visuals_DamageESP)
			return;


		for (int i = 0; i < MAX_FLOATING_TEXTS; i++)
		{
			FloatingText *txt = &floatingTexts[i % MAX_FLOATING_TEXTS];

			if (!txt->valid)
				continue;

			float endTime = txt->startTime + 1.1f;

			if (endTime < I::Globals->curtime)
			{
				txt->valid = false;
				continue;
			}

			Vector screen;

			if (Menu::WorldToScreen(txt->hitPosition, screen))
			{
				float t = 1.0f - (endTime - I::Globals->curtime) / (endTime - txt->startTime);

				screen.y -= t * (35.0f);
				screen.x -= (float)txt->randomIdx * t * 3.0f;

				char msg[12];
				sprintf_s(msg, 12, "-%dHP", txt->damage);

				int width = Menu::GetTextWitdh(msg, Menu::fntVerdana10);

				Menu::DrawStringWithFont(Menu::fntVerdana10, screen.x - width / 2, screen.y - 11 + 1, D3D_COLOR_BLACK((int)((1.0f - t) * (float)255)), msg);

				Menu::DrawStringWithFont(Menu::fntVerdana10, screen.x - width / 2, screen.y - 11, D3DCOLOR_ARGB(int(Vars.Visuals.Visualsxd.DamageESPColor[3] * 255), int(Vars.Visuals.Visualsxd.DamageESPColor[0] * 255), int(Vars.Visuals.Visualsxd.DamageESPColor[1] * 255), int(Vars.Visuals.Visualsxd.DamageESPColor[2] * 255)), msg);
			}
		}
	}
}

