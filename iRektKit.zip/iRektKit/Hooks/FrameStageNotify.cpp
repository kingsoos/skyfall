#include "../Cheat.h"
#include "../SkinChanger.h"
#include "../thirdperson.h"
#include "../asus.h"
#include "../SDK/Beams.h"



void DrawBeam(Vector src, Vector end, Color color)
{
	BeamInfo_t beamInfo;
	beamInfo.m_nType = TE_BEAMTESLA;
	beamInfo.m_pszModelName = "sprites/purplelaser1.vmt";
	beamInfo.m_nModelIndex = -1;
	beamInfo.m_flHaloScale = 0.0f;
	beamInfo.m_flLife = 3.0f;
	beamInfo.m_flWidth = 2.0f;
	beamInfo.m_flEndWidth = 2.0f;
	beamInfo.m_flFadeLength = 0.0f;
	beamInfo.m_flAmplitude = 2.0f;
	beamInfo.m_flBrightness = 255.f;
	beamInfo.m_flSpeed = 0.2f;
	beamInfo.m_nStartFrame = 0;
	beamInfo.m_flFrameRate = 0.f;
	beamInfo.m_flRed = color.r();
	beamInfo.m_flGreen = color.g();
	beamInfo.m_flBlue = color.b();
	beamInfo.m_nSegments = 2;
	beamInfo.m_bRenderable = true;
	beamInfo.m_vecStart = src;
	beamInfo.m_vecEnd = end;
	Beam_t* myBeam = I::g_pViewRenderBeams->CreateBeamPoints(beamInfo);
	if (myBeam)
		I::g_pViewRenderBeams->DrawBeam(myBeam);
}


struct PlayerAA
{
	CBaseEntity* player;
	QAngle angle;

	PlayerAA(CBaseEntity* player, QAngle angle)
	{
		this->player = player;
		this->angle = angle;
	}
};

std::vector<int>      CPlayerList::Players = {};
std::vector<PlayerAA> player_data;
std::vector<CPlayer>  Players;

float DoYawAAA(CBaseEntity* pEnt) {
	float yaw = pEnt->GetHeadRotation()->y;

	yaw -= 180.f;

	return yaw;
}

FrameStageNotifyFn oFrameStageNotify;
void __stdcall Hooks::FrameStageNotify(ClientFrameStage_t stage)
{
	if (!G::LocalPlayer || G::LocalPlayer->GetHealth() <= 0)
		return oFrameStageNotify(stage);

	G::FSNLBY = *G::LocalPlayer->GetLowerBodyYawTarget();
	// Resolver
	if (Vars.Ragebot.Antiaim.Resolver == 1 && I::Engine->IsInGame() && stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{
		if (G::LocalPlayer && G::LocalPlayer->GetAlive())
		{
			for (int i = 0; i <= I::Globals->maxClients; i++)
			{
				CBaseEntity* Entity = I::ClientEntList->GetClientEntity(i);

				if (!Entity
					|| Entity == G::LocalPlayer
					|| Entity->GetTeam() == G::LocalPlayer->GetTeam()
					|| Entity->GetHealth() <= 0
					
					|| Entity->GetImmune())
					continue;

				player_data.push_back(PlayerAA(Entity, *Entity->GetHeadRotation()));

				Entity->GetHeadRotation()->y = *Entity->GetLowerBodyYawTarget();
			}
		}
	}
	else if (stage == FRAME_RENDER_END)
	{
		for (unsigned long i = 0; i < player_data.size(); i++)
		{
			PlayerAA player_aa_data = player_data[i];

			*player_aa_data.player->GetHeadRotation() = player_aa_data.angle;
		}

		player_data.clear();
	}
	//* Resolver *//

	QAngle aim_punch_old;
	QAngle view_punch_old;

	QAngle* aim_punch = nullptr;
	QAngle* view_punch = nullptr;

	if (stage == FRAME_RENDER_START)
	{
		if (*(bool*)((DWORD)I::Input + 0xA5)) {
			*(QAngle*)((DWORD)G::LocalPlayer + offsets.deadflag + 4) = G::VisualAngle;
		}

		if (Vars.Visuals.BulletTracers)
		{
			float Red, Green, Blue;
			Red = Vars.Visuals.Bulletracer[0] * 255;
			Green = Vars.Visuals.Bulletracer[1] * 255;
			Blue = Vars.Visuals.Bulletracer[2] * 255;
			for (unsigned int i = 0; i < trace_logs.size(); i++) {
				auto *shooter = I::ClientEntList->GetClientEntity(I::Engine->GetPlayerForUserID(trace_logs[i].userid));
				if (!shooter)
					return;
				DrawBeam(trace_logs[i].start, trace_logs[i].position, Color(Red, Green, Blue, Vars.Visuals.Bulletracer[3] * 255));
				trace_logs.erase(trace_logs.begin() + i);
			}
		}
	}

	if (I::Engine->IsInGame() && stage == FRAME_RENDER_START && Vars.Visuals.RemovalsVisualRecoil)
	{
		if (G::LocalPlayer && G::LocalPlayer->GetAlive())
		{
			aim_punch = (QAngle*)((DWORD)G::LocalPlayer + offsets.m_aimPunchAngle);
			view_punch = (QAngle*)((DWORD)G::LocalPlayer + offsets.m_viewPunchAngle);

			aim_punch_old = *aim_punch;
			view_punch_old = *view_punch;

			*aim_punch = QAngle(0, 0, 0);
			*view_punch = QAngle(0, 0, 0);
		}
	}

	//SkinChanger::FrameStageNotify(stage);

	//ThirdPerson::FrameStageNotify(stage);
	SkinChanger::FrameStageNotify(stage);
	oFrameStageNotify(stage);


	if (aim_punch && view_punch && Vars.Visuals.RemovalsVisualRecoil)
	{
		*aim_punch = aim_punch_old;
		*view_punch = view_punch_old;
	}
	//return oFrameStageNotify(stage);
}