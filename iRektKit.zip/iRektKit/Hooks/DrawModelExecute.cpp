#include "../Cheat.h"
#include "../xor.h"
#include "../asus.h"
DrawModelExecuteFn oDrawModelExecute;

void ForceMaterial( IMaterial* material, Color color )
{
	if( material != NULL )
	{
		I::RenderView->SetColorModulation( color.Base() );
		I::ModelRender->ForcedMaterialOverride( material );
	}
}

void __stdcall Hooks::DrawModelExecute(void* context, void* state, const ModelRenderInfo_t& info, matrix3x4_t* pCustomBoneToWorld)
{

	if (I::Engine->IsInGame() && G::LocalPlayer && I::Engine->IsConnected())
	{
		if (info.pModel && Vars.Visuals.Chams.Enabled)
		{
			
				std::string modelName = I::ModelInfo->GetModelName(info.pModel);
				const char* ModelName = I::ModelInfo->GetModelName((model_t*)info.pModel);

				if (modelName.find(strenc("models/player")) != std::string::npos && Vars.Visuals.Chams.Enabled)
				{
					//dev/glow_rim3d
					player_info_t pInfo; player_info_t localinfo;
					I::Engine->GetPlayerInfo(info.entity_index, &pInfo); I::Engine->GetPlayerInfo(I::Engine->GetLocalPlayer(), &localinfo);

					CBaseEntity* pModelEntity = (CBaseEntity*)I::ClientEntList->GetClientEntity(info.entity_index);
					if (pModelEntity && pModelEntity->GetAlive())
					{
						//IMaterial* MODEL = I::MaterialSystem->FindMaterial("dev/glow_rim3d", charenc(TEXTURE_GROUP_OTHER));

						if ((Vars.Visuals.Filter.Friendlies && !pModelEntity->IsEnemy()) || pModelEntity == G::LocalPlayer || (Vars.Visuals.Filter.Enemies && pModelEntity->IsEnemy()))
						{
							//auto ChamsCTV = Vars.g_iChamsCTV; auto ChamsTV = Vars.g_iChamsTV;
							//auto ChamsCTH = Vars.g_iChamsCTH; auto ChamsTH = Vars.g_iChamsTH;

							Color render_color_hidden = pModelEntity->GetTeam() == 2 ? Color(int(Vars.g_iChamsTH[0] * 255.0f), int(Vars.g_iChamsTH[1] * 255.0f), int(Vars.g_iChamsTH[2] * 255.0f)) : Color(int(Vars.g_iChamsCTH[0] * 255.0f), int(Vars.g_iChamsCTH[1] * 255.0f), int(Vars.g_iChamsCTH[2] * 255.0f));
							Color render_color_visible = pModelEntity->GetTeam() == 2 ? Color(int(Vars.g_iChamsTV[0] * 255.0f), int(Vars.g_iChamsTV[1] * 255.0f), int(Vars.g_iChamsTV[2] * 255.0f)) : Color(int(Vars.g_iChamsCTV[0] * 255.0f), int(Vars.g_iChamsCTV[1] * 255.0f), int(Vars.g_iChamsCTV[2] * 255.0f));

							if (Vars.Visuals.Chams.XQZ)
							{
							//	ForceMaterial(Vars.Visuals.Chams.Mode == 0 ? hidden_flat : hidden_tex, render_color_hidden);
								if (Vars.Visuals.Chams.Mode == 0)
									ForceMaterial(hidden_flat, render_color_hidden);
								else if(Vars.Visuals.Chams.Mode == 1)
									ForceMaterial(hidden_tex, render_color_hidden);
								else if(Vars.Visuals.Chams.Mode == 2)
									ForceMaterial(GlassChams, render_color_hidden);


								I::ModelRender->DrawModelExecute(context, state, info, pCustomBoneToWorld);

								if (Vars.Visuals.Chams.Mode == 0)
									hidden_flat->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ , true);
								else if(Vars.Visuals.Chams.Mode == 1)
									hidden_tex->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, true);
								else if(Vars.Visuals.Chams.Mode == 2)
									GlassChams->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, true);
							}

							if (Vars.Visuals.Chams.Mode == 0)
								hidden_flat->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, false);
							else if (Vars.Visuals.Chams.Mode == 1)
								hidden_tex->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, false);
							else if (Vars.Visuals.Chams.Mode == 2)
								GlassChams->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, false);

						//	ForceMaterial(Vars.Visuals.Chams.Mode == 0 ? visible_flat : /*visible_tex*/GlassChams, render_color_visible);
							if (Vars.Visuals.Chams.Mode == 0)
								ForceMaterial(visible_flat, render_color_visible);
							else if (Vars.Visuals.Chams.Mode == 1)
								ForceMaterial(visible_tex, render_color_visible);
							else if (Vars.Visuals.Chams.Mode == 2)
								ForceMaterial(GlassChams, render_color_visible);

							I::ModelRender->DrawModelExecute(context, state, info, pCustomBoneToWorld);
						}
						//I::ModelRender->ForcedMaterialOverride(MODEL);
					}
				}
				

				if (modelName.find(strenc("flash")) != std::string::npos && Vars.Visuals.RemovalsFlash)
				{
					IMaterial* flash = I::MaterialSystem->FindMaterial(charenc("effects\\flashbang"), charenc(TEXTURE_GROUP_CLIENT_EFFECTS));
					IMaterial* flashWhite = I::MaterialSystem->FindMaterial(charenc("effects\\flashbang_white"), charenc(TEXTURE_GROUP_CLIENT_EFFECTS));
					flash->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, true);
					flashWhite->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, true);
					I::ModelRender->ForcedMaterialOverride(flash);
					I::ModelRender->ForcedMaterialOverride(flashWhite);
				}
		
		}
	}
	I::ModelRender->DrawModelExecute(context, state, info, pCustomBoneToWorld);
	I::ModelRender->ForcedMaterialOverride(NULL);
}
