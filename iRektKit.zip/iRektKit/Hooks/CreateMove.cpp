﻿#include "../Cheat.h"
//#define WEAPON_DATA_SIZE ( sizeof( pWeaponData ) / sizeof( *pWeaponData ) )
#include "../Settings/Vars.h"

CreateMoveFn oCreateMove;

void StandAloneRCS(float vNP_first, float vNP_second, CBaseEntity* pLocal, CUserCmd* pCmd)
{
	static QAngle vOldPunch = { 0.0f, 0.0f, 0.0f };
	QAngle vNewPunch = pLocal->GetPunch();

	vNewPunch *= vNP_first;

	vNewPunch -= vOldPunch;
	vNewPunch *= vNP_second;
	vNewPunch += vOldPunch;

	QAngle vFinal = pCmd->viewangles - (vNewPunch - vOldPunch);

	vFinal.Normalize();
	vFinal.Clamp();

	I::Engine->SetViewAngles(vFinal);

	vOldPunch = vNewPunch;
}


bool __stdcall Hooks::CreateMove( float flInputSampleTime, CUserCmd* cmd )
{

	bool oReturn = oCreateMove(flInputSampleTime, cmd);
	G::LocalPlayer = U::GetLocalPlayer();
	G::UserCmd = cmd;

	if (Vars.Ragebot.Enabled) Vars.Legitbot.Aimbot.Enabled = false;
	else if (Vars.Legitbot.Aimbot.Enabled) Vars.Ragebot.Enabled = false;


	PVOID pebp;
	__asm mov pebp, ebp;
	bool* pbSendPacket = (bool*)(*(DWORD*)pebp - 0x1C);
	bool& bSendPacket = *pbSendPacket;

	if (!pbSendPacket)
		return false;

	G::SendPacket = *pbSendPacket;


	if (cmd->command_number == 0 || !I::Engine->IsInGame())
		return false;

	if (!G::LocalPlayer || !G::LocalPlayer->GetAlive())
		return G::Return;


	if (Vars.Misc.Bhop)
		E::Misc->Bunnyhop();

	if (Vars.Misc.AutoStrafe > 0)
		E::Misc->AutoStrafe();

	if (Vars.Misc.ChatSpam) E::Misc->ChatSpam(Vars.Misc.SpamText);

	//E::Misc->CircleStrafer();

	Vars.wpn = G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex();

	PredictionSystem->StartPrediction();

	E::LegitBot->Run();
	

	if (Vars.Misc.rcs_standalone)
		StandAloneRCS(Vars.Misc.first_rcs_stand, Vars.Misc.second_rcs_stand, G::LocalPlayer, cmd);

	if (Vars.Ragebot.Enabled)
		E::RageBot->Run();

	if (Vars.Ragebot.Antiaim.Enabled)
		AntiAim->Run();


	if( Vars.Misc.AirStuck )
		E::Misc->AirStuck();

	if (Vars.Ragebot.UntrustedCheck)
		cmd->viewangles.Clamp();

	E::FakeLag->Run();
	/*
	if (G::LocalPlayer->GetWeapon()->IsRevolver())
	{
		float flPostponeFireReady = G::LocalPlayer->GetWeapon()->GetflPostponeFireReadyTime();
		if (flPostponeFireReady > 0 && flPostponeFireReady - 1.f < I::Globals->curtime)
		{
			cmd->buttons &= ~IN_ATTACK;
		}
	}
	*/
	PredictionSystem->EndPrediction();

	if ((G::UserCmd->buttons & IN_ATTACK) && G::LocalPlayer->GetWeapon()->IsGun() && Vars.Ragebot.Enabled)
		Vars.m_iBulletsFire += 1;

	if (Vars.Ragebot.UntrustedCheck)
		cmd->viewangles.Clamp();

	if (Vars.Ragebot.AutoPistol || Vars.Legitbot.Aimbot.AutoPistol)
	{
		int iWeaponID = G::LocalPlayer->GetWeapon()->GetWeaponID();

		if (iWeaponID == WEAPON_FIVESEVEN || iWeaponID == WEAPON_DEAGLE || iWeaponID == WEAPON_ELITE || iWeaponID == WEAPON_P250 || iWeaponID == WEAPON_GLOCK || iWeaponID == WEAPON_USP_SILENCER || iWeaponID == WEAPON_TEC9 || iWeaponID == WEAPON_HKP2000)
		{
			if (G::UserCmd->buttons & IN_ATTACK)
			{
				float flCurTime = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
				float flNextAttack = G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack();

				if (flNextAttack > flCurTime)
				{
					cmd->buttons &= ~IN_ATTACK;
					cmd->buttons |= IN_ATTACK;
					cmd->buttons &= ~IN_ATTACK;
				}
			}
		}
	}

	G::VisualAngle = *G::LocalPlayer->GetHeadRotation();


	*pbSendPacket = G::SendPacket;

	return false;
}