#include "Cheat.h"

RenderViewFn oRenderViewHook;
void __fastcall Hooks::khRenderView(void* thisptr, void* edx, CViewSetup& setup, CViewSetup& hudViewSetup, unsigned int nClearFlags, int whatToDraw)
{
	if (I::Engine->IsConnected()) {
		setup.fovViewmodel = Vars.Misc.FakeLags;
		setup.fov = Vars.Misc.FakeLags;
	}
	return oRenderViewHook(thisptr, setup, hudViewSetup, nClearFlags, whatToDraw);
}

oGetViewModelFOV oGetViewModel;
float __stdcall Hooks::hkGetViewModelFOV() {
	// Change this return value to whatever fov you want.

	float fov = oGetViewModel();

	fov += Vars.Visuals.ViewmodelFov;

	return fov;
}

// Somewhere else...
//clientmode_hook->HookFunc((uintptr_t)hkGetViewModelFOV, 35);