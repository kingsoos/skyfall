#include "Cheat.h"
#include "SkinChanger.h"

IGameEvent* GameEventManager;
FireEventClientSideFn oFireEventClientSide;
std::vector<trace_info> trace_logs;
bool __fastcall Hooks::hkFireEventClientSide(IGameEventManager2* thisptr, void* edx, IGameEvent* pEvent)
{

	


	
	if (pEvent)
	{

		if (strcmp(pEvent->GetName(), "player_hurt") == 0)
			DamageESP::HandleGameEvent(pEvent);


		SkinChanger::KnifeEventFire(pEvent);

		if (Vars.Visuals.BulletTracers)
		{
			if (strcmp(pEvent->GetName(), "bullet_impact") == 0)
			{
				auto* index = I::ClientEntList->GetClientEntity(I::Engine->GetPlayerForUserID(pEvent->GetInt("userid")));
				if (G::LocalPlayer)
				{
					Vector position(pEvent->GetFloat("x"), pEvent->GetFloat("y"), pEvent->GetFloat("z"));
					if (index)
						trace_logs.push_back(trace_info(index->GetEyePosition(), position, I::Globals->curtime, pEvent->GetInt("userid")));
				}
			}
		}

		if (!strcmp(pEvent->GetName(), XorStr("bomb_pickup")))
			Vars.bomber = pEvent->GetInt(XorStr("userid"));
		if (!strcmp(pEvent->GetName(), XorStr("hostage_follows")))
			Vars.Hostage = pEvent->GetInt(XorStr("userid"));
		if (!strcmp(pEvent->GetName(), XorStr("bomb_begindefuse")))
			Vars.defuser = pEvent->GetInt(XorStr("userid"));
		if (!strcmp(pEvent->GetName(), XorStr("bomb_defused")))
			Vars.defuser = 0;
		if (!strcmp(pEvent->GetName(), XorStr("bomb_abortdefuse")))
			Vars.defuser = 0;
		if (!strcmp(pEvent->GetName(), XorStr("bomb_planted"))) {
			Vars.bomb = true;
			Vars.bomber = 0;
		}
		if (!strcmp(pEvent->GetName(), XorStr("bomb_dropped")))
			Vars.bomber = 0;

		if (!strcmp(pEvent->GetName(), XorStr("round_end")))
		{
			Vars.defuser = 0;
			Vars.Hostage = 0;
			Vars.bomb = false;
		}

		if (Vars.Misc.bombinfo)
		{
			if (!strcmp(pEvent->GetName(), XorStr("bomb_planted")))
			{
				//const char* bombsite = pEvent->GetString("site");
				auto userid = I::Engine->GetPlayerForUserID(pEvent->GetInt(XorStr("userid")));

				player_info_t info;
				char pszBuffer[128];
				if (I::Engine->GetPlayerInfo(userid, &info))
				{
					sprintf_s(pszBuffer, "say ~BOMB HAS BEEN PLANTED BY %s ~", /*bombsite, */ info.name);
				}
				I::Engine->ClientCmd(pszBuffer);
			}

			if (!strcmp(pEvent->GetName(), XorStr("bomb_defused")))
			{
				//const char* bombsite = pEvent->GetString("site");
				auto userid = I::Engine->GetPlayerForUserID(pEvent->GetInt(XorStr("userid")));

				player_info_t info;
				char pszBuffer[128];
				if (I::Engine->GetPlayerInfo(userid, &info))
				{
					sprintf_s(pszBuffer, "say ~BOMB HAS BEEN DEFUSED BY %s ~", /*bombsite, */ info.name);
				}
				I::Engine->ClientCmd(pszBuffer);
			}

			if (!strcmp(pEvent->GetName(), XorStr("bomb_beginplant")))
				I::Engine->ClientCmd_Unrestricted(XorStr("say ~BOMB ARE PLANTING~"));

			if (!strcmp(pEvent->GetName(), XorStr("bomb_begindefuse")))
			{
				auto defusekits = pEvent->GetBool(XorStr("haskit"));
				const char* kits;

				if (defusekits)
					kits = XorStr("with kits");
				else
					kits = XorStr("without kits");


				char pszBuffer[128];
				sprintf_s(pszBuffer, "say ~BOMB ARE DEFUSING (%s) ~", kits);
				I::Engine->ClientCmd_Unrestricted(pszBuffer);
			}

			if (!strcmp(pEvent->GetName(), XorStr("bomb_exploded")))
				I::Engine->ClientCmd_Unrestricted(XorStr("say ~BOMB HAS BEEN EXPLODED~"));
		}

		/*if (!strcmp(pEvent->GetName(), "player_footstep"))
		{
			auto userid = I::Engine->GetPlayerForUserID(pEvent->GetInt("userid"));
			auto iLocalPlayer = I::Engine->GetLocalPlayer();
			player_info_t info;
			if (I::Engine->GetPlayerInfo(userid, &info) && userid != iLocalPlayer)
			{
				char pszBuffer[128];
				sprintf_s(pszBuffer, "say %s step", info.name);
				I::Engine->ClientCmd(pszBuffer);
			}
		}*/

		if (!strcmp(pEvent->GetName(), XorStr("player_death")))
		{
			auto userid = I::Engine->GetPlayerForUserID(pEvent->GetInt(XorStr("userid")));
			auto attacker = I::Engine->GetPlayerForUserID(pEvent->GetInt(XorStr("attacker")));
			auto iLocalPlayer = I::Engine->GetLocalPlayer();

			if (attacker == iLocalPlayer && userid != iLocalPlayer)
			{
				if (Vars.Legitbot.Aimbot.KillStop)
					G::KillStop = true;

				bool IsHeadshot = pEvent->GetBool(XorStr("headshot"));
				if (IsHeadshot && Vars.Misc.TapSay)
					I::Engine->ClientCmd(XorStr("say ~Get headshot and buy new hax kid~"));

				else
				{
					if (Vars.Misc.SoundShit)
					{
						player_info_t info;
						if (I::Engine->GetPlayerInfo(userid, &info))
						{
							char pszBuffer[128];
							sprintf_s(pszBuffer, "say %s do you sell that hack?", info.name);
							I::Engine->ClientCmd(pszBuffer);
						}
					}
				}
			}
		}
	}
	/*---*/return oFireEventClientSide(thisptr, pEvent);/*---*/
}