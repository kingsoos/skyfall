#pragma once

void CheatThread();
