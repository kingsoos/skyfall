﻿#include "../Cheat.h"
#include <sstream>
#include <fstream>
#include "../xor.h"

typedef float(*RandomFloat_t)(float, float);
typedef void(*RandomSeed_t)(UINT);

void CMiscellaneous::Initialize()
{
	if ( m_bInitialized )
		return;
}

void CMiscellaneous::Run()
{
	Bunnyhop();
}

void CMiscellaneous::Think()
{

}

void CMiscellaneous::Bunnyhop()
{
	/*if ( G::UserCmd->buttons & IN_JUMP && !( G::LocalPlayer->GetFlags() & FL_ONGROUND ) )
	{
		G::UserCmd->buttons &= ~IN_JUMP;
	}*/

	//LEGIT

	static bool bLastJumped = false;
	static bool bShouldFake = false;

	if (!bLastJumped && bShouldFake)
	{
		bShouldFake = false;
		G::UserCmd->buttons |= IN_JUMP;
	}
	else if (G::UserCmd->buttons & IN_JUMP)
	{
		if (G::LocalPlayer->GetFlags() & FL_ONGROUND)
		{
			bLastJumped = true;
			bShouldFake = true;
		}
		else
		{
			G::UserCmd->buttons &= ~IN_JUMP;
			bLastJumped = false;
		}
	}
	else
	{
		bLastJumped = false;
		bShouldFake = false;
	}
}

float NormalizeFloat(float result)
{
	while (result > 180.0f)
		result -= 360.0f;

	while (result < -180.0f)
		result += 360.0f;

	return result;
}

void CMiscellaneous::AngleToVectors(QAngle &angles, Vector *forward, Vector *right, Vector *up)
{
	float angle;
	static float sr, sp, sy, cr, cp, cy, cpi = (M_PI * 2 / 360);

	angle = angles.y * cpi;
	sy = sin(angle);
	cy = cos(angle);
	angle = angles.x * cpi;
	sp = sin(angle);
	cp = cos(angle);
	angle = angles.z * cpi;
	sr = sin(angle);
	cr = cos(angle);

	if (forward)
	{
		forward->x = cp*cy;
		forward->y = cp*sy;
		forward->z = -sp;
	}

	if (right)
	{
		right->x = (-1 * sr*sp*cy + -1 * cr*-sy);
		right->y = (-1 * sr*sp*sy + -1 * cr*cy);
		right->z = -1 * sr*cp;
	}

	if (up)
	{
		up->x = (cr*sp*cy + -sr*-sy);
		up->y = (cr*sp*sy + -sr*cy);
		up->z = cr*cp;
	}
}

float CMiscellaneous::RandomFloat(float fMin, float fMax)
{
	static RandomFloat_t m_RandomFloat;

	if (!m_RandomFloat)
		m_RandomFloat = (RandomFloat_t)GetProcAddress(GetModuleHandleA("vstdlib.dll"), "RandomFloat");

	return m_RandomFloat(fMin, fMax);
}
void CMiscellaneous::RandomSeed(UINT Seed)
{
	static RandomSeed_t m_RandomSeed;

	if (!m_RandomSeed)
		m_RandomSeed = (RandomSeed_t)GetProcAddress(GetModuleHandleA("vstdlib.dll"), "RandomSeed");

	m_RandomSeed(Seed);
}

void rotate_movement(CUserCmd* cmd, float yaw)
{
	Vector viewangles;
	I::Engine->GetViewAnglesxd(viewangles);

	float rotation = DEG2RAD(viewangles.y - yaw);

	float cos_rot = cos(rotation);
	float sin_rot = sin(rotation);

	float new_forwardmove = (cos_rot * G::UserCmd->forwardmove) - (sin_rot * G::UserCmd->sidemove);
	float new_sidemove = (sin_rot * G::UserCmd->forwardmove) + (cos_rot * G::UserCmd->sidemove);

	G::UserCmd->forwardmove = new_forwardmove;
	G::UserCmd->sidemove = new_sidemove;
}

void CMiscellaneous::AutoStrafe()
{
	if( G::LocalPlayer->GetFlags() & FL_ONGROUND )
		return;

	if (!G::LocalPlayer->GetAlive())
		return;

	if (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
		return;

	Vector vVelocity = G::LocalPlayer->GetVelocity();
	float Speed = sqrt(vVelocity.x * vVelocity.x + vVelocity.y * vVelocity.y);

	float Tickrate = 1.1;

	static float OldY;
	float Difference = NormalizeFloat(G::UserCmd->viewangles.y - OldY);

	if (Vars.Misc.AutoStrafe)
	{
		//G::UserCmd->forwardmove = 450;

		float ideal_rotation = min(RAD2DEG(std::asinf(30.f / 10)) * 0.5f, 45.f);
		float sign = G::UserCmd->random_seed % 2 ? 1.f : -1.f;

		G::UserCmd->sidemove = 0.f;
		G::UserCmd->forwardmove = 450.f;

		rotate_movement(G::UserCmd, (ideal_rotation - 90.f) * sign);
	}
}



void CMiscellaneous::NameSteal()
{
#define RandomInt(min, max) (rand() % (max - min + 1) + min)
	if (!Vars.Misc.NameSteal)
		return;

	static float nextTime = 0.f;
	float flServerTime = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;

	if (nextTime > flServerTime)
		return;

	nextTime = flServerTime + Vars.Misc.NameStealDelay;


	static ConVar* name = I::Cvar->FindVar("name");

	char* szName = NULL;

	while (!szName)
	{
		player_info_t pInfo;
		I::Engine->GetPlayerInfo(RandomInt(0, I::ClientEntList->GetHighestEntityIndex()), &pInfo);

		if (strcmp(pInfo.name, "") != 0 && !(strcmp(pInfo.name, "GOTV") == 0)) szName = pInfo.name;
	}

	char nameChar[64];
	sprintf(nameChar, "%s ", szName);
	name->SetValue(nameChar);
}





void CMiscellaneous::ChangeName( const char* name )
{
	ConVar* nameConvar = I::Cvar->FindVar( charenc( "name" ) );
	*( int* )( ( DWORD )&nameConvar->fnChangeCallback + 0xC ) = NULL;
	nameConvar->SetValue( name );
}

void CMiscellaneous::ChangeCName()
{
	ConVar* nameConvar = I::Cvar->FindVar(charenc("name"));
	*(int*)((DWORD)&nameConvar->fnChangeCallback + 0xC) = NULL;

	switch (Vars.Misc.Cname)
	{
	case 0:
		break;
	case 1:
		nameConvar->SetValue("\x01\x0B\x02""M""\x05""o""\x02""r""\x05""p""\x02""h ""\x05""E""\x02""n""\x05""g""\x02""i""\x05""n""\x02""e""\x03");
		break;
	case 2:
		nameConvar->SetValue("\x01\x0B\x02""Gabe Newell""\x04");
		break;
	case 3:
		char str[512];
		sprintf(str, "\x01\x0B\x02""%s""\x09", G::LocalPlayer->GetName().c_str());
		nameConvar->SetValue(str);
		break;
	case 4:
		nameConvar->SetValue("\n\xAD\xAD\xAD");
		break;
	}
	//nameConvar->SetValue("\x01\x0B\x02""M""\x05""O""\x02""R""\x05""P""\x02""H ""\x05""E""\x02""N""\x05""G""\x02""I""\x05""N""\x02""E""\x03");
	
	//nameConvar->SetValue("\x01\x0B\x02""Gabe Newell""\x04");
	
	//nameConvar->SetValue("\x01\x0B\x02""L3D451R7""\x09");


}

void CMiscellaneous::ChatSpam(const char* text) {
	static float nextTime = 0.f;
	float flServerTime = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;

	if (nextTime > flServerTime)
		return;

	nextTime = flServerTime + 1.3f;

	std::string say = "say ";
	say += text;

	I::Engine->ExecuteClientCmd(say.c_str());
}

void CMiscellaneous::CircleStrafer()
{
	if (GetAsyncKeyState(0x86)) {
	}
}

//YourSetNameFunctionHere(" \x01\x0B\x02""M""\x05""E""\x02""R""\x05""R""\x02""Y ""\x05""C""\x02""H""\x05""R""\x02""I""\x05""S""\x02""T""\x05""M""\x02""A""\x05""S""\x03");

void CMiscellaneous::AirStuck()
{
	if( Vars.Ragebot.Enabled && G::UserCmd->buttons & IN_ATTACK )
		return;

	bool airset = false;

	if (GetKeyState(Vars.Misc.AirStuckKey) & 1)
		airset = !airset;
	
	if (airset)
		G::UserCmd->tick_count = INT_MAX;
}

void CMiscellaneous::GameResources()
{
	int Music = 20024;
	static DWORD GameResources = (U::FindPattern("client_panorama.dll", "8B 3D ? ? ? ? 85 FF 0F 84 ? ? ? ? 81 C7") + 2);

	DWORD ptrResource = **(DWORD**)GameResources;

	DWORD m_nMusicID = (DWORD)ptrResource + offsets.m_nMusicID + (G::LocalPlayer->GetIndex() * 4);

	//DWORD m_nActiveCoinRank = (DWORD)ptrResource + nActiveCoinRank + (G::LocalPlayer->GetIndex() * 4);

	if (Music > 0) *(PINT)((DWORD)m_nMusicID) = Music;
}

void CMiscellaneous::Panic()
{
	SetWindowLongPtrA( G::Window, GWL_WNDPROC, ( LONG_PTR )Hooks::oldWindowProc );
}