#pragma once
#include "../Cheat.h"
CLegitBot* LegitBot;
#define C_BaseEntity CBaseEntity
float curAimTime;
float deltaTime;
DWORD dwShotTime = NULL;
int huinia = 0;

float GetFov(const QAngle& viewAngle, const QAngle& aimAngle)
{
	QAngle delta = aimAngle - viewAngle;
	delta.Normalized();
	return sqrtf(powf(delta.x, 2.0f) + powf(delta.y, 2.0f));
}

int ClosestBone(C_BaseEntity *Entity, CUserCmd* cmd)
{
	if (Vars.Legitbot.Weapon[Vars.wpn].Hitbox >= 9)
	{
		float BestDist = 360.f;
		int aimbone;

		matrix3x4a_t matrix[MAXSTUDIOBONES];

		if (!Entity->SetupBones(matrix, 128, BONE_USED_BY_HITBOX, I::Engine->GetLastTimeStamp()))
			return -1;

		studiohdr_t* pStudioModel = I::ModelInfo->GetStudioModel(Entity->GetModel());
		if (!pStudioModel)
			return -1;

		mstudiohitboxset_t* set = pStudioModel->pHitboxSet(Entity->GetHitboxSet());
		if (!set)
			return -1;

		for (int i = 0; i < set->numhitboxes; i++)
		{
			if (   i == HITBOX_RIGHT_THIGH   || i == HITBOX_LEFT_THIGH     || i == HITBOX_RIGHT_CALF
				|| i == HITBOX_LEFT_CALF     || i == HITBOX_RIGHT_FOOT     || i == HITBOX_LEFT_FOOT
				|| i == HITBOX_RIGHT_HAND    || i == HITBOX_LEFT_HAND      || i == HITBOX_RIGHT_UPPER_ARM
				|| i == HITBOX_RIGHT_FOREARM || i == HITBOX_LEFT_UPPER_ARM || i == HITBOX_LEFT_FOREARM)
				continue;

			mstudiobbox_t* hitbox = set->pHitbox(i);

			if (!hitbox)
				continue;

			auto thisdist = GetFov(cmd->viewangles, M::CalcAngle(G::LocalPlayer->GetEyePosition(), Vector(matrix[hitbox->bone][0][3], matrix[hitbox->bone][1][3], matrix[hitbox->bone][2][3])));

			if (BestDist > thisdist)
			{
				BestDist = thisdist;
				aimbone = hitbox->bone;
				continue;
			}
		}
		return aimbone;
	}
	else
		return Vars.Legitbot.Weapon[Vars.wpn].Hitbox;
}

int CLegitBot::FindTarget(CBaseEntity* pLocalPlayer, CUserCmd* pCmd)
{
	float flMax = 8192.f;
	int iBestTarget = -1;
	curAimTime = 0.f;

	if (pLocalPlayer->GetAlive()) {
		for (int i = 0; i < I::ClientEntList->GetHighestEntityIndex(); i++)
		{
			CBaseEntity* pEntityPlayer = I::ClientEntList->GetClientEntity(i);
			if (!pEntityPlayer)
				continue;
			if (pEntityPlayer == pLocalPlayer)
				continue;
			if (!pEntityPlayer->GetAlive())
				continue;
			
			if (pEntityPlayer->GetTeam() == pLocalPlayer->GetTeam() && !Vars.Legitbot.Aimbot.FriendlyFire)
				continue;
			if (!pEntityPlayer->IsVisible(ClosestBone(pEntityPlayer, pCmd)))
				continue;
			float flFoV = GetFov(pCmd->viewangles, M::CalcAngle(pLocalPlayer->GetEyePosition(), pEntityPlayer->GetBonePosition(ClosestBone(pEntityPlayer, pCmd))));
			if (flFoV < flMax) {
				flMax = flFoV;
				iBestTarget = i;
			}
		}
	}

	if (!dwShotTime)
		dwShotTime = GetTickCount();

	if (!(G::UserCmd->buttons & IN_ATTACK))
	{
		G::KillStop = false;
		dwShotTime = NULL;
	}

	return iBestTarget;
}

bool LocalChecks() {

	if (!G::LocalPlayer || G::LocalPlayer->GetHealth() <= 0 || !G::LocalPlayer->GetAlive()) return false;
	return true;
}

bool IsValid(CBaseEntity* Entity) {

	if (!G::LocalPlayer)
		return false;

	if (!Entity) return false;
	if (Entity->GetTeam() == G::LocalPlayer->GetTeam() || Entity->GetHealth() <= 0) return false;

	return true;
}

bool CanHit(trace_t& tr) {
	if ((tr.hitgroup == HITGROUP_LEFTARM || tr.hitgroup == HITGROUP_RIGHTARM) && Vars.Legitbot.Triggerbot.Filter.Arms) return true;
	if (tr.hitgroup == HITGROUP_CHEST && Vars.Legitbot.Triggerbot.Filter.Chest) return true;
	if (tr.hitgroup == HITGROUP_HEAD && Vars.Legitbot.Triggerbot.Filter.Head) return true;
	if ((tr.hitgroup == HITGROUP_LEFTLEG || tr.hitgroup == HITGROUP_RIGHTLEG) && Vars.Legitbot.Triggerbot.Filter.Legs) return true;
	if (tr.hitgroup == HITGROUP_STOMACH && Vars.Legitbot.Triggerbot.Filter.Stomach) return true;
	return false;
}

void CLegitBot::TriggerBot() {
		if (!LocalChecks()) return;
		int weapid = G::LocalPlayer->GetWeapon()->GetItemDefinitionIndex();

		if (!Vars.Legitbot.Weapon[weapid].TriggerBot) return;
		
		Vector endPos;
		QAngle view = G::UserCmd->viewangles;

		trace_t tr;
		Ray_t ray;

		CTraceFilter filter;
		filter.pSkip = G::LocalPlayer;

		M::AngleVectors(view, &endPos);
		endPos = endPos * 8192.0f + G::LocalPlayer->GetEyePosition();

		ray.Init(G::LocalPlayer->GetEyePosition(), endPos);

		I::EngineTrace->TraceRay(ray, 0x4600400B, &filter, &tr);


		if (Vars.Legitbot.Triggerbot.CustomHitBoxes) {
			if (!CanHit(tr)) return;
		}

			if (tr.m_pEnt->GetHealth() > 0 && tr.m_pEnt->GetTeam() != G::LocalPlayer->GetTeam())
			{
				if (Vars.Legitbot.Triggerbot.IsOnKey) {
					if (GetAsyncKeyState(Vars.Legitbot.Triggerbot.Key))
						G::UserCmd->buttons |= IN_ATTACK;
				}
				else G::UserCmd->buttons |= IN_ATTACK;
				
			}
}


bool psile = false;

void CLegitBot::Run()
{
	static int CustomDelay = 0;

	if (!G::LocalPlayer)
		return;

	if (!Vars.Legitbot.Aimbot.Enabled)
		return;

	CBaseEntity* pLocalPlayer = G::LocalPlayer;

	if (!pLocalPlayer)
		return;

	if (!pLocalPlayer->GetAlive())
		return;

	if (!G::LocalPlayer)
		return;

	//if (!G::LocalPlayer->GetWeapon()->IsGun())
	//	return;

	if (!G::SendPacket /*&& (G::LocalPlayer->GetWeapon()->IsPistol() || G::LocalPlayer->GetWeapon()->IsSniper())*/)
	{
		G::SendPacket = true;
	}
	TriggerBot();
	int iTarget = FindTarget(pLocalPlayer, G::UserCmd);

	if (Vars.Legitbot.Aimbot.KillStop)
		huinia = 1;
	else
		huinia = 0;

	if (!((Vars.Legitbot.Aimbot.AlwaysOn) || (Vars.Legitbot.Aimbot.OnKey && G::PressedKeys[Vars.Legitbot.Aimbot.Key])))
	{
		G::SendPacket = true;
		return;
	}

	if (iTarget == -1)
		return;

	if (huinia == 1 && G::KillStop)
		return;

	CBaseEntity* pEntityPlayer = I::ClientEntList->GetClientEntity(iTarget);

	Vector vecBone = pEntityPlayer->GetBonePosition(ClosestBone(pEntityPlayer, G::UserCmd));

	if (vecBone.IsZero())
		return;

	if (Vars.Legitbot.Aimbot.SmokeCheck && U::LineToSmoke(G::LocalPlayer->GetEyePosition(), vecBone, true))
		return;

	QAngle qAim = M::CalcAngle(pLocalPlayer->GetEyePosition(), vecBone);

	if (!pEntityPlayer->IsVisible(ClosestBone(pEntityPlayer, G::UserCmd)))
		return;

	static bool psile = false;

	psile = (Vars.Legitbot.Weapon[Vars.wpn].pSilent && (G::LocalPlayer->GetShotsFired() < 1)) ? true : false;

	float FOV = psile ? Vars.Legitbot.Weapon[Vars.wpn].PFOV : Vars.Legitbot.Weapon[Vars.wpn].FOV;

	if (GetFov(G::UserCmd->viewangles, qAim) > FOV)
		return;

	int flRecoilX = Vars.Legitbot.Weapon[Vars.wpn].RCSAmountX;
	int flRecoilY = Vars.Legitbot.Weapon[Vars.wpn].RCSAmountY;

	if (Vars.Menu.Opened)
		return;

	if ((flRecoilX > 1 || flRecoilY > 1) && G::LocalPlayer->GetShotsFired() > 2) {
		if (pLocalPlayer->GetPunch().Length() > 0 && pLocalPlayer->GetPunch().Length() < 150)
		{
			if (flRecoilX > 1)
				qAim.x -= pLocalPlayer->GetPunch().x * (flRecoilX / 50.f);

			if (flRecoilY > 1)
				qAim.y -= pLocalPlayer->GetPunch().y * (flRecoilY / 50.f);
		}
	}

	if (!G::SendPacket /*&&(G::LocalPlayer->GetWeapon()->IsPistol() || G::LocalPlayer->GetWeapon()->IsSniper())*/)
	{
		G::SendPacket = true;
	}
	else
		G::SendPacket = psile ? false : true;

	float flSmooth = psile ? 0.f : Vars.Legitbot.Weapon[Vars.wpn].Speed;

	if (flSmooth >= 1.f)
	{
		QAngle delta = G::UserCmd->viewangles - qAim;
		if (!delta.IsZero())
		{
			delta.Normalized();
			qAim = G::UserCmd->viewangles - delta / flSmooth;
		}
	}

	qAim.Normalized();
	qAim.Clamp();

	

	if (Vars.Legitbot.fastzoom)
	{
		if (G::UserCmd->buttons & IN_ATTACK)
		{
			if (/*G::LocalPlayer->GetWeapon()->IsSniper()*/false) {
				if (!G::LocalPlayer->IsScoped())
				{
					G::UserCmd->buttons &= ~IN_ATTACK;
					G::UserCmd->buttons |= IN_ZOOM;
				}

				if ((G::UserCmd->buttons & IN_ATTACK) && Vars.Legitbot.fastzoomswitch) {
					I::Engine->ExecuteClientCmd("lastinv");
				}
			}
		}
	}



	G::UserCmd->viewangles = qAim;

	if (!dwShotTime && G::UserCmd->buttons & IN_ATTACK)
		dwShotTime = GetTickCount();


	if (!Vars.Legitbot.Weapon[Vars.wpn].pSilent || (G::LocalPlayer->GetShotsFired() > 1 && Vars.Legitbot.Weapon[Vars.wpn].pSilent) || !psile)
		I::Engine->SetViewAngles(G::UserCmd->viewangles);

	if (Vars.Legitbot.Weapon[Vars.wpn].FireDelayEnabled && (!Vars.Legitbot.Weapon[Vars.wpn].pSilent))
	{
		if (dwShotTime + Vars.Legitbot.Weapon[Vars.wpn].FireDelay >= GetTickCount())
			G::UserCmd->buttons &= ~IN_ATTACK;
	}
	return;
}

bool IsHitChance(float flChance, CBaseCombatWeapon *pWep)
{
	if (flChance >= 99.f)
		flChance = 99.f;

	if (flChance < 1)
		flChance = 1;

	float flSpread = pWep->GetInaccuracyReal() * 10;
	return((((100.f - flChance) * 0.65f) * 0.01125) >= flSpread);
}