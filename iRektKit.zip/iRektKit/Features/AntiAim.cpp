#include "../Cheat.h"

#define RandomInt(min, max) (rand() % (max - min + 1) + min)
CAntiAim* AntiAim = new CAntiAim;




inline void VectorSubtract(const Vector& a, const Vector& b, Vector& c)
{
	CHECK_VALID(a);
	CHECK_VALID(b);
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	c.z = a.z - b.z;
}
void angleVectorsxd(const Vector& angles, Vector& forward)
{
	Assert(s_bMathlibInitialized);
	Assert(forward);

	float sp, sy, cp, cy;

	sy = sin(DEG2RAD(angles[1]));
	cy = cos(DEG2RAD(angles[1]));

	sp = sin(DEG2RAD(angles[0]));
	cp = cos(DEG2RAD(angles[0]));

	forward.x = cp * cy;
	forward.y = cp * sy;
	forward.z = -sp;
}



__forceinline float DotProducttt(const float *a, const float *b)
{
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}

void VectorTransformmm(const float *in1, const matrix3x4_t& in2, float *out)
{
	out[0] = DotProducttt(in1, in2[0]) + in2[0][3];
	out[1] = DotProducttt(in1, in2[1]) + in2[1][3];
	out[2] = DotProducttt(in1, in2[2]) + in2[2][3];
}
static void VectorTransformmm(const Vector& in1, const matrix3x4_t& in2, Vector& out)
{
	VectorTransformmm(&in1.x, in2, &out.x);
}
Vector get_hitbox_location(CBaseEntity* obj, int hitbox_id) {
	matrix3x4_t bone_matrix[128];

	if (obj->SetupBones(bone_matrix, 128, 0x00000100, 0.0f)) {
		if (obj->GetModel()) {
			auto studio_model = I::ModelInfo->GetStudioModel(obj->GetModel());
			if (studio_model) {
				auto hitbox = studio_model->pHitboxSet(0)->pHitbox(hitbox_id);
				if (hitbox) {
					auto min = Vector{}, max = Vector{};

					VectorTransformmm(hitbox->bbmin, bone_matrix[hitbox->bone], min);
					VectorTransformmm(hitbox->bbmax, bone_matrix[hitbox->bone], max);

					return (min + max) / 2.0f;
				}
			}
		}
	}
	return Vector{};
}


bool is_viable_target(CBaseEntity* pEntity)
{
	//ClientClass* pClass = (ClientClass*)pEntity->GetClientClass();
	if (!pEntity) return false;
	//if (pClass->m_ClassID != (int)CSGOClassID::CCSPlayer) return false;
	if (pEntity == G::LocalPlayer) return false;
	if (pEntity->GetTeam() == G::LocalPlayer->GetTeam()) return false;
	if (pEntity->GetImmune()) return false;
	if (!pEntity->GetAlive()) return false;
	return true;
}


void AngleVectors(const Vector &angles, Vector *forward, Vector *right, Vector *up)
{
	auto SinCos = [](float flRadians, float* pflSine, float* pflCosine)
	{
		__asm
		{
			fld	DWORD PTR[flRadians]
			fsincos
			mov edx, DWORD PTR[pflCosine]
			mov eax, DWORD PTR[pflSine]
			fstp DWORD PTR[edx]
			fstp DWORD PTR[eax]
		}
	};
	float sr, sp, sy, cr, cp, cy;

	SinCos(DEG2RAD(angles[1]), &sy, &cy);
	SinCos(DEG2RAD(angles[0]), &sp, &cp);
	SinCos(DEG2RAD(angles[2]), &sr, &cr);

	if (forward)
	{
		forward->x = cp * cy;
		forward->y = cp * sy;
		forward->z = -sp;
	}

	if (right)
	{
		right->x = (-1 * sr*sp*cy + -1 * cr*-sy);
		right->y = (-1 * sr*sp*sy + -1 * cr*cy);
		right->z = -1 * sr*cp;
	}

	if (up)
	{
		up->x = (cr*sp*cy + -sr * -sy);
		up->y = (cr*sp*sy + -sr * cy);
		up->z = cr * cp;
	}
}

void calculate_angle(Vector src, Vector dst, Vector &angles)
{
	Vector delta = src - dst;
	double hyp = delta.Length2D();
	angles.y = (atan(delta.y / delta.x) * 57.295779513082f);
	angles.x = (atan(delta.z / hyp) * 57.295779513082f);
	angles[2] = 0.0f;
	if (delta.x >= 0.0)
		angles.y += 180.0f;
}


void normalize(Vector &vIn, Vector &vOut)
{
	float flLen = vIn.Length();
	if (flLen == 0) {
		vOut.Init(0, 0, 1);
		return;
	}
	flLen = 1 / flLen;
	vOut.Init(vIn.x * flLen, vIn.y * flLen, vIn.z * flLen);
}
int aa_indicator = 0;


void FreestandingRun(QAngle& angle)
{
	if (!Vars.Ragebot.AntiAim.Freestading)
		return;

	static float last_autodirect_angle;
	if (G::LocalPlayer->GetVelocity().Length() < 300) {

		auto fov_to_player = [](Vector view_offset, Vector view, CBaseEntity* m_entity, int hitbox)
		{
			CONST FLOAT MaxDegrees = 180.0f;
			Vector Angles = view;
			Vector Origin = view_offset;
			Vector Delta(0, 0, 0);
			Vector Forward(0, 0, 0);
			angleVectorsxd(Angles, Forward);
			Vector AimPos = get_hitbox_location(m_entity, hitbox);
			VectorSubtract(AimPos, Origin, Delta);
			normalize(Delta, Delta);
			FLOAT DotProduct = Forward.Dot(Delta);
			return (acos(DotProduct) * (MaxDegrees / 3.14159265358979323846f));
		};

		int target = -1;
		float mfov = 50;

		Vector viewoffset = G::LocalPlayer->GetEyePosition();
		Vector view;
		I::Engine->GetViewAnglesxd(view);

		for (int i = 0; i < I::Globals->maxClients; i++) {
			CBaseEntity* m_entity = I::ClientEntList->GetClientEntity(i);

			if (is_viable_target(m_entity)) {

				float fov = fov_to_player(viewoffset, view, m_entity, 0);
				if (fov < mfov) {
					mfov = fov;
					target = i;
				}
			}
		}

		Vector at_target_angle;

		if (target)
		{
			auto m_entity = I::ClientEntList->GetClientEntity(target);

			if (is_viable_target(m_entity))
			{
				Vector head_pos_screen;

				if (D::WorldToScreen(m_entity->GetBonePosition(8), head_pos_screen))
				{

					calculate_angle(G::LocalPlayer->GetOrigin(), m_entity->GetOrigin(), at_target_angle);
					at_target_angle.x = 0;

					Vector src3D, dst3D, forward, right, up, src, dst;
					float back_two, right_two, left_two;

					trace_t tr;
					Ray_t ray, ray2, ray3, ray4, ray5;
					CTraceFilter filter;

					const Vector to_convert = at_target_angle;
					AngleVectors(to_convert, &forward, &right, &up);

					filter.pSkip = G::LocalPlayer;
					src3D = G::LocalPlayer->GetEyePosition();
					dst3D = src3D + (forward * 384); //Might want to experiment with other numbers, incase you don't know what the number does, its how far the trace will go. Lower = shorter.

					ray.Init(src3D, dst3D);
					I::EngineTrace->TraceRay(ray, MASK_SHOT, &filter, &tr);
					back_two = (tr.endpos - tr.startpos).Length();

					ray2.Init(src3D + right * 35, dst3D + right * 35);
					I::EngineTrace->TraceRay(ray2, MASK_SHOT, &filter, &tr);
					right_two = (tr.endpos - tr.startpos).Length();

					ray3.Init(src3D - right * 35, dst3D - right * 35);
					I::EngineTrace->TraceRay(ray3, MASK_SHOT, &filter, &tr);
					left_two = (tr.endpos - tr.startpos).Length();
					static int timer;
					static int timer1;
					if (left_two > right_two)
					{
						timer1 = 0;

						timer++;
						if (timer >= 15)
						{
							G::UserCmd->viewangles.y += 90;
							last_autodirect_angle = +90;
							aa_indicator = 1;
						}
						else
							aa_indicator = 0;


					}
					else if (right_two > left_two)
					{
						timer = 0;
						timer1++;
						if (timer1 >= 15)
						{
							angle.y -= 90;
							last_autodirect_angle = -90;
							aa_indicator = 2;
						}
						else
							aa_indicator = 0;
					}
					else
					{
						aa_indicator = 0;
					}

				}
			}
			else
				aa_indicator = 0;


		}
		else
			aa_indicator = 0;
	}
}










static bool BreakLBY()
{
	float curtime = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
	float velocity = GetAsyncKeyState(VK_SHIFT) ? 0 : G::LocalPlayer->GetVelocity().Length2D();

	if (G::NextLBYUpdateTime > curtime + 1.1)
	{
		G::NextLBYUpdateTime = 0;
	}

	if (velocity > 0.1f)
	{
		G::NextLBYUpdateTime = curtime + 0.22 + I::Globals->interval_per_tick;
		return false;
	}

	if ((G::NextLBYUpdateTime < curtime) && (G::LocalPlayer->GetFlags() & FL_ONGROUND) && velocity < 1.f)
	{
		G::NextLBYUpdateTime = curtime + 1.1 + I::Globals->interval_per_tick;
		return true;
	}

	return false;
}


float Distance(Vector a, Vector b)
{
	return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2) + pow(a.z - b.z, 2));
}

void CalcAngle(Vector src, Vector dst, QAngle &angles)
{
	Vector delta = src - dst;
	double hyp = delta.Length2D();
	angles.y = (atan(delta.y / delta.x) * 57.295779513082f);
	angles.x = (atan(delta.z / hyp) * 57.295779513082f);
	angles[2] = 0.00;

	if (delta.x >= 0.0)
		angles.y += 180.0f;
}

bool CAntiAim::GetBestHeadAngle(QAngle& angle)
{
	Vector position = G::LocalPlayer->GetEyePosition();

	float closest_distance = 100.0f;

	float radius = Vars.Ragebot.Antiaim.EdgeDistance + 0.1f;
	float step = M_PI * 2.0 / 8;

	for (float a = 0; a < (M_PI * 2.0); a += step)
	{
		Vector location(radius * cos(a) + position.x, radius * sin(a) + position.y, position.z);

		Ray_t ray;
		trace_t tr;
		ray.Init(position, location);
		CTraceFilter traceFilter;
		traceFilter.pSkip = G::LocalPlayer;
		I::EngineTrace->TraceRay(ray, 0x4600400B, &traceFilter, &tr);

		float distance = Distance(position, tr.endpos);

		if (distance < closest_distance)
		{
			closest_distance = distance;
			angle.y = RAD2DEG(a);
		}
	}

	return closest_distance < Vars.Ragebot.Antiaim.EdgeDistance;
}

bool CAntiAim::HasViableEnemy()
{
	for (int i = 1; i < I::Engine->GetMaxClients(); ++i)
	{
		CBaseEntity* entity = I::ClientEntList->GetClientEntity(i);

		if (!entity
			|| entity == G::LocalPlayer
			
			|| !entity->GetAlive()
			|| entity->GetImmune())
			continue;

		if (Vars.Ragebot.FriendlyFire || entity->GetTeam() != G::LocalPlayer->GetTeam())
			return true;
	}

	return false;
}

QAngle AtTargets() {

	if (!Vars.Ragebot.Antiaim.AtPlayer)
		return QAngle(0, 0, 0);

	if (!AntiAim->HasViableEnemy())
		return QAngle(0, 0, 0);

	float lowest = 99999999.f;
	Vector EyePos = G::LocalPlayer->GetEyePosition() + G::LocalPlayer->GetOrigin();

	for (int i = 1; i < 65; i++) {
		if (i == I::Engine->GetLocalPlayer())
			continue;

		CBaseEntity* pEnt = I::ClientEntList->GetClientEntity(i);

		if (!pEnt)
			continue;

		

		if (!pEnt->GetAlive())
			continue;

		if (pEnt->GetTeam() == G::LocalPlayer->GetTeam())
			continue;

		Vector CurPos = pEnt->GetEyePosition() + pEnt->GetOrigin();

		QAngle angles;

		if (CurPos.DistToSqr(EyePos) < lowest) {
			lowest = CurPos.Dist(EyePos);
			CalcAngle(EyePos, CurPos, angles);
			return angles;
		}
	}
	return QAngle(0, 0, 0);
}

void DoAntiAimY(QAngle& angle, bool bFlip)
{
	static bool n1;
	static bool n2;
	float add;
	static bool attck;
	static bool flip;
	static bool flip2;
	flip = !flip;
	flip2 = !flip2;

	static float fYaw = 0.0f;
	static bool yFlip;

	if (bFlip)
		n1 = !n1;
	else
		n2 = !n2;


	if (bFlip)
		yFlip = !yFlip;

	if (Vars.Ragebot.Antiaim.FakeYaw)
	{
		int aa_type = G::SendPacket ? Vars.Ragebot.Antiaim.YawReal : Vars.Ragebot.Antiaim.YawFake;


		if (aa_type == SPIN)
		{
			if (Vars.Ragebot.Antiaim.spinspeed < 1) Vars.Ragebot.Antiaim.spinspeed = 3;
			float CalculatedCurTime_1 = (I::Globals->curtime * (Vars.Ragebot.Antiaim.spinspeed * 100));
			add = 1.f + CalculatedCurTime_1;
		}
		else if (aa_type == ADD90FAKE)
		{
			//if (!flip)
				//angle.y += 1.f + RandomInt(85, 105);
			static bool Switch = false;

			if (GetAsyncKeyState(VK_XBUTTON1) & 1)
				Switch = !Switch;

			if (G::LocalPlayer->GetVelocity().Length2D() > 0.5) {
				add = 179;
			}

			if (Switch)
			{
				if (G::SendPacket) // Fake
					add = 90;
				else		       // Real
					add = -90;
			}
			else
			{
				if (G::SendPacket) // Fake
					add = -90;
				else			   // Real
					add = 90;
			}

			if (G::LastLBYUpdate)
			{
				if (Switch)
				{
					if (G::SendPacket) // Fake
						add = -90;
					else		       // Real
						add = 90;
				}
				else
				{
					if (G::SendPacket) // Fake
						add = 90;
					else			   // Real
						add = -90;
				}
			}
		}
		else if (aa_type == SIDE)
		{
			if (!Vars.Ragebot.Antiaim.AtPlayer)
			{
				if (flip)
					add = 1.f + 90.0f;
				else
					add = 1.f + -90.0f;
			}
			else
			{
				if (flip)
					add = RandomInt(80, 120);
				else
					add = RandomInt(-80, -120);
			}
		}
		else if (aa_type == SIDE2)
		{
			if (G::SendPacket)
			{
				if (G::LocalPlayer->GetVelocity().Length2D() > 1)
				{
					if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
					{
						add = 90;
					}
					else
					{
						add = -90;
					}
				}
				else
				{
					add = 170;
				}
			}
			else
			{
				if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
				{
					add = -45;
				}
				else
				{
					if (G::LocalPlayer->GetVelocity().Length2D() > 1)
					{
						add = -161;
					}
					else
					{
						add = -20;
					}
				}
			}
		}
		else if (aa_type == BACKWARDS)
			add = 180.0f;
		else if (aa_type == LEFT)
			add = 90.0f;
		else if (aa_type == RIGHT)
			add = -90.0f;
		else if (aa_type == ZERO)
			add = 0.0f;
		else if (aa_type == FAKESPIN)
		{
			static int yawadd;
			int AddRate = I::Globals->curtime * 7000;

			while (AddRate > 180.f)
				AddRate -= 360.f;

			while (AddRate < -180.f)
				AddRate += 360.f;

			add = (flip2 ? AddRate : (yawadd == 5 ? (G::UserCmd->command_number % 2 ? 90 : -90) : (G::UserCmd->command_number % 2 ? RandomInt(60, 195) : RandomInt(-60, -195))));

			yawadd++;
			if (yawadd >= 4)
				yawadd = 0;
		}
		else if (aa_type == LOWERBODY)
		{
			//add = 1.f + (G::FSNLBY + flip2 ? RandomInt(60, 195) : RandomInt(-60, -195));
			static bool Switch = false;

			if (GetAsyncKeyState(VK_XBUTTON1) & 1)
				Switch = !Switch;

			if (G::LocalPlayer->GetVelocity().Length2D() > 0.5) {
				add = 179;
			}

			if (Switch)
				add = -90;
			else
				add = 90;


			if (G::LastLBYUpdate)
			{
				if (Switch)
					add = 90;
				else
					add = -90;
			}
		}
		else if (aa_type == LAGSPIN)
		{
			if (G::SendPacket)
			{
				if (n1)
					add = 1.f + 70;
				else
					add = 1.f + 140;

				if (n2)
					add = 1.f + -70;
				else
					add = 1.f + -140;
			}
			else
			{
				if (n1)
					add = 1.f + RandomInt(55, 80);
				else
					add = 1.f + RandomInt(125, 140);

				if (n2)
					add = 1.f + RandomInt(-55, -80);
				else
					add = 1.f + RandomInt(-125, -140);
			}
		}
		else if (aa_type == MEMESPIN)
		{
				add = 1.f + 135;
		}
		else if (aa_type == TESTING)
		{
			static int tickmeme = 0;

			if (G::LocalPlayer->GetVelocity().Length2D() > 1.f) {
				add = 179.0f;
			}

			if (tickmeme <= 30)
			{
				if (G::SendPacket)
				{
					if (G::LastLBYUpdate)
						add = 219.f;
					else
						add = 149.f;
				}
				else
				{
					if (G::LastLBYUpdate)
						add = 149.f;
					else
						add = 219.f;
				}
			}
			else if (tickmeme >= 30 && tickmeme <= 60)
			{
				if (G::SendPacket)
				{
					if (G::LastLBYUpdate)
						add = 149.f;
					else
						add = 219.f;
				}
				else
				{
					if (G::LastLBYUpdate)
						add = 219.f;
					else
						add = 149.f;
				}
			}
			tickmeme++;

			if (tickmeme >= 61)
				tickmeme = 0;
		}
	}
	else
	{
		int aa_type = Vars.Ragebot.Antiaim.YawReal; 


		if (aa_type == SPIN)
		{
			if (Vars.Ragebot.Antiaim.spinspeed < 1) Vars.Ragebot.Antiaim.spinspeed = 3;
			float CalculatedCurTime_1 = (I::Globals->curtime * (Vars.Ragebot.Antiaim.spinspeed * 100));
			add = 1.f + CalculatedCurTime_1;
		}
		else if (aa_type == ADD90FAKE)
		{
			//if (!flip)
			//angle.y += 1.f + RandomInt(85, 105);
			static bool Switch = false;

			if (GetAsyncKeyState(VK_XBUTTON1) & 1)
				Switch = !Switch;

			if (G::LocalPlayer->GetVelocity().Length2D() > 0.5) {
				add = 179;
			}

			if (Switch)
			{
				if (G::SendPacket) // Fake
					add = 90;
				else		       // Real
					add = -90;
			}
			else
			{
				if (G::SendPacket) // Fake
					add = -90;
				else			   // Real
					add = 90;
			}

			if (G::LastLBYUpdate)
			{
				if (Switch)
				{
					if (G::SendPacket) // Fake
						add = -90;
					else		       // Real
						add = 90;
				}
				else
				{
					if (G::SendPacket) // Fake
						add = 90;
					else			   // Real
						add = -90;
				}
			}

		}
		else if (aa_type == SIDE)
		{
			if (!Vars.Ragebot.Antiaim.AtPlayer)
			{
				if (flip)
					add = 1.f + 90.0f;
				else
					add = 1.f + -90.0f;
			}
			else
			{
				if (flip)
					add = RandomInt(80, 120);
				else
					add = RandomInt(-80, -120);
			}
		}
		else if (aa_type == SIDE2)
		{
			if (G::SendPacket)
			{
				if (G::LocalPlayer->GetVelocity().Length2D() > 1)
				{
					if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
					{
						add = 90;
					}
					else
					{
						add = -90;
					}
				}
				else
				{
					add = 170;
				}
			}
			else
			{
				if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
				{
					add = -45;
				}
				else
				{
					if (G::LocalPlayer->GetVelocity().Length2D() > 1)
					{
						add = -161;
					}
					else
					{
						add = -20;
					}
				}
			}
		}
		else if (aa_type == BACKWARDS)
			add = 180.0f;
		else if (aa_type == LEFT)
			add = 90.0f;
		else if (aa_type == RIGHT)
			add = -90.0f;
		else if (aa_type == ZERO)
			add = 0.0f;
		else if (aa_type == FAKESPIN)
		{
			static int yawadd;
			int AddRate = I::Globals->curtime * 7000;

			while (AddRate > 180.f)
				AddRate -= 360.f;

			while (AddRate < -180.f)
				AddRate += 360.f;

			add = (flip2 ? AddRate : (yawadd == 5 ? (G::UserCmd->command_number % 2 ? 90 : -90) : (G::UserCmd->command_number % 2 ? RandomInt(60, 195) : RandomInt(-60, -195))));

			yawadd++;
			if (yawadd >= 4)
				yawadd = 0;
		}
		else if (aa_type == LOWERBODY)
		{
			//add = 1.f + (G::FSNLBY + flip2 ? RandomInt(60, 195) : RandomInt(-60, -195));
			static bool Switch = false;

			if (GetAsyncKeyState(VK_XBUTTON1) & 1)
				Switch = !Switch;

			if (G::LocalPlayer->GetVelocity().Length2D() > 0.5) {
				add = 179;
			}

			if (Switch)
				add = -90;
			else
				add = 90;

			if (G::LastLBYUpdate)
			{
				if (Switch)
					add = 90;
				else
					add = -90;
			}
		}
		else if (aa_type == LAGSPIN)
		{
			if (G::SendPacket)
			{
				if (n1)
					add = 1.f + 70;
				else
					add = 1.f + 140;

				if (n2)
					add = 1.f + -70;
				else
					add = 1.f + -140;
			}
			else
			{
				if (n1)
					add = 1.f + RandomInt(55, 80);
				else
					add = 1.f + RandomInt(125, 140);

				if (n2)
					add = 1.f + -RandomInt(-55, -80);
				else
					add = 1.f + RandomInt(-125, -140);
			}
		}
		else if (aa_type == MEMESPIN)
		{
			static int jitterangle = 0;

			if (jitterangle <= 1)
			{
				add = 1.f + 135;
			}
			else if (jitterangle > 1 && jitterangle <= 3)
			{
				add = 1.f + 225;
			}

			static int iChoked = -1;
			iChoked++;
			if (iChoked < 1)
			{
				G::SendPacket = false;
				if (jitterangle <= 1)
				{
					add = 1.f + 45;
					jitterangle += 1;
				}
				else if (jitterangle > 1 && jitterangle <= 3)
				{
					add = 1.f + 45;
					jitterangle += 1;
				}
				else
				{
					jitterangle = 0;
				}
			}
			else
			{
				G::SendPacket = true;
				iChoked = -1;
			}
			jitterangle++;
		}
		else if (aa_type == TESTING)
		{
			//G::SendPacket = yFlip;
			static int tickmeme = 0;

			if (G::LocalPlayer->GetVelocity().Length2D() > 1.f) {
				add = 179.0f;
			}

			if (tickmeme <= 30)
			{
				if (G::SendPacket)
				{
					if (G::LastLBYUpdate)
						add = 219.f;
					else
						add = 149.f;
				}
				else
				{
					if (G::LastLBYUpdate)
						add = 149.f;
					else
						add = 219.f;
				}
			}
			else if (tickmeme >= 30 && tickmeme <= 60)
			{
				if (G::SendPacket)
				{
					if (G::LastLBYUpdate)
						add = 149.f;
					else
						add = 219.f;
				}
				else
				{
					if (G::LastLBYUpdate)
						add = 219.f;
					else
						add = 149.f;
				}
			}
			tickmeme++;

			if (tickmeme >= 61)
				tickmeme = 0;
		}

		if (Vars.Ragebot.Antiaim.Shuffle)
		{
			if (*G::LocalPlayer->GetLowerBodyYawTarget() == angle.y)
				add = angle.y + 33.983148f;
		}
	}

	angle.y += add;
}
static bool IsFakeLagging;











bool FakeWalk()
{
	if (GetAsyncKeyState(Vars.Ragebot.AntiAim.FakeWalkButton) && Vars.Ragebot.AntiAim.FakeWalk)
	{
		static int choked = 0;
		choked = choked > 13 ? 0 : choked + 1;
		G::UserCmd->forwardmove = choked < 3 || choked > 6 ? 0 : G::UserCmd->forwardmove;
		G::UserCmd->sidemove = choked < 3 || choked > 6 ? 0 : G::UserCmd->sidemove;
		G::SendPacket = choked < 1;
		return true;
	}
	return false;
}

void Fakelags()
{
	if (!Vars.Ragebot.AntiAim.FakeLagEnable
		|| G::LocalPlayer->GetVelocity().Length2D() < 0.1f
		|| G::UserCmd->buttons & IN_ATTACK
		|| (G::LocalPlayer->GetFlags() & FL_ONGROUND) && Vars.Ragebot.AntiAim.FakeLagInAirOnly
		|| FakeWalk()) {
		IsFakeLagging = false;
		return;
	}

	switch (Vars.Ragebot.AntiAim.FakeLag)
	{
	case 0: // VERY good
	{
		static float last_landtime;
		if (G::LocalPlayer->GetFlags() & FL_ONGROUND)
		{
			static bool sw = false;
			static int timer = 0;
			timer++;
			G::SendPacket = false;
			static int ticks = 0;
			ticks++;
			if (ticks > 15)
			{
				sw = !sw;
				ticks = 0;
			}
			int choke = sw ? Vars.Ragebot.AntiAim.FakeLagAmount / 2 : Vars.Ragebot.AntiAim.FakeLagAmount;
			if (timer > choke)
			{
				G::SendPacket = true;
				timer = 0;
			}
			last_landtime = I::Globals->curtime;
		}
		else
		{
			if (fabsf(last_landtime - I::Globals->curtime) > 0.22f)
			{
				static int choke = Vars.Ragebot.AntiAim.FakeLagAmount;
				if (choke > Vars.Ragebot.AntiAim.FakeLagAmount)
				{
					choke = Vars.Ragebot.AntiAim.FakeLagAmount / 2;
				}
				static int timer = 0;
				timer++;
				G::SendPacket = false;
				if (timer > choke)
				{
					G::SendPacket = true;
					timer = 0;
					choke++;
				}
			}
		}

		IsFakeLagging = true;
	}
	break;
	case 1:
	{
		if (!(G::LocalPlayer->GetFlags() & FL_ONGROUND))
		{
			static int choke = Vars.Ragebot.AntiAim.FakeLagAmount / 2;
			if (choke > Vars.Ragebot.AntiAim.FakeLagAmount / 2)
			{
				choke = Vars.Ragebot.AntiAim.FakeLagAmount;
			}
			static int timer = 0;
			timer++;
			G::SendPacket = false;

			if (timer > choke)
			{
				G::SendPacket = true;
				timer = 0;
				choke++;
			}
		}
		else
		{
			auto tick = rand() % 2 ? 2 : Vars.Ragebot.AntiAim.FakeLagAmount;
			static int choke = tick;
			if (choke > tick)
			{
				choke = Vars.Ragebot.AntiAim.FakeLagAmount;
			}
			static int timer = 0;
			timer++;
			G::SendPacket = false;

			if (timer > choke)
			{
				G::SendPacket = true;
				timer = 0;
				choke++;
			}
		}
		IsFakeLagging = true;
	}
	break;
	case 2:
	{
		static int choke = Vars.Ragebot.AntiAim.FakeLagAmount / 2;
		if (choke > Vars.Ragebot.AntiAim.FakeLagAmount)
		{
			choke = Vars.Ragebot.AntiAim.FakeLagAmount;
		}
		static int timer = 0;
		timer++;
		G::SendPacket = false;
		if (timer > choke)
		{
			G::SendPacket = true;
			timer = 0;
			choke++;
		}
		IsFakeLagging = true;
	}
	break;
	}
}






void InitAntiAims(QAngle& angle)
{
	

	auto DoYaw = [](int select, QAngle& angle)
	{
		switch (select)
		{
		case 1:
			angle.y += 180;
			break;
		case 2:
		{
			static float tick;
			tick += Vars.Ragebot.AntiAim.SpinSpeed;
			if (tick > 360)
				tick = 0;

			angle.y = tick;
		}
		break;
		case 3:
		{
			float range = Vars.Ragebot.AntiAim.JitterRange / 2;

			angle.y += 180 + M::RandFloat(range, -range);
		}
		break;
		case 4:
		{
			float range = Vars.Ragebot.AntiAim.JitterRange2 / 2;

			static bool flip;
			auto InitFlip = []() {
				static clock_t start1_t1 = clock();
				double timeSoFar1 = (double)(clock() - start1_t1) / CLOCKS_PER_SEC;
				if (timeSoFar1 < 0.05)
					return;
				flip = !flip;
				start1_t1 = clock();
			};

			InitFlip();

			angle.y += 180 + (flip ? range : -range);
		}
		break;
		case 5:
		{
			float server_time = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
			static float rotate_speed = 100;
			static float rotate_range = 120;
			float yaws = fmod(static_cast<float>(server_time) * rotate_speed, rotate_range);

			angle.y += 180 - ((rotate_range / 2) - static_cast<float>(yaws));
		}
		break;
		case 7:
		{
			angle.y += Vars.Ragebot.AntiAim.cX;
		}
		
		case 6:
		{
			static float t;
			t += 5;
			if (t > 240)
				t = 120;
			angle.y += t;
		}
		


		}
		
	};


	
}


void VectorAngles3D(Vector& vecForward, Vector& vecAngles)
{
	Vector vecView;
	if (vecForward[1] == 0.f && vecForward[0] == 0.f)
	{
		vecView[0] = 0.f;
		vecView[1] = 0.f;
	}
	else
	{
		vecView[1] = atan2(vecForward[1], vecForward[0]) * 180.f / M_PI;

		if (vecView[1] < 0.f)
			vecView[1] += 360;

		vecView[2] = sqrt(vecForward[0] * vecForward[0] + vecForward[1] * vecForward[1]);

		vecView[0] = atan2(vecForward[2], vecView[2]) * 180.f / M_PI;
	}

	vecAngles[0] = -vecView[0];
	vecAngles[1] = vecView[1];
}
void CorrectMovement(QAngle vOldAngles, CUserCmd* pCmd, QAngle Viewangs)
{
	Vector vMove(pCmd->forwardmove, pCmd->sidemove, pCmd->upmove);
	float flSpeed = sqrt(vMove.x * vMove.x + vMove.y * vMove.y), flYaw;
	Vector vMove2;
	VectorAngles3D(vMove, vMove2);

	flYaw = DEG2RAD(Viewangs.y - vOldAngles.y + vMove2.y);
	pCmd->forwardmove = cos(flYaw) * flSpeed;
	pCmd->sidemove = sin(flYaw) * flSpeed;

	if (Viewangs.x < -90.f || Viewangs.x > 90.f)
		pCmd->forwardmove = -pCmd->forwardmove;
}



void CAntiAim::Run()
{

	if (!Vars.Ragebot.Enabled)
		return;

	if (!G::LocalPlayer || !G::LocalPlayer->GetWeapon() || !G::LocalPlayer->GetAlive())
		return;

	bool canshoot = true;

	QAngle oldAngle = G::UserCmd->viewangles;
	float oldForward = G::UserCmd->forwardmove;
	float oldSideMove = G::UserCmd->sidemove;

	float server_time = G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
	float next_shot = G::LocalPlayer->GetWeapon()->GetNextPrimaryAttack() - server_time;

	if (next_shot > 0 || (Vars.Ragebot.AutoStop && G::LocalPlayer->GetVelocity().Length() > 10))
		canshoot = false;

	static int chocked = 0;

	if (canshoot && (G::UserCmd->buttons & IN_ATTACK) && Vars.Ragebot.pSilent)
	{
		G::SendPacket = false;

		if (G::SendPacket == false)
			chocked++;

		if (chocked >= 13) {
			G::SendPacket = true;
			chocked = 0;
		}
	}
	
	if (((G::UserCmd->buttons & IN_ATTACK) && canshoot) || G::UserCmd->buttons & IN_USE)
		return;

	auto curNade = (CBaseCSGrenade*)G::LocalPlayer->GetWeapon();
	if (curNade && G::LocalPlayer->GetWeapon()->IsGrenade() && curNade->GetThrowTime() > 0.f)
		return;

	if (G::LocalPlayer->GetMoveType() == MOVETYPE_LADDER || G::LocalPlayer->GetMoveType() == MOVETYPE_NOCLIP)
		return;

	if (Vars.Ragebot.Antiaim.knife_held && G::LocalPlayer->GetAlive() && G::LocalPlayer->GetWeapon()->IsKnife())
		return;

	if (Vars.Ragebot.Antiaim.no_enemy && G::LocalPlayer->GetAlive() && !HasViableEnemy()) // 
		return;


	static bool bSwitch;
	bSwitch = !bSwitch;

	if (!IsFakeLagging && !FakeWalk())
		G::SendPacket = bSwitch;



	FakeWalk();
	Fakelags();





	QAngle View = G::UserCmd->viewangles;

	if (Vars.Ragebot.Antiaim.AtPlayer)
		View = AtTargets();

	static bool bFlip;
	static float pDance = 0.0f;

	bFlip = !bFlip;

	if (Vars.Ragebot.Antiaim.YawReal)
		DoAntiAimY(View, bFlip);

	if (Vars.Ragebot.UntrustedCheck)
		View.Clamp();

	

	
	//pitch stand/move
	if (G::LocalPlayer->GetVelocity().Length2D() > 0.1f)
	{
		switch (Vars.Ragebot.AntiAim.Move.Pitch)
		{
		case 1:
			View.x = 88.9f;
			break;
		case 2:
			View.x = 179.f;
			break;
		case 3:
			View.x = 180.17f;
			break;
		case 4:
			View.x = 271.f;
			break;
		case 5:
			View.x = 1080.f;
			break;
		case 6:
			View.x = 1089.f;
			break;
		case 7:
			View.x = 132.f;
			break;
		case 8:
			View.x = Vars.Ragebot.AntiAim.cY;
			break;
		

		break;
		}

	}
	else
	{
		switch (Vars.Ragebot.AntiAim.Pitch)
		{
		case 1:
			View.x = 88.9f;
			break;
		case 2:
			View.x = 179.f;
			break;
		case 3:
			View.x = 180.17f;
			break;
		case 4:
			View.x = 271.f;
			break;
		case 5:
			View.x = 1080.f;
			break;
		case 6:
			View.x = 1089.f;
			break;
		case 7:
			View.x = 132.f;
			break;
		case 8:
			View.x = Vars.Ragebot.AntiAim.cY;
			break;


			break;
		}

	}


	


	//yaw stand/move

	if (G::SendPacket)
	{
		if (G::LocalPlayer->GetVelocity().Length2D() > 0.1f)
		{

			//Vars.Ragebot.AntiAim.Move.FakeYaw
			switch (Vars.Ragebot.AntiAim.Move.FakeYaw)
			{
			case 1:
				View.y += 180;
				break;
			case 2:
			{
				static float tick;
				tick += Vars.Ragebot.AntiAim.SpinSpeed;
				if (tick > 360)
					tick = 0;
				View.y = tick;
				break;
			}
			case 3:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange / 2;
				View.y += 180 + M::RandFloat(range, -range);
				break;
			}
			case 4:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange2 / 2;
				static bool flip;
				auto InitFlip = []() {
					static clock_t start1_t1 = clock();
					double timeSoFar1 = (double)(clock() - start1_t1) / CLOCKS_PER_SEC;
					if (timeSoFar1 < 0.05)
						return;
					flip = !flip;
					start1_t1 = clock();
				};

				InitFlip();
				View.y += 180 + (flip ? range : -range);
				break;
			}
			case 5:
			{
				float server_time = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
				static float rotate_speed = 100;
				static float rotate_range = 120;
				float yaws = fmod(static_cast<float>(server_time) * rotate_speed, rotate_range);
				View.y += 180 - ((rotate_range / 2) - static_cast<float>(yaws));
				break;
			}
			case 6:
			{
				static float t;
				t += 5;
				if (t > 240)
					t = 120;
				View.y += t;
				break;
			}
			case 7:
			{
				View.y += Vars.Ragebot.AntiAim.cX;
				break;
			}

			}


		}
			
		else
		{

			switch (Vars.Ragebot.AntiAim.FakeYaw)
			{
			case 1:
				View.y += 180;
				break;
			case 2:
			{
				static float tick;
				tick += Vars.Ragebot.AntiAim.SpinSpeed;
				if (tick > 360)
					tick = 0;
				View.y = tick;
				break;
			}
			case 3:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange / 2;
				View.y += 180 + M::RandFloat(range, -range);
				break;
			}
			case 4:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange2 / 2;
				static bool flip;
				auto InitFlip = []() {
					static clock_t start1_t1 = clock();
					double timeSoFar1 = (double)(clock() - start1_t1) / CLOCKS_PER_SEC;
					if (timeSoFar1 < 0.05)
						return;
					flip = !flip;
					start1_t1 = clock();
				};

				InitFlip();
				View.y += 180 + (flip ? range : -range);
				break;
			}
			case 5:
			{
				float server_time = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
				static float rotate_speed = 100;
				static float rotate_range = 120;
				float yaws = fmod(static_cast<float>(server_time) * rotate_speed, rotate_range);
				View.y += 180 - ((rotate_range / 2) - static_cast<float>(yaws));
				break;
			}
			case 6:
			{
				static float t;
				t += 5;
				if (t > 240)
					t = 120;
				View.y += t;
				break;
			}
			case 7:
			{
				View.y += Vars.Ragebot.AntiAim.cX;
				break;
			}

			}
			//Vars.Ragebot.AntiAim.FakeYaw

		}
	}
	else
	{
		if (!G::SendPacket)
		{
			if (BreakLBY())
				View.y += Vars.Ragebot.AntiAim.lby_delta;

			FreestandingRun(View);
		}

		if (G::LocalPlayer->GetVelocity().Length2D() > 0.1f)
		{
			switch (Vars.Ragebot.AntiAim.Move.Yaw)
			{
			case 1:
				View.y += 180;
				break;
			case 2:
			{
				static float tick;
				tick += Vars.Ragebot.AntiAim.SpinSpeed;
				if (tick > 360)
					tick = 0;
				View.y = tick;
				break;
			}
			case 3:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange / 2;
				View.y += 180 + M::RandFloat(range, -range);
				break;
			}
			case 4:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange2 / 2;
				static bool flip;
				auto InitFlip = []() {
					static clock_t start1_t1 = clock();
					double timeSoFar1 = (double)(clock() - start1_t1) / CLOCKS_PER_SEC;
					if (timeSoFar1 < 0.05)
						return;
					flip = !flip;
					start1_t1 = clock();
				};

				InitFlip();
				View.y += 180 + (flip ? range : -range);
				break;
			}
			case 5:
			{
				float server_time = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
				static float rotate_speed = 100;
				static float rotate_range = 120;
				float yaws = fmod(static_cast<float>(server_time) * rotate_speed, rotate_range);
				View.y += 180 - ((rotate_range / 2) - static_cast<float>(yaws));
				break;
			}
			case 6:
			{
				static float t;
				t += 5;
				if (t > 240)
					t = 120;
				View.y += t;
				break;
			}
			case 7:
			{
				View.y += Vars.Ragebot.AntiAim.cX;
				break;
			}

			}
			//Vars.Ragebot.AntiAim.Move.Yaw

		}
		else
		{
			switch (Vars.Ragebot.AntiAim.RealYaw)
			{
			case 1:
				View.y += 180;
				break;
			case 2:
			{
				static float tick;
				tick += Vars.Ragebot.AntiAim.SpinSpeed;
				if (tick > 360)
					tick = 0;
				View.y = tick;
				break;
			}
			case 3:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange / 2;
				View.y += 180 + M::RandFloat(range, -range);
				break;
			}
			case 4:
			{
				float range = Vars.Ragebot.AntiAim.JitterRange2 / 2;
				static bool flip;
				auto InitFlip = []() {
					static clock_t start1_t1 = clock();
					double timeSoFar1 = (double)(clock() - start1_t1) / CLOCKS_PER_SEC;
					if (timeSoFar1 < 0.05)
						return;
					flip = !flip;
					start1_t1 = clock();
				};

				InitFlip();
				View.y += 180 + (flip ? range : -range);
				break;
			}
			case 5:
			{
				float server_time = (float)G::LocalPlayer->GetTickBase() * I::Globals->interval_per_tick;
				static float rotate_speed = 100;
				static float rotate_range = 120;
				float yaws = fmod(static_cast<float>(server_time) * rotate_speed, rotate_range);
				View.y += 180 - ((rotate_range / 2) - static_cast<float>(yaws));
				break;
			}
			case 6:
			{
				static float t;
				t += 5;
				if (t > 240)
					t = 120;
				View.y += t;
				break;
			}
			case 7:
			{
				View.y += Vars.Ragebot.AntiAim.cX;
				break;
			}

			}
			//Vars.Ragebot.AntiAim.RealYaw
		}
	}



	if (Vars.Ragebot.UntrustedCheck)
		View.Clamp();


	G::UserCmd->viewangles = View;

	M::CorrectMovement(oldAngle, G::UserCmd, oldForward, oldSideMove);
}