#include "../Cheat.h"

CFakeLag* FakeLag;

void CFakeLag::Run()
{
	if (Vars.Misc.FakeLags <= 0)
		return;

	if (!I::Engine->IsInGame())
		return;

	if (G::UserCmd->buttons & IN_ATTACK && !Vars.Ragebot.pSilent)
	{
		G::SendPacket = true;
		return;
	}

	if (Vars.Misc.FakeLag == 1) {
		if (ticks >= ticksMax)
		{
			G::SendPacket = true;
			ticks = 0;
		}
		else
		{
			G::SendPacket = ticks < ticksMax - Vars.Misc.FakeLags;
		}
	}

	ticks++;
}