#include "../sdk.h"
#include <fstream>
#include <Psapi.h>
#include "../SkinChanger.h"
#include "../xor.h"

#include <wininet.h>
#include <cstring>
#include <windows.h>
#include <iostream>
#include <urlmon.h>
#include <ctype.h>

#pragma comment(lib,"wininet.lib")
#pragma comment(lib, "urlmon.lib")


MsgFn U::PrintMessage = (MsgFn)GetProcAddress(GetModuleHandleA(charenc("tier0.dll")), charenc("Msg"));
SendClanTagFn U::SendClanTag;
ServerRankRevealAllFn U::ServerRankRevealAllEx;
InitKeyValuesFn U::InitKeyValuesEx;
LoadFromBufferFn U::LoadFromBufferEx;
IsReadyFn U::IsReady;
CL_FullUpdate_t U::CL_FullUpdate = NULL;
LineGoesThroughSmokeFn U::LineToSmoke = NULL;
TraceToExitFn U::TraceToExit = NULL;

void U::SetupInterfaces()
{
	I::Client = U::CaptureInterface<IBaseClientDll>(strenc("client_panorama.dll"), strenc("VClient018"));
	I::ClientMode = **(IClientModeShared***)((*(DWORD**)I::Client)[10] + 5);
	auto pClientVFTable = *reinterpret_cast<uint32_t**>(I::Client);
	I::Input = *reinterpret_cast<CInput**>(U::FindPattern(strenc("client_panorama.dll"), strenc("B9 ? ? ? ? F3 0F 11 04 24 FF 50 10")) + 1);

	I::ClientEntList = U::CaptureInterface<IClientEntityList>(strenc("client_panorama.dll"), strenc("VClientEntityList003"));
	I::Cvar = U::CaptureInterface<ICVar>(strenc("vstdlib.dll"), strenc("VEngineCvar007"));

	I::Engine = U::CaptureInterface<IEngineClient>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("VEngineClient014"));
	I::EngineTrace = U::CaptureInterface<IEngineTrace>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("EngineTraceClient004"));
	I::InputSystem = U::CaptureInterface<IInputSystem>(strenc("inputsystem.dll"), strenc("InputSystemVersion001"));
	I::Localize = U::CaptureInterface<ILocalize>(strenc("localize.dll"), strenc("Localize_001"));
	I::Globals = **(IGlobalVarsBase***)((*(DWORD**)I::Client)[0] + 0x1B);
	I::Surface = U::CaptureInterface<ISurface>(strenc("vguimatsurface.dll"), strenc("VGUI_Surface031"));
	
	I::GameEvent = U::CaptureInterface<IGameEventManager2>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("GAMEEVENTSMANAGER002"));
	I::VPanel = U::CaptureInterface<IVPanel>(strenc("vgui2.dll"), strenc("VGUI_Panel009"));
	I::RenderView = U::CaptureInterface<IVRenderView>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("VEngineRenderView014"));
	I::ModelRender = U::CaptureInterface<IVModelRender>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("VEngineModel016"));
	I::MaterialSystem = U::CaptureInterface<IMaterialSystem>(strenc("materialsystem.dll"), strenc("VMaterialSystem080"));
	I::ModelInfo = U::CaptureInterface<IVModelInfo>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("VModelInfoClient004"));
	I::GameMovement = U::CaptureInterface<IGameMovement>(strenc("client_panorama.dll"), strenc("GameMovement001"));
	I::Prediction = U::CaptureInterface<IPrediction>(strenc("client_panorama.dll"), strenc("VClientPrediction001"));
	I::Physprops = U::CaptureInterface<IPhysicsSurfaceProps>(strenc("vphysics.dll"), strenc("VPhysicsSurfaceProps001"));
	I::DebugOverlay = U::CaptureInterface<IVDebugOverlay>(/*engine.dll*/Xor<0xF1, 11, 0x39AB18D2>("\x94\x9C\x94\x9D\x9B\x93\xD9\x9C\x95\x96" + 0x39AB18D2).s, strenc("VDebugOverlay004"));
	I::StudioRender = U::CaptureInterface<IStudioRender>(strenc("studiorender.dll"), strenc("VStudioRender026"));
	I::MoveHelper = **(IMoveHelper***)(U::FindPattern(strenc("client_panorama.dll"), strenc("8B 0D ? ? ? ? 8B 46 08 68")) + 0x2);
	I::g_pViewRenderBeams = *(IViewRenderBeams**)(U::FindPattern("client_panorama.dll", "B9 ? ? ? ? A1 ? ? ? ? FF 10 A1 ? ? ? ? B9") + 1);
	I::g_GlowObjManager = *(CGlowObjectManager**)(U::FindPattern("client_panorama.dll", "0F 11 05 ? ? ? ? 83 C8 01") + 3);
}

// learn_more
DWORD U::FindPattern(std::string moduleName, std::string pattern)
{
	const char* pat = pattern.c_str();
	DWORD firstMatch = 0;
	DWORD rangeStart = (DWORD)GetModuleHandleA(moduleName.c_str());
	MODULEINFO miModInfo; GetModuleInformation(GetCurrentProcess(), (HMODULE)rangeStart, &miModInfo, sizeof(MODULEINFO));
	DWORD rangeEnd = rangeStart + miModInfo.SizeOfImage;
	for (DWORD pCur = rangeStart; pCur < rangeEnd; pCur++)
	{
		if (!*pat)
			return firstMatch;

		if (*(PBYTE)pat == '\?' || *(BYTE*)pCur == getByte(pat))
		{
			if (!firstMatch)
				firstMatch = pCur;

			if (!pat[2])
				return firstMatch;

			if (*(PWORD)pat == '\?\?' || *(PBYTE)pat != '\?')
				pat += 3;

			else
				pat += 2;    //one ?
		}
		else
		{
			pat = pattern.c_str();
			firstMatch = 0;
		}
	}
	return NULL;
}

inline bool U::Compare(const uint8_t* data, const uint8_t* pattern, const char* mask) {
	for (; *mask; ++mask, ++data, ++pattern)
		if (*mask == 'x' && *data != *pattern)
			return false;

	return (*mask) == 0;
}

int U::SafeWeaponID()
{
	if (!(G::LocalPlayer))
		return 0;

	CBaseCombatWeapon* WeaponC = G::LocalPlayer->GetWeapon();

	if (!(WeaponC))
		return 0;

	return WeaponC->GetItemDefinitionIndex();
}

DWORD_PTR U::FindPattern3(std::string strModuleName, PBYTE pbPattern, std::string strMask, DWORD_PTR nCodeBase, DWORD_PTR nSizeOfCode)
{
	BOOL bPatternDidMatch = FALSE;
	HMODULE hModule = GetModuleHandleA(strModuleName.c_str());

	if (!hModule)
		return 0;

	PIMAGE_DOS_HEADER pDsHeader = PIMAGE_DOS_HEADER(hModule);
	PIMAGE_NT_HEADERS pPeHeader = PIMAGE_NT_HEADERS(LONG(hModule) + pDsHeader->e_lfanew);
	PIMAGE_OPTIONAL_HEADER pOptionalHeader = &pPeHeader->OptionalHeader;

	if (!nCodeBase)
		nCodeBase = (ULONG)hModule + pOptionalHeader->BaseOfCode;

	if (!nSizeOfCode)
		nSizeOfCode = pOptionalHeader->SizeOfCode;

	std::size_t nMaskSize = strMask.length();

	if (!nCodeBase || !nSizeOfCode || !nMaskSize)
		return 0;

	for (DWORD_PTR i = nCodeBase; i <= nCodeBase + nSizeOfCode; i++)
	{
		for (size_t t = 0; t < nMaskSize; t++)
		{
			if (*((PBYTE)i + t) == pbPattern[t] || strMask.c_str()[t] == '?')
				bPatternDidMatch = TRUE;

			else
			{
				bPatternDidMatch = FALSE;
				break;
			}
		}

		if (bPatternDidMatch)
			return i;
	}

	return 0;
}

uintptr_t U::FindPattern2(const char* module, const char* pattern_string, const char* mask) {
	MODULEINFO module_info = {};
	GetModuleInformation(GetCurrentProcess(), GetModuleHandleA(module), &module_info, sizeof MODULEINFO);

	uintptr_t module_start = uintptr_t(module_info.lpBaseOfDll);

	const uint8_t* pattern = reinterpret_cast<const uint8_t*>(pattern_string);

	for (size_t i = 0; i < module_info.SizeOfImage; i++)
		if (Compare(reinterpret_cast<uint8_t*>(module_start + i), pattern, mask))
			return module_start + i;

	return 0;
}
void U::StdReplaceStr(std::string& replaceIn, const std::string& replace, const std::string& replaceWith)
{
	size_t const span = replace.size();
	size_t const step = replaceWith.size();
	size_t index = 0;

	while (true)
	{
		index = replaceIn.find(replace, index);

		if (index == std::string::npos)
			break;

		replaceIn.replace(index, span, replaceWith);
		index += step;
	}
}

CBaseEntity* U::GetLocalPlayer()
{
	return I::ClientEntList->GetClientEntity(I::Engine->GetLocalPlayer());
}

CNetVarManager* U::NetVars = new CNetVarManager;

wchar_t* U::ConvertCharArrayToLPCWSTR(const char* charArray)
{
	wchar_t* wString = new wchar_t[4096];
	MultiByteToWideChar(CP_ACP, 0, charArray, -1, wString, 4096);
	return wString;
}

void U::ClipTraceToPlayers(const Vector& vecAbsStart, const Vector& vecAbsEnd, unsigned int mask, ITraceFilter* filter, trace_t* tr)
{
	if (!offsets.ClipTraceToPlayersFn)
		return;

	_asm
	{
		MOV		EAX, filter
		LEA		ECX, tr
		PUSH	ECX
		PUSH	EAX
		PUSH	mask
		LEA		EDX, vecAbsEnd
		LEA		ECX, vecAbsStart
		CALL	offsets.ClipTraceToPlayersFn
		ADD		ESP, 0xC
	}
}

void U::TraceLine(const Vector& vecAbsStart, const Vector& vecAbsEnd, unsigned int mask, CBaseEntity* ignore, trace_t* ptr)
{
	Ray_t ray;
	ray.Init(vecAbsStart, vecAbsEnd);
	CTraceFilter filter;
	filter.pSkip = ignore;

	I::EngineTrace->TraceRay(ray, mask, &filter, ptr);
}

std::string GetTimeString()
{
	//Time related variables
	time_t current_time;
	struct tm *time_info;
	static char timeString[10];

	//Get current time
	time(&current_time);
	time_info = localtime(&current_time);

	//Get current time as string
	strftime(timeString, sizeof(timeString), "%I:%M%p", time_info);
	return timeString;
}

void SetConsoleColor(WORD color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

#define FOREGROUND_WHITE		    (FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_GREEN)
#define FOREGROUND_INTENSE_GREEN	(FOREGROUND_GREEN | FOREGROUND_INTENSITY)

void U::ServerRankRevealAll()
{
	static float fArray[3] = { 0.f, 0.f, 0.f };

	U::ServerRankRevealAllEx = (ServerRankRevealAllFn)(offsets.ServerRankRevealAllEx);
	U::ServerRankRevealAllEx(fArray);
}

void U::InitKeyValues(KeyValues* pKeyValues, const char* name)
{
	U::InitKeyValuesEx = (InitKeyValuesFn)(offsets.InitKeyValuesEx);
	U::InitKeyValuesEx(pKeyValues, name);
}

void U::LoadFromBuffer(KeyValues* pKeyValues, const char* resourceName, const char* pBuffer, void* pFileSystem, const char* pPathID, void* pfnEvaluateSymbolProc)
{
	U::LoadFromBufferEx = (LoadFromBufferFn)(offsets.LoadFromBufferEx);
	U::LoadFromBufferEx(pKeyValues, resourceName, pBuffer, pFileSystem, pPathID, pfnEvaluateSymbolProc);
}

void U::SendPacket(byte toggle)
{
	*(byte*)(offsets.SendPacket) = toggle;
}

float U::RandomFloat(float min, float max)
{
	assert(max > min);
	float random = ((float)rand()) / (float)RAND_MAX;
	float range = max - min;
	return (random*range) + min;
}




std::uint8_t *PatternScan(void* module, const char* signature)
{
	static auto pattern_to_byte = [](const char* pattern) {
		auto bytes = std::vector<int>{};
		auto start = const_cast<char*>(pattern);
		auto end = const_cast<char*>(pattern) + strlen(pattern);

		for (auto current = start; current < end; ++current) {
			if (*current == '?') {
				++current;
				if (*current == '?')
					++current;
				bytes.push_back(-1);
			}
			else {
				bytes.push_back(strtoul(current, &current, 16));
			}
		}
		return bytes;
	};

	auto dosHeader = (PIMAGE_DOS_HEADER)module;
	auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)module + dosHeader->e_lfanew);

	auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
	auto patternBytes = pattern_to_byte(signature);
	auto scanBytes = reinterpret_cast<std::uint8_t*>(module);

	auto s = patternBytes.size();
	auto d = patternBytes.data();

	for (auto i = 0ul; i < sizeOfImage - s; ++i) {
		bool found = true;
		for (auto j = 0ul; j < s; ++j) {
			if (scanBytes[i + j] != d[j] && d[j] != -1) {
				found = false;
				break;
			}
		}
		if (found) {
			return &scanBytes[i];
		}
	}

	// Afterwards call server to stop dispatch of cheat and to alert us of update.
	//ConsolePrint(true, "A pattern has outtdated: %s", signature);
	return nullptr;
}


using PlaySoundFn = void(__thiscall*)(ISurface*);
PlaySoundFn oPlaySound;
void __stdcall Hooks::PlaySound_CSGO()
{
	if (Vars.Menu.Opened)
	{
		I::Surface->unlockcursor();
		return;
	}
	oPlaySound(I::Surface);
}


SceneEnd_t o_SceneEnd;




void __fastcall SceneEnd_h(void* thisptr, void* edx)
{
	if (!G::LocalPlayer || !I::Engine->IsInGame() || !I::Engine->IsConnected())
		return o_SceneEnd(thisptr);

	o_SceneEnd(thisptr);
	
	if (Vars.Visuals.esp_player_chams)
	{
		constexpr float color_gray[4] = { 166, 167, 169, 255 };
		IMaterial *mat =
			(Vars.Visuals.esp_player_chams_type < 2 ?
				I::MaterialSystem->FindMaterial("chams", TEXTURE_GROUP_MODEL) :
				I::MaterialSystem->FindMaterial("debug/debugdrawflat", TEXTURE_GROUP_MODEL));

		if (!mat || mat->IsErrorMaterial())
			return;

		for (int i = 1; i < I::Globals->maxClients; ++i) {
			CBaseEntity* ent = static_cast<CBaseEntity*>(I::ClientEntList->GetClientEntity(i));
				if (ent && ent->GetAlive()) {

					if (Vars.Visuals.Visualsxd.Visuals_EspTeam && ent->GetTeam() == G::LocalPlayer->GetTeam())
						continue;

					if (Vars.Visuals.esp_player_chams_type == 1 || Vars.Visuals.esp_player_chams_type == 3)
					{	// XQZ Chams
						I::RenderView->SetColorModulation(ent->GetImmune() ? color_gray : (ent->GetTeam() == 2 ? Vars.Visuals.esp_player_chams_color_t : Vars.Visuals.esp_player_chams_color_ct));

						mat->IncrementReferenceCount();
						mat->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, true);

						I::ModelRender->ForcedMaterialOverride(mat);

						ent->DrawModel(0x1, 255);
						I::ModelRender->ForcedMaterialOverride(nullptr);

						I::RenderView->SetColorModulation(ent->GetImmune() ? color_gray : (ent->GetTeam() == 2 ? Vars.Visuals.esp_player_chams_color_t_visible : Vars.Visuals.esp_player_chams_color_ct_visible));

						mat->IncrementReferenceCount();
						mat->SetMaterialVarFlag(MATERIAL_VAR_IGNOREZ, false);

						I::ModelRender->ForcedMaterialOverride(mat);

						ent->DrawModel(0x1, 255);
						I::ModelRender->ForcedMaterialOverride(nullptr);
					}
					else
					{	// Normal Chams
						I::RenderView->SetColorModulation(ent->GetTeam() == 2 ? Vars.Visuals.esp_player_chams_color_t_visible : Vars.Visuals.esp_player_chams_color_ct_visible);

						I::ModelRender->ForcedMaterialOverride(mat);

						ent->DrawModel(0x1, 255);

						I::ModelRender->ForcedMaterialOverride(nullptr);
					}
				}
		}
	}
	

	if (Vars.Visuals.glow_enabled)
	{
		for (auto i = 0; i < I::g_GlowObjManager->m_GlowObjectDefinitions.Count(); i++)
		{
			auto &glowObject = I::g_GlowObjManager->m_GlowObjectDefinitions[i];
			CBaseEntity* entity = reinterpret_cast<CBaseEntity*>(glowObject.m_pEntity);

			if (glowObject.IsUnused())
				continue;

			if (!entity)
				continue;

			auto class_id = entity->GetClientClass()->m_ClassID;
			Color color;

			switch (class_id)
			{
			case 38:
			{
				bool is_enemy = entity->GetTeam() != G::LocalPlayer->GetTeam();
				bool playerTeam = entity->GetTeam() == 2;

				if (!Vars.Visuals.glow_players)
					continue;

				if (playerTeam && Vars.Visuals.Visualsxd.Visuals_EspTeam)
					continue;

				glowObject.m_nGlowStyle = Vars.Visuals.glow_players_style;

				bool vis = !entity->IsVisible(8);
				float* cur_color = (playerTeam ? (vis ? Vars.Visuals.glow_player_color_t_visible : Vars.Visuals.glow_player_color_t) : (vis ? Vars.Visuals.glow_player_color_ct_visible : Vars.Visuals.glow_player_color_ct));

				color.SetColor(cur_color);

				break;
			}

			case 2:

				if (!Vars.Visuals.glow_others)
					continue;

				glowObject.m_nGlowStyle = Vars.Visuals.glow_others_style;
				
				color = Color(Vars.Visuals.glow_player_other[0] * 255, Vars.Visuals.glow_player_other[1] * 255, Vars.Visuals.glow_player_other[2] * 255, Vars.Visuals.glow_player_other[3]*255);

				break;

			case 108:

				if (!Vars.Visuals.glow_others)
					continue;

				glowObject.m_nGlowStyle = Vars.Visuals.glow_others_style;

				color = Color(Vars.Visuals.glow_player_other[0] * 255, Vars.Visuals.glow_player_other[1] * 255, Vars.Visuals.glow_player_other[2] * 255, Vars.Visuals.glow_player_other[3] * 255);

				break;

			default:
			{
				if (entity->IsWeapon())
				{
					if (!Vars.Visuals.glow_others)
						continue;

					glowObject.m_nGlowStyle = Vars.Visuals.glow_others_style;

					color = Color(70, 255, 70, 255);
				}
			}
			}

			glowObject.m_flRed = color.r() / 255.0f;
			glowObject.m_flGreen = color.g() / 255.0f;
			glowObject.m_flBlue = color.b() / 255.0f;
			glowObject.m_flAlpha = color.a() / 255.0f;
			glowObject.m_bRenderWhenOccluded = true;
			glowObject.m_bRenderWhenUnoccluded = false;
		}
	}


}


void U::SetupHooks()
{
	DWORD * VxdPanel = (DWORD*)*(DWORD*)(I::VPanel);
	DWORD * ClienxdtMode = (DWORD*)*(DWORD*)(I::ClientMode);
	DWORD * GamexdEvent = (DWORD*)*(DWORD*)(I::GameEvent);
	DWORD * FramexdClient = (DWORD*)*(DWORD*)(I::Client);
	DWORD * ModelxdDraw = (DWORD*)*(DWORD*)(I::ModelRender);
	DWORD dxtable = U::FindPattern(XorStr("d3d9.dll"), XorStr("C7 06 ? ? ? ? 89 86 ? ? ? ? 89 86"));
	DWORD * pD3D9VTable = (DWORD*)*(DWORD*)(dxtable + 2);
	DWORD * SurfacexdLock = (DWORD*)*(DWORD*)(I::Surface);
	DWORD * ScenexdEnd = (DWORD*)*(DWORD*)(I::RenderView);
	

	oPaintTraverse = (PaintTraverseFn)DetourFunction((PBYTE)VxdPanel[41], (PBYTE)Hooks::PaintTraverse);
	oCreateMove = (CreateMoveFn)DetourFunction((PBYTE)ClienxdtMode[24], (PBYTE)Hooks::CreateMove);
	oOverrideView = (OverrideViewFn)DetourFunction((PBYTE)ClienxdtMode[18], (PBYTE)Hooks::OverrideView);
	oGetViewModel = (oGetViewModelFOV)DetourFunction((PBYTE)ClienxdtMode[35], (PBYTE)Hooks::hkGetViewModelFOV);
	oFireEventClientSide = (FireEventClientSideFn)DetourFunction((PBYTE)GamexdEvent[9], (PBYTE)Hooks::hkFireEventClientSide);
	oFrameStageNotify = (FrameStageNotifyFn)DetourFunction((PBYTE)FramexdClient[37], (PBYTE)Hooks::FrameStageNotify);
	//oDrawModelExecute = (DrawModelExecuteFn)DetourFunction((PBYTE)ModelxdDraw[21], (PBYTE)Hooks::DrawModelExecute);
	oReset = (ResetFn)DetourFunction((PBYTE)pD3D9VTable[16], (PBYTE)Hooks::Reset);
	oEndScene = (EndSceneFn)DetourFunction((PBYTE)pD3D9VTable[42], (PBYTE)Hooks::EndScene);
	oPlaySound = (PlaySoundFn)DetourFunction((PBYTE)SurfacexdLock[67], (PBYTE)Hooks::PlaySound_CSGO);
	o_SceneEnd = (SceneEnd_t)DetourFunction((PBYTE)ScenexdEnd[9], (PBYTE)SceneEnd_h);





//	U::SendClanTag = (SendClanTagFn)U::FindPattern(XorStr("client_panorama.dll"), XorStr("55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0"));
	U::CL_FullUpdate = (CL_FullUpdate_t)U::FindPattern(XorStr("engine.dll"), XorStr("A1 ? ? ? ? B9 ? ? ? ? 56 FF 50 14 8B 34 85"));
	U::LineToSmoke = (LineGoesThroughSmokeFn)U::FindPattern(XorStr("client_panorama.dll"), XorStr("55 8B EC 83 EC 08 8B 15 ? ? ? ? 0F 57 C0"));
	U::TraceToExit = (TraceToExitFn)U::FindPattern(XorStr("client_panorama.dll"), XorStr("55 8B EC 83 EC 30 F3 0F 10 75"));
	//GetSkins(k_Skins, k_Gloves, "csgo");

	//NetVars->DumpNetvars();
}

void U::SetupOffsets()
{
	U::NetVars->Initialize();
	Offsets::GrabOffsets();
}

void U::SetupTextures()
{
	visible_flat = I::MaterialSystem->CreateMaterial(true, false, false);
	visible_tex = I::MaterialSystem->CreateMaterial(false, false, false);
	hidden_flat = I::MaterialSystem->CreateMaterial(true, true, false);
	hidden_tex = I::MaterialSystem->CreateMaterial(false, true, false);
	GlassChams = I::MaterialSystem->FindMaterial(charenc("models/inventory_items/cologne_prediction/cologne_prediction_glass"), charenc(TEXTURE_GROUP_OTHER));
}

void U::Setup()
{
	U::SetupInterfaces();

	U::SetupOffsets();

	D::SetupFonts();

	U::SetupTextures();

	U::SetupHooks();

	//SetupOffsets();

	Config->Setup();


	//START VARS
	Vars.Ragebot.UntrustedCheck = true;
	//Vars.Legitbot. = 8;

	//	U::NetVars->HookProp("DT_BaseViewModel", "m_nModelIndex", SkinChanger::RecvProxy_Viewmodel);

	ApplyAAAHooks();
}





struct D3DTLVERTEX
{
	float x, y, z, rhw;
	DWORD color;
};





namespace Menu
{
	D3DVIEWPORT9 viewPort;
	LPD3DXFONT fntVerdana11 = nullptr;
	LPD3DXFONT fntVerdana10 = nullptr;
	LPD3DXFONT fntVerdana9 = nullptr;
	LPD3DXFONT fntWeaponIcon = nullptr;

	const char* merixids[] =
	{
		"1","2","3","4","5","6", "7", "8", "9",
		"Q","W","E","R","T","Y","U","I","O","P",
		"A","S","D","F","G","H","J","K","L",
		"Z","X","C","V","B","N","M",".","\\","|", "/","}","{","[","]",
		"<",">","?","'"
	};


	void DrawLineFast(float x1, float y1, float x2, float y2, D3DCOLOR COLOR, IDirect3DDevice9* pDevice)
	{
		D3DTLVERTEX qV[2] = {
			{ x1, y1, 0.0f, 1.0f, COLOR },
		{ x2, y2, 0.0f, 1.0f, COLOR },
		};

		pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA); //pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_SRCALPHA); // neon mode
		pDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
		pDevice->SetRenderState(D3DRS_FOGENABLE, false);

		DWORD oldFVF;

		pDevice->GetFVF(&oldFVF);
		pDevice->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
		pDevice->SetTexture(0, 0);
		pDevice->DrawPrimitiveUP(D3DPT_LINELIST, 1, qV, sizeof(D3DTLVERTEX));
		pDevice->SetFVF(oldFVF);
	}

	float GetTextWitdh(char *text, LPD3DXFONT fnt)
	{
		RECT fontRect = { 0,0,0,0 };

		fnt->DrawText(NULL, text, strlen(text), &fontRect, DT_CALCRECT, D3DCOLOR_XRGB(0, 0, 0));

		return fontRect.right - fontRect.left;
	}
	int GetTextWitdhW(wchar_t *text, LPD3DXFONT fnt)
	{
		RECT fontRect = { 0,0,0,0 };

		fnt->DrawTextW(NULL, text, -1, &fontRect, DT_CALCRECT, D3DCOLOR_XRGB(0, 0, 0));

		return fontRect.right - fontRect.left;
	}
	bool WorldToScreen(Vector vOrigin, Vector &vScreen)
	{


		float w = viewMatrix[3][0] * vOrigin.x + viewMatrix[3][1] * vOrigin.y + viewMatrix[3][2] * vOrigin.z + viewMatrix[3][3];

		float ScreenWidth = (float)Menu::viewPort.Width;
		float ScreenHeight = (float)Menu::viewPort.Height;

		if (w > 0.01f)
		{
			float inverseWidth = 1.f / w;
			vScreen.x = (float)((ScreenWidth / 2) + (0.5 * ((viewMatrix[0][0] * vOrigin.x + viewMatrix[0][1] * vOrigin.y + viewMatrix[0][2] * vOrigin.z + viewMatrix[0][3]) * inverseWidth) * ScreenWidth + 0.5));
			vScreen.y = (float)((ScreenHeight / 2) - (0.5 * ((viewMatrix[1][0] * vOrigin.x + viewMatrix[1][1] * vOrigin.y + viewMatrix[1][2] * vOrigin.z + viewMatrix[1][3]) * inverseWidth) * ScreenHeight + 0.5));
			return true;
		}

		return false;
	}




	void DrawFilledRectangle(float x, float y, float height, float width, D3DCOLOR COLOR, IDirect3DDevice9* pDevice)
	{
		D3DXVECTOR2 points[5];

		/*
		x	y
		h	w
		*/

		D3DTLVERTEX t1[3] = {
			{ x, y, 0.0f, 1.0f, COLOR },
		{ x + width, y, 0.0f, 1.0f, COLOR },
		{ x + width, y + height, 0.0f, 1.0f, COLOR },
		};

		D3DTLVERTEX t2[3] = {
			{ x , y, 0.0f, 1.0f, COLOR },
		{ x + width , y + height, 0.0f, 1.0f, COLOR },
		{ x, y + height, 0.0f, 1.0f, COLOR },
		};

		pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA); //pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_SRCALPHA); // neon mode
		pDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
		pDevice->SetRenderState(D3DRS_FOGENABLE, false);

		DWORD oldFVF;

		pDevice->GetFVF(&oldFVF);
		pDevice->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1);
		pDevice->SetTexture(0, 0);
		pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 1, t1, sizeof(D3DTLVERTEX));
		pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 1, t2, sizeof(D3DTLVERTEX));
		pDevice->SetFVF(oldFVF);
	}

	int FrameRate() {
		static int iFps, iLastFps;
		static float flLastTickCount, flTickCount;
		flTickCount = clock() * 0.001f;
		iFps++;
		if ((flTickCount - flLastTickCount) >= 1.0f) {
			flLastTickCount = flTickCount;
			iLastFps = iFps;
			iFps = 0;
		}
		return iLastFps;
	}

	void DrawStringWithFont(LPD3DXFONT fnt, float x, float y, D3DCOLOR color, char *format, ...)
	{
		char buffer[256];
		RECT fontRect = { (int)x, (int)y, (int)x, (int)y };

		va_list va_argList;

		va_start(va_argList, format);
		wvsprintf(buffer, format, va_argList);
		va_end(va_argList);

		fnt->DrawText(NULL, buffer, strlen(buffer), &fontRect, DT_NOCLIP, color);
	}





	void DrawCornierBoxFastAlpha(float x, float y, float height, float width, D3DCOLOR COLOR, float alpha, IDirect3DDevice9* pDevice)
	{
		D3DXVECTOR2 points[4][3];


		
		switch (Vars.Visuals.Visualsxd.Visuals_BoxType)
		{
		case 0:
		{
			points[0][0] = D3DXVECTOR2(x, y);
			points[0][1] = D3DXVECTOR2(x + (width)* alpha, y);
			points[0][2] = D3DXVECTOR2(x, y + (height)* alpha);

			points[1][0] = D3DXVECTOR2(x + width, y);
			points[1][1] = D3DXVECTOR2(x + width - (width)* alpha, y);
			points[1][2] = D3DXVECTOR2(x + width, y + (height)* alpha);


			points[2][0] = D3DXVECTOR2(x, y + height);
			points[2][1] = D3DXVECTOR2(x + (width)* alpha, y + height);
			points[2][2] = D3DXVECTOR2(x, y + height - (height)* alpha);

			points[3][0] = D3DXVECTOR2(x + width, y + height);
			points[3][1] = D3DXVECTOR2(x + width - (width)* alpha, y + height);
			points[3][2] = D3DXVECTOR2(x + width, y + height - (height)* alpha);
		}break;
		case 1:
		{
			points[0][0] = D3DXVECTOR2(x, y);
			points[0][1] = D3DXVECTOR2(x + (width / 4.5f)* alpha, y);
			points[0][2] = D3DXVECTOR2(x, y + (height / 5.f)* alpha);

			points[1][0] = D3DXVECTOR2(x + width, y);
			points[1][1] = D3DXVECTOR2(x + width - (width / 4.5f)* alpha, y);
			points[1][2] = D3DXVECTOR2(x + width, y + (height / 5.f)* alpha);


			points[2][0] = D3DXVECTOR2(x, y + height);
			points[2][1] = D3DXVECTOR2(x + (width / 4.5f)* alpha, y + height);
			points[2][2] = D3DXVECTOR2(x, y + height - (height / 5.f)* alpha);

			points[3][0] = D3DXVECTOR2(x + width, y + height);
			points[3][1] = D3DXVECTOR2(x + width - (width / 4.5f)* alpha, y + height);
			points[3][2] = D3DXVECTOR2(x + width, y + height - (height / 5.f)* alpha);
		}break;
		default: break;
		}





		DrawLineFast(points[0][0].x, points[0][0].y, points[0][1].x, points[0][1].y, COLOR, pDevice);
		DrawLineFast(points[0][0].x, points[0][0].y, points[0][2].x, points[0][2].y, COLOR, pDevice);

		DrawLineFast(points[1][0].x, points[1][0].y, points[1][1].x, points[1][1].y, COLOR, pDevice);
		DrawLineFast(points[1][0].x, points[1][0].y, points[1][2].x, points[1][2].y, COLOR, pDevice);

		DrawLineFast(points[2][0].x, points[2][0].y, points[2][1].x, points[2][1].y, COLOR, pDevice);
		DrawLineFast(points[2][0].x, points[2][0].y, points[2][2].x, points[2][2].y, COLOR, pDevice);

		DrawLineFast(points[3][0].x, points[3][0].y, points[3][1].x, points[3][1].y, COLOR, pDevice);
		DrawLineFast(points[3][0].x, points[3][0].y, points[3][2].x, points[3][2].y, COLOR, pDevice);
	}


	CBaseCombatWeapon* GetActiveBaseCombatWeaponxd(CBaseEntity *entity)
	{
		//CANCRUSH
		HANDLE pWeepEhandle = *reinterpret_cast<HANDLE*>(uintptr_t(entity) + 0x2EE8);
		return (CBaseCombatWeapon*)(I::ClientEntList->GetClientEntityFromHandle(pWeepEhandle));
	}

	void RenderMonitor()
	{
		if (!I::Engine->IsConnected())
			return;

		if (!I::Engine->IsInGame())
			return;
		
		CBaseEntity* pLocal = G::LocalPlayer;

		if (!pLocal)
			return;

		if (!pLocal->GetAlive())
			return;

		

		if (ImGui::Begin(XorStr("Monitor"), &Vars.Visuals.Visualsxd.Panels.Monitor, ImVec2(200, 250), 1.0F, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize))
		{
			ImDrawList* windowDrawList = ImGui::GetWindowDrawList();

			ImVec2 siz = ImGui::GetWindowSize();
			ImVec2 pos = ImGui::GetWindowPos();

			CBaseCombatWeapon* pWeapon = GetActiveBaseCombatWeaponxd(pLocal);
			if (pWeapon)
			{
				float accuracy = pWeapon->GetInaccuracy() * 550.f;

				if (accuracy > 179)
					accuracy = 179;

				int iSpeed = 0;
				Vector vSpeed = pLocal->GetVelocity();
				iSpeed = (int)vSpeed.Length2D();

				int iBoost = 0;
				Vector vBoost = pLocal->GetVelocity();
				iBoost = (int)vBoost.Length2D() - 300;

				float flPunch = 0.0f;
				Vector vRecoil = pLocal->GetPunchAngle();
				flPunch = (float)vRecoil.Length();

				if (iSpeed < 300)
					windowDrawList->AddText(ImVec2(pos.x + 25, pos.y + 1 + 217), Color(255, 255, 255, 255).GetU32(), XorStr("Speed"));
				if (iSpeed > 300)
					windowDrawList->AddText(ImVec2(pos.x + 25, pos.y + 1 + 217), Color(255, 0, 0, 255).GetU32(), XorStr("Boost"));
				windowDrawList->AddText(ImVec2(pos.x + 85, pos.y + 1 + 217), Color(255, 255, 255, 255).GetU32(), XorStr("Recoil"));
				windowDrawList->AddText(ImVec2(pos.x + 145, pos.y + 1 + 217), Color(255, 255, 255, 255).GetU32(), XorStr("Spread"));

				windowDrawList->AddRect(ImVec2(pos.x + 147, pos.y + 35), ImVec2(pos.x + 147 + 25, pos.y + 35 + 180), Color(0, 0, 0, 255).GetU32());
				windowDrawList->AddRect(ImVec2(pos.x + 87, pos.y + 35), ImVec2(pos.x + 87 + 25, pos.y + 35 + 180), Color(0, 0, 0, 255).GetU32());
				windowDrawList->AddRect(ImVec2(pos.x + 28, pos.y + 35), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), Color(0, 0, 0, 255).GetU32());

				if (iSpeed < 300)
					windowDrawList->AddRectFilled(ImVec2(pos.x + 28, pos.y + 35 + 180 - (iSpeed * 0.6)), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), Color(255, 255, 255, 255).GetU32());

				if (iSpeed > 300)
					windowDrawList->AddRectFilled(ImVec2(pos.x + 28, pos.y + 35 + 180 - (iBoost * 0.2)), ImVec2(pos.x + 28 + 25, pos.y + 35 + 180), Color(255, 0, 0, 255).GetU32());

				windowDrawList->AddRectFilled(ImVec2(pos.x + 147, pos.y + 35 + 180 - accuracy), ImVec2(pos.x + 147 + 25, pos.y + 35 + 180), Color(255, 255, 255, 255).GetU32());
				windowDrawList->AddRectFilled(ImVec2(pos.x + 87, pos.y + 35 + 180 - flPunch * 30), ImVec2(pos.x + 87 + 25, pos.y + 35 + 180), Color(255, 255, 255, 255).GetU32());

				ImGui::End();
			}
		}
	}


	void CircleFilledRainbowColor(float x, float y, float rad, float rotate, int type, int resolution, IDirect3DDevice9* m_device)
	{
		LPDIRECT3DVERTEXBUFFER9 g_pVB2;

		std::vector<D3DTLVERTEX> circle(resolution + 2);

		float angle = rotate * D3DX_PI / 180, pi = D3DX_PI;

		if (type == 1)
			pi = D3DX_PI; // Full circle
		if (type == 2)
			pi = D3DX_PI / 2; // 1/2 circle
		if (type == 3)
			pi = D3DX_PI / 4; // 1/4 circle

		pi = D3DX_PI / type; // 1/4 circle

		circle[0].x = x;
		circle[0].y = y;
		circle[0].z = 0;
		circle[0].rhw = 1;
		circle[0].color = D3DCOLOR_RGBA(0, 0, 0, 0);

		float hue = 0.f;

		for (int i = 1; i < resolution + 2; i++)
		{
			circle[i].x = (float)(x - rad * cos(pi*((i - 1) / (resolution / 2.0f))));
			circle[i].y = (float)(y - rad * sin(pi*((i - 1) / (resolution / 2.0f))));
			circle[i].z = 0;
			circle[i].rhw = 1;

			auto clr = Color::FromHSB(hue, 1.f, 1.f);
			circle[i].color = D3DCOLOR_RGBA(clr.r(), clr.g(), clr.b(), clr.a());
			hue += 0.02;
		}

		// Rotate matrix
		int _res = resolution + 2;
		for (int i = 0; i < _res; i++)
		{
			float Vx1 = x + (cosf(angle) * (circle[i].x - x) - sinf(angle) * (circle[i].y - y));
			float Vy1 = y + (sinf(angle) * (circle[i].x - x) + cosf(angle) * (circle[i].y - y));

			circle[i].x = Vx1;
			circle[i].y = Vy1;
		}

		m_device->CreateVertexBuffer((resolution + 2) * sizeof(D3DTLVERTEX), D3DUSAGE_WRITEONLY, D3DFVF_XYZRHW | D3DFVF_DIFFUSE, D3DPOOL_DEFAULT, &g_pVB2, NULL);

		VOID* pVertices;
		g_pVB2->Lock(0, (resolution + 2) * sizeof(D3DTLVERTEX), (void**)&pVertices, 0);
		memcpy(pVertices, &circle[0], (resolution + 2) * sizeof(D3DTLVERTEX));
		g_pVB2->Unlock();

		m_device->SetTexture(0, NULL);
		m_device->SetPixelShader(NULL);
		m_device->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		m_device->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		m_device->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

		m_device->SetStreamSource(0, g_pVB2, 0, sizeof(D3DTLVERTEX));
		m_device->SetFVF(D3DFVF_XYZRHW | D3DFVF_DIFFUSE);
		m_device->DrawPrimitive(D3DPT_TRIANGLEFAN, 0, resolution);
		if (g_pVB2 != NULL)
			g_pVB2->Release();
	}

	void DrawCircleFast(float x, float y, int radius, int numSides, D3DCOLOR color, IDirect3DDevice9* pDevice)
	{
		float step = (float)(D3DX_PI * 2.0 / numSides);

		if (step <= 0)
			return;

		for (float a = 0; a < D3DX_PI*2.0; a += step)
		{
			float X1 = radius * cosf(a) + x;
			float Y1 = radius * sinf(a) + y;
			float X2 = radius * cosf(a + step) + x;
			float Y2 = radius * sinf(a + step) + y;

			DrawLineFast(X1, Y1, X2, Y2, color, pDevice);
		}
	}

	void drawfatalpricel(IDirect3DDevice9* pDevice)
	{
		int w, h;
		static float rot = 0.f;
		CBaseCombatWeapon* pWeapon = NULL;
		I::Engine->GetScreenSize(w, h); w /= 2; h /= 2;
		auto weapons = G::LocalPlayer->GetWeapons();
		for (size_t i = 0; weapons[i] != 0xFFFFFFFF; i++)
		{
			CBaseEntity *pEntity = I::ClientEntList->GetClientEntityFromHandle((HANDLE)weapons[i]);
			pWeapon = (CBaseCombatWeapon*)pEntity;
		}
		if (pWeapon)
		{
			int Index = pWeapon->GetItemDefinitionIndex();
			if (Index != 42 && Index != 59 && Index != 500)
			{
				auto accuracy = pWeapon->GetInaccuracy() * 550.f;
				CircleFilledRainbowColor(w, h, accuracy, rot, 1, 50, pDevice);

				rot += 1.f;
				if (rot > 360.f) rot = 0.f;
			}
		}

	}
}



