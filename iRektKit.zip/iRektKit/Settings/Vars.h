#pragma once
#include "../ImGUI/imgui.h"

class Weapon_tTT
{
public:
	int SkinsWeapon;
	int SkinsKnife;
	int VremennyiWeapon;
	int VremennyiKnife;
	int Stikers1;
	int Stikers2;
	int Stikers3;
	int Stikers4;
	float ChangerWear = 0;
	int ChangerStatTrak = 0;
	char ChangerName[32] = "";
	bool ChangerEnabled;
};

class cVisuals
{
public:
	bool BulletTracers;
	float Bulletracer[4] = { 1.f, 1.f, 1.f, 1.0f };
	bool 	Enabled;
	bool 	Box;
	int 	BoxType;
	bool	Skeleton;
	bool	Glow;
	bool	SpectatorList;
	bool	BulletTrace;
	int ViewmodelFov;
	bool esp3d;
	int Line;
	bool CrosshairFOV;
	//float   BulletTraceLength;
	bool	CrosshairOn;
	bool CrosshairSpread;
	bool		CrosshairType;
	int		CrosshairStyle;
	bool CrosshairRainbow;
	float 	TeamColor[3];
	float 	TeamColorWall[3];
	float 	EnemyColor[3];
	float 	EnemyColorWall[3];

	bool glow_enabled;
	bool glow_players;
	int glow_players_style;
	bool glow_others;
	int glow_others_style;

	float glow_player_color_t[4] = { 1.f, 0.f, 0.3f, 1.f };
	float glow_player_color_ct[4] = { 0.f, 0.2f, 1.f, 1.f };
	float glow_player_color_t_visible[4] = { 1.f, 1.f, 0.0f, 1.f };
	float glow_player_color_ct_visible[4] = { 0.f, 0.7f, 1.f, 0.85f };
	float glow_player_other[4] = { 0.f, 0.7f, 1.f, 0.85f };
	bool esp_player_chams;
	int esp_player_chams_type;
	float esp_player_chams_color_t_visible[4] = { 1.f, 1.f, 0.0f, 1.f };
	float esp_player_chams_color_ct_visible[4] = { 0.15f, 0.7f, 1.f, 1.0f };
	float esp_player_chams_color_t[4] = { 1.f, 0.f, 0.3f, 1.f };
	float esp_player_chams_color_ct[4] = { 0.f, 0.2f, 1.f, 1.f };

	struct
	{
		bool Enemies;
		bool Friendlies;
		bool C4;
		bool Weapons;
	} Filter;

	struct
	{
		bool enabled;
		float distance;
	} thirdperson;


	struct
	{
		bool	RainbowHands;
		float 	RainbowTime;
		bool	Enabled;
		int 	Mode;
		bool	Wireframe;
		bool	hands;
		bool	XQZ;
		float 	TeamColor[3];
		float 	TeamColorWall[3];
		float  	EnemyColor[3];
		float 	EnemyColorWall[3];
	} Chams;

	struct
	{
		bool Enabled;
		bool EnemyOnly;
		int range;
		bool Nicks;
	} Radar;

	bool NoScope;
	bool AntiSS;

	bool 	InfoHealth;
	bool 	ShowWeapon;
	bool	InfoFlashed;

	bool	RemovalsHands;
	bool	HandChams;
	bool	ChamsWeapon;
	bool	RemovalsVisualRecoil;
	bool	RemovalsFlash;
	bool    RemovalsSmoke;
	bool	RemovalsSky;

	bool Enemi;
	bool Healt;
	bool c4;
	bool Wep;





	struct Visualsxd
	{
		bool Enabled = true;
		bool Visuals_BoxEnabled = true;
		int Visuals_BoxType = 1;
		int Visuals_HealthBarType = 1;
		bool Visuals_Scoped = false;
		bool Visuals_AmmoESP = true;
		int Visuals_AmmoESPType = 1;

		bool Visuals_EspTeam = false;
		bool Visuals_VisableOnly = false;

		float BoxColorPickCTVIS[4] = { 1.0f,0.0f,0.0f,1.0f };
		float BoxColorPickCTINVIS[4] = { 1.0f,1.0f,0.0f,1.0f };


		float BoxColorPickTVIS[4] = { 0.0f,1.0f,0.0f,1.0f };
		float BoxColorPickTINVIS[4] = { 0.0f,1.0f,1.0f,1.0f };


		float LagCompHitboxes[4] = { 0.0f,1.0f,0.0f,1.0f };



		float SkeletonCTVIS[4] = { 1.0f,0.0f,0.0f,1.0f };
		float SkeletonCTINVIS[4] = { 1.0f,1.0f,0.0f,1.0f };

		float SkeletonTVIS[4] = { 0.0f,1.0f,0.0f,1.0f };
		float SkeletonTINVIS[4] = { 0.0f,1.0f,1.0f,1.0f };




		float CTChamsVisable[4] = { 1.0f,0.0f,0.0f,1.0f };

		float TChamsVisable[4] = { 1.0f,1.0f,0.0f,1.0f };


		float CTChamsInVisable[4] = { 0.0f,1.0f,0.0f,1.0f };
		float TChamsInVisable[4] = { 1.0f,1.0f,0.0f,1.0f };

		float beamtrace[4] = { 1.0f,0.0f,0.0f,1.0f };
		int thirdkey;
		int Hitsound;
		bool tp_bool;
		bool Monitor;
		bool Visuals_HealthBar = true;
		bool Visuals_Name = true;
		bool Visuals_ArmorBar = false;
		bool Visuals_Flashed = false;
		bool Visuals_Defuser = false;
		bool Visuals_Weapons = false;
		int Visuals_WeaponsType = 0;
		bool Visuals_AimLines = false;
		bool Visuals_Skeltal = false;
		bool Visuals_EngineRadar = false;
		bool Visuals_DrawLinesAA = false;
		bool Visuals_DroppedWeapons = false;
		bool Visuals_NoRecoil = false;
		bool Visuals_NoFlash = false;
		bool Visuals_NoSmoke = false;
		bool Visuals_NoSmokeVar = false;
		bool Visuals_NoScope = false;
		bool Visuals_NoZoom = false;
		bool Visuals_NoPostProcess = false;


		bool Visuals_Chams = true;
		bool Visuals_ChamsTeam = false;
		bool Visuals_ChamsXQZ = false;
		int  Visuals_ChamsMaterial = 1;
		bool Visuals_GhostAngle = false;
		bool Visuals_ChamsGuns = false;
		bool Visuals_Crosshair = false;
		bool Visuals_CrosshairDynamic = false;


		float CTGlowVisable[4] = { 1.f,1.0f,1.0f,1.0f };
		float TGlowVisable[4] = { 1.f,1.0f,1.0f,1.0f };
		float CTGlowInVisable[4] = { 1.f,1.0f,1.0f,1.0f };
		float TGlowInVisable[4] = { 1.f,1.0f,1.0f,1.0f };

		bool Visuals_Hitmarker = false;
		bool Visuals_Spread = false;
		bool Visuals_GrenadePrediction = false;
		bool Visuals_DamageESP = false;
		bool Visuals_C4 = false;
		bool eventlog_enabled = false;
		float SpreadColor[4] = { 1.0f,0.0f,0.0f,1.0f };

		float DamageESPColor[4] = { 1.0f,0.0f,0.0f,1.0f };
		bool Vis_Glow = true;
		bool Vis_Glow_Team = false;
		bool Vis_Glow_Vis = false;


		bool Visuals_NightMode = false;
		bool Visuals_Asus = false;

		bool Visuals_DrawBeams = false;
		float Visuals_DrawBeamsDuration = 3.f;
		float Visuals_DrawBeamsSize = 3.f;

		bool Visuals_DrawCapsules = false;
		bool Visuals_DrawEventLog = false;
		float capsulecolor[4] = { 1.0,0.0f,0.0f,1.0f };
		float Visuals_DrawCapsulesDuration = 5.f;
		int Visuals_Spread_Type = 0;
		struct
		{
			bool Enabled = false;
			float Distance = 800.f;
			int type = 0;
			float Radius = 10.f;
			bool Animated = false;
			bool visonly = true;
		}SoundESP;
		struct
		{
			struct
			{
				bool	ExternalRadar;
				int		RadarStyle;
				float	RadarDistance;
				bool	RadarVisibleOnly;
				bool	RadarSmoke;
			}Radar;
			bool Monitor = false;
		}Panels;

		bool lbyIndicator = false;
		bool strelkiIndicator = false;
	}Visualsxd;






};

class cSkins
{
public:
		bool SSEnabled;
		int Glove;
		int GloveSkin;
		int KnifeModel;
		int SkinModel;
		int GloveModel;


		struct wpnz
		{
			int PaintKit;
			int StatTrk;
			float Wear;
		}Weapons[519];
};

class cMenu
{
public:
		bool	Opened = false;
		int 	Key;
		bool	Ragebot = false;
		bool	Legitbot = false;
		bool	Visual = false;
		bool	Misc = false;
};

class cMisc
{
public:
	
	bool rcs_standalone = false;
	float first_rcs_stand = 1.6f,
		second_rcs_stand = 0.1f;
	
	int FakeLag;
		int		FakeLags;
		int		yawchocked;
		int		fov;
		bool 	Bhop;
		int 	AutoStrafe;
		bool	ChatSpam;
		char    SpamText[32] = "";
		bool SwastikaSpam;
		bool NameSteal;
		bool NameStealSelf;
		float NameStealDelay;
		bool LocSpam;
		int Cname;
		int alpha;
		bool LocSpamEnemies;
		bool LocSpamChat;
		float ChatSpamDelay;
		bool TapSay;
		bool SoundShit;
		bool bombinfo;
		char configname[128] = "default";
		bool	Watermark;
		bool	Ranks;
		bool	AirStuck;
		int		AirStuckKey;
		bool	AutoAccept;
		bool Unload;
		struct
		{
			bool enabled;
			char* value;
			bool animation;
			int animation_speed;
			int type;
		} ClantagChanger;
		bool NameChangerenabled;
		int NameChangerseparator_animation;
};

class cRagebot
{
public:
	bool 	Enabled;
	bool 	AutoFire;
	bool 	Hold;
	int 	HoldKey;
	int 	Filter; // will hold flags for team/enemy/etc.
	bool 	Silent;
	bool	RRCS;
	int		RCS;
	bool pSilent;
	float	RCShow;
	bool 	VisCheck;
	bool 	AutoWall;
	float	AutoWallDmg;
	int		Hitbox;
	int		pHitBox;
	float 	FOV;
	bool 	HitChance;
	float	HitChanceAmt;
	bool MultiPoints;
	float PointScale;
	bool 	AutoStop;
	bool AutoScope;
	bool 	AutoStopFast;
	bool 	AutoStopCanShoot;
	bool	ShootWhenStopped;//
	bool 	AutoCrouch;
	bool 	FriendlyFire;
	bool	Aimstep;
	float	AimstepAmount;
	int	HitScan;
	bool NoSpreadFix;
	//bool HVHhs;
	bool AutoPistol;
	bool	UntrustedCheck = true;



	struct
	{
		bool Enable;
		int Pitch;
		int ChokeFactor;
		int RealYaw;
		float RealYawAdd;
		int FakeYaw;
		float FakeYawAdd;
		bool AtTarget;
		bool FakeWalk;
		bool AutoShuffle;
		int FakeWalkButton;
		int SuffleRight;
		int SuffleLeft;
		float SpinSpeed;
		float SpinSpeedfake;
		float JitterSpeed;
		float JitterRange;
		float JitterRange2;
		int cX;
		int cY;
		bool JitterSpeedDynamic;
		bool AAWithKnife;
		bool Freestading;
		bool AAWithGrenades;
		bool Edge;
		float FakeWalkSpeed;
		bool FakeLagEnable;
		int FakeLag;
		int FakeLagAmount;
		bool FakeLagInAirOnly;
		int ShuffleFlipKey;
		bool CrookedMode;
		bool ZeroAtPeek;
		float lby_delta;
		struct
		{
			int Pitch;
			int Yaw;
			int FakeYaw;
			float YawAdd;
			float FakeYawAdd;
		}Move;

	} AntiAim;

	bool HLow;
	bool HALL;

	bool    bones[6] = { true, true, true, true, true, true };//
	int ResolverHelper;

	struct
	{
		bool	Enabled;
		bool FakeYaw;
		int	Resolver;
		bool	knife_held;
		bool	no_enemy;
		int		Pitch;
		int		YawReal;
		int		YawFake;//
		bool	DetectEdge;//
		float	EdgeDistance;//
		bool	Shuffle;
		bool AtPlayer;
		int Zeta;
		int spinspeed;
		int spinspeedz;
		bool YawCustom;
		bool PitchCustom;
		float PCReal;
		float PCFake;
	
		float YCFake;
		float YCReal;
	} Antiaim;
};

class cLegitBot
{
public:
	struct
	{
		bool 	Enabled;
		int 	Key;
		bool	OnKey;
		int group;
		int 	Filter; // will hold flags for team/enemy/etc.
		bool smart;
		bool 	VisCheck;
		bool 	AlwaysOn;
		bool	FriendlyFire;
		bool	SmokeCheck;
		bool AutoPistol;
		bool	KillStop;
	} Aimbot;

	struct
	{
		bool 	Enabled;
		bool 	pSilent;
		float RCSAmountX;
		float RCSAmountY;
		float	Speed;
		int 	Hitbox;
		float	PFOV;
		float 	FOV;
		bool 	AdaptiveSmooth;
		bool FireDelayEnabled;
		float FireDelay;
		int pHitbox;
				
		bool TriggerBot;
	} Weapon[519];

	bool fastzoom;
	bool fastzoomswitch;
	int delay;

	struct
	{
		bool	Enabled;
		bool	AutoFire;
		bool    IsOnKey;
		bool    CustomHitBoxes;
		int		Key;
		bool 	HitChance;
		float	HitChanceAmt;
		bool AutoWall;
		int Delay;


		struct
		{
			bool Head;
			bool Chest;
			bool Stomach;
			bool Arms;
			bool Legs;
			bool Friendly;
			bool smoke;
		} Filter;

	} Triggerbot;

};

class Variables
{
public:
	//CRageBotTab RageBotTab;
	cRagebot Ragebot;
	cVisuals Visuals;
	cMisc Misc;
	cLegitBot Legitbot;
	cSkins Skins;
	cMenu Menu;
	Weapon_tTT weapons[520];

	int wpn;

	Variables()
	{
		wpn = -1;
	}
	int bomber;
	int Hostage;
	bool font2;
	int defuser;
	bool bomb;
	bool shoot;
	//QAngle lastTickViewAngles = { 0,0,0 };
	bool bIsNoShot;
	int m_iBulletsFire = 0;

	float g_fMColor[4] = { 0.50f, 0.67f, 0.75f, 1.0f }; //RGBA color
	float g_fBColor[4] = { 0.31f, 0.30f, 0.30f, 1.0f };
	float g_fTColor[4] = { 0.85f, 0.87f, 0.90f, 1.0f };

	float g_iChamsTV[4] = { 0.30f, 0.47f, 0.05f, 1.0f };
	float g_iChamsCTH[4] = { 0.941f, 0.0f, 0.0f, 1.0f };
	float g_iChamsTH[4] = { 0.941f, 0.0f, 0.0f, 1.0f };
	float g_iChamsCTV[4] = { 0.30f, 0.47f, 0.05f, 1.0f };

	float g_iBoxV[4] = { 0.30f, 0.47f, 0.05f, 1.0f };
	float g_iBoxH[4] = { 0.941f, 0.0f, 0.0f, 1.0f };

	ImFont* font;
	




	bool Save(std::string file_name);
	bool Load(std::string file_name);

	bool Remove(std::string file_name);

	void CreateConfig(std::string name); // creates a blank config

	std::vector<std::string> GetConfigs();

	int config_sel;


};

	extern Variables Vars;