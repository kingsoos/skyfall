#pragma once

void ApplyStickerHooks(CBaseCombatWeapon* item);