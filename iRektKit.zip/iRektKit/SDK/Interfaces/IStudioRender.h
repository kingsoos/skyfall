#pragma once

class IStudioRender;