#include "../../sdk.h"
/*
surfacedata_t* IPhysicsSurfaceProps::GetSurfaceData(int surfaceDataIndex)
{
	typedef surfacedata_t*(__thiscall* OriginalFn)(void*, int);
	return U::GetVFunc<OriginalFn>(this, 5)(this, surfaceDataIndex);
}*/