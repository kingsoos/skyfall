#pragma once

class IBaseClientDll
{
public:
	ClientClass* GetAllClasses();
};