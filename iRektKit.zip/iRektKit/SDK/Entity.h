#pragma once

enum MoveType_t
{
	MOVETYPE_NONE = 0,
	MOVETYPE_ISOMETRIC,
	MOVETYPE_WALK,
	MOVETYPE_STEP,
	MOVETYPE_FLY,
	MOVETYPE_FLYGRAVITY,
	MOVETYPE_VPHYSICS,
	MOVETYPE_PUSH,
	MOVETYPE_NOCLIP,
	MOVETYPE_LADDER,
	MOVETYPE_OBSERVER,
	MOVETYPE_CUSTOM,
	MOVETYPE_LAST = MOVETYPE_CUSTOM,
	MOVETYPE_MAX_BITS = 4
};

enum DataUpdateType_t
{
	DATA_UPDATE_CREATED = 0,
	DATA_UPDATE_DATATABLE_CHANGED,
};

class CBaseCombatWeapon;
class CBaseEntity
{
public:
	char				__pad[0x64];
	int					index;
	int					GetIndex();
	bool IsDefusing();
	int					GetHealth();
	int					GetTeam();
	int					GetFlags();
	int					GetTickBase();
	int					GetShotsFired();
	float				GetSensitivity();
	int					iShotsFired(int i);
	int					GetMoveType();
	int*					GetModelIndex();
	int					GetHitboxSet();
	int					GetUserID();
	int					GetArmor();
	int					GetCompetitiveRanking(int index);
	int					GetCollisionGroup();
	int					PhysicsSolidMaskForEntity();
	int					GetOwner();
	DWORD				GetOwnerHandler();
	int					GetGlowIndex();
	int					GetBoneByName(const char* boneName);
	int GetSequence();
	//IClientNetworkable * GetNetworkable();
	void SetModelIndex(int index);
	bool IsWeapon();
	bool				GetAlive();
	bool GetLifeState();
	QAngle*				GetVAngles();
	CBaseEntity*				GetViewModel();
	bool				GetDormant();
	bool				GetImmune();
	bool				IsEnemy();
	bool				IsVisible( int bone );
	bool				m_visible;
	bool				IsBroken();
	bool				IsScoped();
	bool				HasHelmet();
	bool				IsFlashed();
	bool IsKnife();
	int					*GetWeapons();
	int					GetPlayerC4();
	bool				IsTargetingLocal();
	float				GetFlashDuration();
	float				GetBombTimer();
	QAngle				GetViewPunch();
	QAngle				GetPunch();
	QAngle 				GetEyeAngles();
	Vector GetEyeAnglesxd();
	QAngle* 			GetHeadRotation();
	float* 				GetLowerBodyYawTarget();
	float&				GetSimulationTime();
	Vector				GetOrigin();
	Vector				GetAbsOrigin();
	Vector				GetEyePosition();
	Vector				GetBonePositionz(int iBone);
	Vector				GetBonePosition( int iBone );
	bool				SetupBones( matrix3x4_t *pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime );
	bool HandleBoneSetup(int boneMask, matrix3x4_t * boneOut);
	Vector				GetVelocity();
	Vector GetPunchAngle();
	Vector				GetPredicted( Vector p0 );
	ICollideable*		GetCollideable();
	int DrawModel(int flags, const int & instance);
	player_info_t		GetPlayerInfo();
	model_t*			GetModel();
	std::string			GetName();
	std::string			GetSteamID();
	std::string			GetLastPlace();
	int&				GetXUIDLow();
	int&				GetXUIDHigh();
	CBaseCombatWeapon*	GetWeapon();
	DWORD GetActiveWeapon();
	HANDLE GetActiveWeaponHANDLE();
	ClientClass*		GetClientClass();
	HANDLE				GetObserverTargetHandle();
	void PreDataUpdate(DataUpdateType_t updateType);
	bool IsVisibleVector(Vector bone);
	//void GetPreDataUpdate(DataUpdateType_t updateType);
	//void * GetPreDataUpdate();
	//IClientNetworkable * GetClientNetworkable();
	//DWORD GetObserverTargetHandleD();
};

class CPlayer
{
public:
	Vector ShootPos[125];
	int index = -1;
	CBaseEntity* entity;
	Vector reset = Vector(0, 0, 0);
	float lastsim = 0;
	Vector lastorigin = Vector(0, 0, 0);
	std::vector< float > pastangles;
	int ScannedNumber = 0;
	int BestIndex = 0;
	float difference = 0.f;
	float Backtrack[360];
	float flLastPelvisAng = 0.f;
	float flEyeAng = 0.f;
	float resolved = 0.f;
	float posedifference = 0.f;
	int* box;

	CPlayer(CBaseEntity* entity, int index, int lastsim) : entity(entity), index(index), lastsim(lastsim)
	{
	}
};

class CBaseAttributableItem : public CBaseEntity
{
public:
	int* GetItemDefinitionIndex()
	{
		return (int*)((uintptr_t)this + offsets.m_iItemDefinitionIndex);
	}

	int* GetItemIDHigh()
	{
		return (int*)((uintptr_t)this + offsets.m_iItemIDHigh);
	}

	int* GetEntityQuality()
	{
		return (int*)((uintptr_t)this + offsets.m_iEntityQuality);
	}

	int* GetFallbackPaintKit()
	{
		return (int*)((uintptr_t)this + offsets.m_nFallbackPaintKit);
	}

	int* GetFallbackSeed()
	{
		return (int*)((uintptr_t)this + offsets.m_nFallbackSeed);
	}

	float* GetFallbackWear()
	{
		return (float*)((uintptr_t)this + offsets.m_flFallbackWear);
	}

	int* GetFallbackStatTrak()
	{
		return (int*)((uintptr_t)this + offsets.m_nFallbackStatTrak);
	}

	int* GetAccountID()
	{
		return (int*)((uintptr_t)this + offsets.m_iAccountID);
	}
};

class CHudTexture
{
public:
	char type[64]; //0x0000
	char subtype[64]; //0x0040
	char unknowndata00[2]; //0x0080
	char charinFont; //0x0082
	char unknowndata01[1]; //0x0083
};//Size=0x00AC

class WeaponInfo_t
{
public:
	char _0x0000[20];
	__int32 max_clip;			//0x0014 
	char _0x0018[12];
	__int32 max_reserved_ammo;	//0x0024 
	char _0x0028[96];
	char* hud_name;				//0x0088 
	char* weapon_name;			//0x008C 
	char _0x0090[60];
	__int32 type;				//0x00CC 
	__int32 price;				//0x00D0 
	__int32 reward;				//0x00D4 
	char _0x00D8[20];
	BYTE full_auto;				//0x00EC 
	char _0x00ED[3];
	__int32 damage;				//0x00F0 
	float armor_ratio;			//0x00F4 
	__int32 bullets;			//0x00F8 
	float penetration;			//0x00FC 
	char _0x0100[8];
	float range;				//0x0108 
	float range_modifier;		//0x010C 
	char _0x0110[16];
	BYTE silencer;				//0x0120 
	char _0x0121[15];
	float max_speed;			//0x0130 
	float max_speed_alt;		//0x0134 
	char _0x0138[76];
	__int32 recoil_seed;		//0x0184 
	char _0x0188[32];
};

class CBaseCombatWeapon
{
public:
	char			__pad[0x64];
	int				index;
	short&			GetWeaponID();
	float&			GetNextPrimaryAttack();
	float&			GetAccuracyPenalty();
	float& GetSpread();
	float GetInaccuracyReal();
	float& GetInaccuracy();
	float & GetAllInaccuracy();
	HANDLE			GetOwnerHandle();
	int&			GetXUIDLow();
	int&			GetXUIDHigh();
	int&			GetEntityQuality();
	int&			GetAccountID();
	int ammo();
	int ammo2();
	model_t * GetModel();
	int & GetModelIndex();
	int&			GetItemIDHigh();
	int & GetItemIDLow();
	short&			GetItemDefinitionIndex();
	int&			GetFallbackPaintKit();
	int & GetViewModelIndex();
	int & GetWorldModelIndex();
	int&			GetFallbackStatTrak();
	float&			GetFallbackWear();
	float & GetflPostponeFireReadyTime();
	bool			IsEmpty();
	int BulletSize();
	int				Clip();
	int				Clip2();
	bool			IsReloading();
	void			UpdateAccuracyPenalty();
	float			GetWeaponSpread();
	float			GetWeaponCone();
	WeaponInfo_t*	GetCSWpnData();
	CBaseEntity SetModelIndex(int index);
	bool			IsGun();
	bool			IsSniper();
	bool IsOneShotSniper();
	bool IsRifle();
	bool IsSmg();
	bool IsShotgun();
	bool IsPistol();
	bool			IsGrenade();
	std::string		GetWeaponName();
	bool			IsKnife();
	bool IsRevolver();
	char* GetCustomName();
};

class C_BaseAttributableItem : public CBaseCombatWeapon {
public:
	bool meow();
};


class CBaseCSGrenade : CBaseCombatWeapon
{
public:
	float GetPinPulled();
	float GetThrowTime();
};