#pragma once

#include "Cheat.h"

namespace ThirdPerson
{
	void BeginFrame();
	void FrameStageNotify(ClientFrameStage_t stage);
}