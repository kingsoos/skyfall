#pragma once
#include "GameEvent.h"
#include <d3d9.h>
using CreateMoveFn = bool( __stdcall* )(float, CUserCmd* );
extern CreateMoveFn oCreateMove;

using FireEventClientSideFn = bool(__thiscall*)(IGameEventManager2*, IGameEvent*);
extern FireEventClientSideFn oFireEventClientSide;

using RenderViewFn = void(__thiscall*)(void*, CViewSetup&, CViewSetup&, unsigned int, int);
extern RenderViewFn oRenderViewHook;

using FrameStageNotifyFn = void( __stdcall* )( ClientFrameStage_t );
extern FrameStageNotifyFn oFrameStageNotify;

using FindMdlFn = void(__thiscall*)(void*, char*);
extern FindMdlFn oFindMDL;

using PaintTraverseFn = void( __thiscall* )(void*, unsigned int, bool, bool );
extern PaintTraverseFn oPaintTraverse;

typedef float(__stdcall *oGetViewModelFOV)();
extern oGetViewModelFOV oGetViewModel;

using OverrideViewFn = void(__thiscall* )(void*, CViewSetup* );
extern OverrideViewFn oOverrideView;

using DrawModelExecuteFn = void*( __stdcall* )( void*, void*, const ModelRenderInfo_t&, matrix3x4_t* );
extern DrawModelExecuteFn oDrawModelExecute;
  
//using InPredictionFn = bool( __stdcall* )( );
//extern InPredictionFn oInPrediction;

typedef void(__thiscall *SceneEnd_t)(void*);
extern SceneEnd_t o_SceneEnd;

using EndSceneFn = long( __stdcall* )( IDirect3DDevice9* device );
extern EndSceneFn oEndScene;

using ResetFn = long( __stdcall* )( IDirect3DDevice9* device, D3DPRESENT_PARAMETERS* pp );
extern ResetFn oReset;

using OverrideMouseInputFn = void( __stdcall* )( float* pX, float* pY );
extern OverrideMouseInputFn oOverrideMouseInput;



namespace Hooks
{
	extern bool __stdcall CreateMove(float flInputSampleTime, CUserCmd* cmd );
	extern void __stdcall FrameStageNotify( ClientFrameStage_t stage );
	extern void __fastcall PaintTraverse(void* ecx, void* edx, unsigned int panel, bool forceRepaint, bool allowForce );
	extern void __fastcall OverrideView(void* ecx, void* edx, CViewSetup* vsView );
	extern bool __fastcall hkFireEventClientSide(IGameEventManager2* thispt, void* edx, IGameEvent* pEvent);
	extern void __fastcall FindMDL(void* thisptr, void* edx, char *path);
	extern float __stdcall hkGetViewModelFOV();
	extern void __fastcall khRenderView(void* thisptr, void* edx , CViewSetup& setup, CViewSetup& hudViewSetup, unsigned int nClearFlags, int whatToDraw);
	extern void __stdcall DrawModelExecute( void* context, void* state, const ModelRenderInfo_t &pInfo, matrix3x4_t *pCustomBoneToWorld );
	extern void __stdcall PlaySound_CSGO();
	extern long __stdcall EndScene( IDirect3DDevice9* pDevice );
	extern long __stdcall Reset( IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentationParameters );

	extern WNDPROC oldWindowProc;
	extern LRESULT __stdcall WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
}


extern bool menuop;




//shit as fuck but xd

#include <d3dx9.h>

extern float viewMatrix[4][4];


namespace Menu
{
	extern LPD3DXFONT fntVerdana11;
	extern LPD3DXFONT fntVerdana10;
	extern D3DVIEWPORT9 viewPort;
	extern LPD3DXFONT fntWeaponIcon;
	extern void DrawFilledRectangle(float x, float y, float height, float width, D3DCOLOR COLOR, IDirect3DDevice9* pDevice);
	extern void DrawStringWithFont(LPD3DXFONT fnt, float x, float y, D3DCOLOR color, char *format, ...);
	extern LPD3DXFONT fntVerdana9;
	extern void DrawLineFast(float x1, float y1, float x2, float y2, D3DCOLOR COLOR, IDirect3DDevice9* pDevice);
	extern void DrawCornierBoxFastAlpha(float x, float y, float height, float width, D3DCOLOR COLOR, float alpha, IDirect3DDevice9* pDevice);
	extern bool WorldToScreen(Vector vOrigin, Vector &vScreen);
	extern int GetTextWitdhW(wchar_t *text, LPD3DXFONT fnt);
	extern float GetTextWitdh(char *text, LPD3DXFONT fnt);
	extern void DrawCircleFast(float x, float y, int radius, int numSides, D3DCOLOR color, IDirect3DDevice9* pDevice);
	extern int FrameRate();
	extern void RenderMonitor();
}

#define D3D_COLOR_LIME(a)	D3DCOLOR_ARGB(a, 204, 255, 153)
#define D3D_COLOR_WHITE(a)	D3DCOLOR_ARGB(a, 255, 255, 255)
#define D3D_COLOR_BLACK(a)	D3DCOLOR_ARGB(a, 0, 0, 0)
#define D3D_COLOR_RED(a)	D3DCOLOR_ARGB(a, 255, 0, 0)
#define D3D_COLOR_DARKRED(a)D3DCOLOR_ARGB(a, 153, 0, 0)
#define D3D_COLOR_GREEN(a)	D3DCOLOR_ARGB(a, 0, 255, 0)
#define D3D_COLOR_DARKGREEN(a)	D3DCOLOR_ARGB(a, 0, 153, 0)
#define D3D_COLOR_BLUE(a)	D3DCOLOR_ARGB(a, 0, 0, 255)
#define D3D_COLOR_DARKBLUE(a)D3DCOLOR_ARGB(a, 0, 0, 153)
#define D3D_COLOR_YELLOW(a)	D3DCOLOR_ARGB(a, 255, 255, 0)
#define D3D_COLOR_PINK(a)	D3DCOLOR_ARGB(a, 255, 0, 255)
#define D3D_COLOR_ORANGE(a)	D3DCOLOR_ARGB(a, 255, 153, 0)
#define D3D_COLOR_LIGHTBLUE(a)D3DCOLOR_ARGB(a, 0, 255, 255) 
#define D3D_COLOR_BROWN(a)	D3DCOLOR_ARGB(a, 153, 102, 0)
#define D3D_COLOR_GRAY(a)	D3DCOLOR_ARGB(a, 153, 153, 153)
#define D3D_COLOR_DARKGRAY(a)	D3DCOLOR_ARGB(a, 13, 13, 13)



class IDirect3DDevice9;

namespace D9Visuals
{
	void Render(IDirect3DDevice9* pDevice);
	void DrawCrossHair(float size, DWORD color);
	void DrawName(CBaseEntity *entity);
	void DrawWeapon(CBaseEntity *entity, IDirect3DDevice9* pDevice);
	void DrawHealth(CBaseEntity *entity, IDirect3DDevice9* pDevice);
	void DrawBox(CBaseEntity *entity, int cType, IDirect3DDevice9* pDevice);
	void DrawBone(CBaseEntity * entity, matrix3x4_t * pBoneToWorldOut, DWORD color, IDirect3DDevice9 * pDevice);
	void DrawBoneESP(CBaseEntity *entity, int cType, IDirect3DDevice9* pDevice);


	bool GetPlayerBox(CBaseEntity *entity, float &x, float &y, float &width, float &height, Vector offset = Vector(0, 0, 0));
	bool Filter(CBaseEntity *entity, bool& IsVis);

	void PunchAnglesToScreen(int height, int width, int FOV, int *resultX, int *resultY);

	extern bool canUseSetupBones;

	extern int PlayerNickVal[65];
	extern int PlayerAlpha[65];
	extern float PlayerBoxAlpha[65];

};


namespace DamageESP
{
	class FloatingText
	{
	public:
		FloatingText() :
			valid(false)
		{ }

		bool valid;
		float startTime;
		int damage;
		int hitgroup;
		Vector hitPosition;
		int randomIdx;
	};

	const int MAX_FLOATING_TEXTS = 50;
	extern std::array<FloatingText, MAX_FLOATING_TEXTS> floatingTexts;

	void HandleGameEvent(IGameEvent* pEvent);
	void Draw();
};
